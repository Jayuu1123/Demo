
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { format, parseISO, isValid } from 'date-fns';
import { addInvoice } from './invoices'; // Import for conversion
import { salesOrderStatusOptions, type SalesOrderStatus } from '@/types/sales'; // Import from types file

// Define status options for reuse and clarity - MOVED TO types/sales.ts
// export const salesOrderStatusOptions = ['Draft', 'To Deliver and Bill', 'To Bill', 'Delivered', 'Completed', 'Cancelled'] as const;
// export type SalesOrderStatus = typeof salesOrderStatusOptions[number]; // MOVED TO types/sales.ts


// Helper function from quotations, ensure consistency
const validateAndFormatDate = (dateString: unknown): string | null => {
    if (typeof dateString !== 'string' || !dateString) return null;
    try {
        if (/^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
             const parsed = parseISO(dateString);
             if (isValid(parsed)) return format(parsed, 'yyyy-MM-dd');
         }
        const parsed = new Date(dateString);
        if (isValid(parsed)) return format(parsed, 'yyyy-MM-dd');
    } catch (e) { }
    return null;
};

const SalesOrderSchema = z.object({
  id: z.string().optional(),
  customer: z.string().min(1, "Customer name is required"),
  orderDate: z.string().refine(val => validateAndFormatDate(val) !== null, {
      message: "Invalid order date format (YYYY-MM-DD required)"
  }),
  deliveryDate: z.string().refine(val => validateAndFormatDate(val) !== null, {
      message: "Invalid delivery date format (YYYY-MM-DD required)"
  }),
  total: z.number().positive("Total must be a positive number").optional().nullable(),
  status: z.enum(salesOrderStatusOptions), // Use imported enum
});

export type SalesOrder = z.infer<typeof SalesOrderSchema>;

// Get all sales orders
// Optimization: Add pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getSalesOrders(): Promise<SalesOrder[]> {
  try {
    // Ensure 'orderDate' and 'id' columns are indexed for sorting
    const result = await runSqlQuery('SELECT * FROM sales_orders ORDER BY orderDate DESC, id DESC');
     // Format/validate dates and numbers on retrieval
      return (result.rows as any[]).map(row => ({
          ...row,
          total: row.total != null ? Number(row.total) : null,
          // Ensure dates are valid YYYY-MM-DD strings
          orderDate: validateAndFormatDate(row.orderDate) || format(new Date(), 'yyyy-MM-dd'),
          deliveryDate: validateAndFormatDate(row.deliveryDate) || format(new Date(), 'yyyy-MM-dd'),
          status: row.status as SalesOrderStatus, // Assert type if needed
      }));
  } catch (error) {
    console.error("Failed to fetch sales orders:", error);
    return [];
  }
}

// Add a new sales order
export async function addSalesOrder(formData: FormData): Promise<{ success: boolean; message: string; id?: string; errors?: Record<string, string[]> | z.ZodIssue[] }> {
    const rawData = Object.fromEntries(formData.entries());

    // Convert total to number or null
    let totalValue: number | null = null;
    const rawTotal = rawData.total;
    if (rawTotal !== '' && rawTotal !== undefined && rawTotal !== null) {
         const parsedTotal = parseFloat(rawTotal as string);
         if (!isNaN(parsedTotal) && parsedTotal > 0) { // Ensure positive
            totalValue = parsedTotal;
         } else {
             // Return specific validation error for total
             return { success: false, message: "Validation failed", errors: { total: ["Total must be a positive number."] } };
         }
    }
    rawData.total = totalValue;

    // Validate and format dates
     const formattedOrderDate = validateAndFormatDate(rawData.orderDate);
     const formattedDeliveryDate = validateAndFormatDate(rawData.deliveryDate);

     if (!formattedOrderDate) {
        return { success: false, message: "Validation failed", errors: { orderDate: ["Invalid order date format. Use YYYY-MM-DD."] } };
     }
     if (!formattedDeliveryDate) {
         return { success: false, message: "Validation failed", errors: { deliveryDate: ["Invalid delivery date format. Use YYYY-MM-DD."] } };
     }

      rawData.orderDate = formattedOrderDate;
      rawData.deliveryDate = formattedDeliveryDate;

      // Default status if missing or invalid
      if (!salesOrderStatusOptions.includes(rawData.status as any)) {
          rawData.status = 'Draft'; // Or 'To Deliver and Bill' might be better
      }

    const validatedData = SalesOrderSchema.omit({ id: true }).safeParse(rawData);

    if (!validatedData.success) {
        console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
        return {
            success: false,
            message: "Validation failed",
            errors: validatedData.error.flatten().fieldErrors,
        };
    }

    const data = validatedData.data;
    // Optimization: Use crypto.randomUUID()
    const newId = `SO-${Date.now()}-${crypto.randomUUID().slice(0, 5)}`;

    try {
        // Ensure primary key 'id' is indexed
        await runSqlQuery(
        'INSERT INTO sales_orders (id, customer, orderDate, deliveryDate, total, status) VALUES (?, ?, ?, ?, ?, ?)',
        [
            newId,
            data.customer,
            data.orderDate,
            data.deliveryDate,
            data.total, // Already validated number or null
            data.status,
        ]
        );
        revalidatePath('/sales/sales-orders');
        return { success: true, message: "Sales Order added successfully", id: newId };
    } catch (error) {
        console.error("Failed to add sales order:", error);
        return { success: false, message: "Database error occurred while adding sales order.", error: error instanceof Error ? error.message : String(error) };
    }
}

// Delete a sales order
export async function deleteSalesOrder(id: string) {
   if (!id) {
     return { success: false, message: "Sales Order ID is required" };
   }
   try {
       // Ensure 'id' and 'status' columns are indexed if checking status
       const orderResult = await runSqlQuery('SELECT status FROM sales_orders WHERE id = ?', [id]);
       const order = orderResult.rows[0] as Pick<SalesOrder, 'status'> | undefined;

       if (!order) {
           return { success: false, message: "Sales Order not found." };
       }

       if (order && ['Delivered', 'Completed', 'To Bill'].includes(order.status)) {
             return { success: false, message: `Cannot delete order with status '${order.status}'. Consider cancelling first.` };
       }

        // Ensure primary key 'id' is indexed
       const deleteResult = await runSqlQuery('DELETE FROM sales_orders WHERE id = ?', [id]);
       if (deleteResult.rowsAffected === 0) {
           return { success: false, message: "Sales Order not found or already deleted." };
       }

       revalidatePath('/sales/sales-orders');
       return { success: true, message: "Sales Order deleted successfully" };
   } catch (error) {
       console.error("Failed to delete sales order:", error);
       return { success: false, message: "Database error occurred while deleting sales order.", error: error instanceof Error ? error.message : String(error) };
   }
}

// Cancel a sales order
export async function cancelSalesOrder(id: string) {
    if (!id) {
        return { success: false, message: "Sales Order ID is required" };
    }
    try {
        // Ensure 'id' and 'status' columns are indexed
        const orderResult = await runSqlQuery('SELECT status FROM sales_orders WHERE id = ?', [id]);
        const order = orderResult.rows[0] as Pick<SalesOrder, 'status'> | undefined;

        if (!order) {
             return { success: false, message: "Sales Order not found" };
        }
        if (order.status === 'Completed' || order.status === 'Cancelled') {
            return { success: false, message: `Order is already ${order.status}.` };
        }

        // Ensure 'id' and 'status' columns are indexed
        const updateResult = await runSqlQuery('UPDATE sales_orders SET status = ? WHERE id = ?', ['Cancelled', id]);
        if (updateResult.rowsAffected === 0) {
            return { success: false, message: "Sales Order not found or status not updated." };
        }

        revalidatePath('/sales/sales-orders');
        return { success: true, message: "Sales Order cancelled successfully" };
    } catch (error) {
        console.error("Failed to cancel sales order:", error);
        return { success: false, message: "Database error occurred while cancelling order.", error: error instanceof Error ? error.message : String(error) };
    }
}


// Create Invoice from Sales Order
// Optimization: Consider using a database transaction
export async function createInvoiceFromSalesOrder(orderId: string) {
    if (!orderId) {
        return { success: false, message: "Sales Order ID is required" };
    }

    try {
        // Fetch Sales Order Data
        // Ensure 'id' is indexed
        const soResult = await runSqlQuery('SELECT * FROM sales_orders WHERE id = ?', [orderId]);
        const salesOrder = soResult.rows[0] as SalesOrder | undefined;

        if (!salesOrder) {
            return { success: false, message: "Sales Order not found" };
        }

        // Check if invoice can be created based on status
        if (!['To Deliver and Bill', 'To Bill', 'Delivered'].includes(salesOrder.status)) {
             return { success: false, message: `Invoice cannot be created for order with status '${salesOrder.status}'.` };
        }


        // Create Invoice (addInvoice handles its own DB operation)
        const invoiceFormData = new FormData();
        invoiceFormData.append('customer', salesOrder.customer);
        // Posting date = today, Due date maybe 30 days from today?
        const today = new Date();
        const dueDate = new Date();
        dueDate.setDate(today.getDate() + 30);

        invoiceFormData.append('postingDate', format(today, 'yyyy-MM-dd'));
        invoiceFormData.append('dueDate', format(dueDate, 'yyyy-MM-dd'));
        if (salesOrder.total !== null) {
            invoiceFormData.append('grandTotal', salesOrder.total.toString());
            // Outstanding amount initially equals grand total
            invoiceFormData.append('outstandingAmount', salesOrder.total.toString());
        } else {
             // Handle case where SO total is null - maybe prevent invoice creation or set default?
             return { success: false, message: "Cannot create invoice from Sales Order with no total amount." };
        }
        invoiceFormData.append('status', 'Unpaid'); // Default for new invoice

        const addInvResult = await addInvoice(invoiceFormData);

        if (!addInvResult.success) {
            console.error("Failed to create Invoice during SO conversion:", addInvResult.errors || addInvResult.error);
            return { success: false, message: `Failed to create Invoice: ${addInvResult.message}` };
        }

        // Update Sales Order status to 'Completed'
        // Ensure 'id' and 'status' columns are indexed
        await runSqlQuery('UPDATE sales_orders SET status = ? WHERE id = ?', ['Completed', orderId]);

        // Revalidate paths
        revalidatePath('/sales/sales-orders');
        revalidatePath('/sales/invoices');

        return { success: true, message: "Invoice created successfully from Sales Order", invoiceId: addInvResult.id };

    } catch (error) {
        console.error("Failed to create invoice from sales order:", error);
        // Consider rolling back invoice creation if UPDATE fails (requires transaction)
        return { success: false, message: "Database error occurred during invoice creation.", error: error instanceof Error ? error.message : String(error) };
    }
}

// TODO: Implement updateSalesOrder function
// Ensure UPDATE uses WHERE id = ? and updates only necessary fields
// Function signature should be async function updateSalesOrder(...) { ... }

// TODO: Implement 'Create Delivery Note' functionality (might involve a new table/status updates)
// Ensure necessary indexes and potentially transactions
// Function signature should be async function createDeliveryNote(...) { ... }
