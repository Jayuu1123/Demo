
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { format, parseISO, isValid } from 'date-fns';
import { addSalesOrder } from './salesOrders'; // Import for conversion
import { quotationStatusOptions, type QuotationStatus } from '@/types/sales'; // Import from types file

// Define status options for reuse and clarity - MOVED TO types/sales.ts
// export const quotationStatusOptions = ['Draft', 'Sent', 'Accepted', 'Rejected', 'Expired', 'Cancelled'] as const;
// export type QuotationStatus = typeof quotationStatusOptions[number]; // MOVED TO types/sales.ts


// Helper to validate and format date strings
const validateAndFormatDate = (dateString: unknown): string | null => {
    if (typeof dateString !== 'string' || !dateString) return null;
    try {
        if (/^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
            const parsed = parseISO(dateString);
            if (isValid(parsed)) return format(parsed, 'yyyy-MM-dd');
        }
        const parsed = new Date(dateString);
         if (isValid(parsed)) {
            return format(parsed, 'yyyy-MM-dd');
        }
    } catch (e) { /* Ignore parsing errors */ }
    return null;
};


const QuotationSchema = z.object({
  id: z.string().optional(),
  customer: z.string().min(1, "Customer name is required"),
  date: z.string().refine(val => validateAndFormatDate(val) !== null, {
      message: "Invalid date format (YYYY-MM-DD required)"
  }),
  expiryDate: z.string().refine(val => validateAndFormatDate(val) !== null, {
      message: "Invalid expiry date format (YYYY-MM-DD required)"
  }),
  total: z.number().positive("Total must be a positive number").optional().nullable(),
  status: z.enum(quotationStatusOptions), // Use imported enum
});

export type Quotation = z.infer<typeof QuotationSchema>;

// Get all quotations
// Optimization: Add pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getQuotations(): Promise<Quotation[]> {
  try {
     // Ensure 'date' and 'id' columns are indexed for sorting
    const result = await runSqlQuery('SELECT * FROM quotations ORDER BY date DESC, id DESC');
    // Format/validate dates and numbers on retrieval
     return (result.rows as any[]).map(row => ({
         ...row,
         total: row.total != null ? Number(row.total) : null,
         // Ensure dates are valid YYYY-MM-DD strings
         date: validateAndFormatDate(row.date) || format(new Date(), 'yyyy-MM-dd'),
         expiryDate: validateAndFormatDate(row.expiryDate) || format(new Date(), 'yyyy-MM-dd'),
         status: row.status as QuotationStatus, // Assert type if needed
     }));
  } catch (error) {
    console.error("Failed to fetch quotations:", error);
    return [];
  }
}

// Add a new quotation
export async function addQuotation(formData: FormData): Promise<{ success: boolean; message: string; id?: string; errors?: Record<string, string[]> | z.ZodIssue[] }> {
    const rawData = Object.fromEntries(formData.entries());

    // Convert total to number or null
    let totalValue: number | null = null;
    const rawTotal = rawData.total;
     if (rawTotal !== '' && rawTotal !== undefined && rawTotal !== null) {
         const parsedTotal = parseFloat(rawTotal as string);
         if (!isNaN(parsedTotal) && parsedTotal > 0) { // Ensure positive
            totalValue = parsedTotal;
         } else {
             // Return specific validation error for total
             return { success: false, message: "Validation failed", errors: { total: ["Total must be a positive number."] } };
         }
     }
    rawData.total = totalValue;

    // Validate and format dates
     const formattedDate = validateAndFormatDate(rawData.date);
     const formattedExpiryDate = validateAndFormatDate(rawData.expiryDate);

     if (!formattedDate) {
        return { success: false, message: "Validation failed", errors: { date: ["Invalid date format. Use YYYY-MM-DD."] } };
     }
      if (!formattedExpiryDate) {
         return { success: false, message: "Validation failed", errors: { expiryDate: ["Invalid expiry date format. Use YYYY-MM-DD."] } };
     }

      rawData.date = formattedDate;
      rawData.expiryDate = formattedExpiryDate;

      // Default status if missing or invalid
      if (!quotationStatusOptions.includes(rawData.status as any)) {
          rawData.status = 'Draft';
      }


    const validatedData = QuotationSchema.omit({ id: true }).safeParse(rawData);

    if (!validatedData.success) {
        console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
        return {
            success: false,
            message: "Validation failed",
            errors: validatedData.error.flatten().fieldErrors,
        };
    }

    const data = validatedData.data;
    // Optimization: Use crypto.randomUUID()
    const newId = `QTN-${Date.now()}-${crypto.randomUUID().slice(0, 5)}`;

    try {
        // Ensure primary key 'id' is indexed
        await runSqlQuery(
        'INSERT INTO quotations (id, customer, date, expiryDate, total, status) VALUES (?, ?, ?, ?, ?, ?)',
        [
            newId,
            data.customer,
            data.date, // Use validated & formatted date
            data.expiryDate, // Use validated & formatted expiry date
            data.total, // Already validated number or null
            data.status,
        ]
        );
        revalidatePath('/sales/quotations');
        return { success: true, message: "Quotation added successfully", id: newId };
    } catch (error) {
        console.error("Failed to add quotation:", error);
        return { success: false, message: "Database error occurred while adding quotation.", error: error instanceof Error ? error.message : String(error) };
    }
}

// Delete a quotation
export async function deleteQuotation(id: string) {
    if (!id) {
      return { success: false, message: "Quotation ID is required" };
    }
    try {
      // Ensure 'id' and 'status' columns are indexed if checking status
      const qtnResult = await runSqlQuery('SELECT status FROM quotations WHERE id = ?', [id]);
      const qtn = qtnResult.rows[0] as Pick<Quotation, 'status'> | undefined;

      if (!qtn) {
         return { success: false, message: "Quotation not found." };
      }
      // Prevent deleting accepted quotations? Adapt based on business rules.
      if (qtn.status === 'Accepted') {
          return { success: false, message: "Cannot delete an accepted quotation. Consider converting or cancelling." };
      }

      // Ensure primary key 'id' is indexed
      const deleteResult = await runSqlQuery('DELETE FROM quotations WHERE id = ?', [id]);
      if (deleteResult.rowsAffected === 0) {
         return { success: false, message: "Quotation not found or already deleted." };
      }

      revalidatePath('/sales/quotations');
      return { success: true, message: "Quotation deleted successfully" };
    } catch (error) {
      console.error("Failed to delete quotation:", error);
      return { success: false, message: "Database error occurred while deleting quotation.", error: error instanceof Error ? error.message : String(error) };
    }
}


// Convert Quotation to Sales Order
// Optimization: Consider using a database transaction
export async function convertQuotationToSalesOrder(quotationId: string) {
    if (!quotationId) {
        return { success: false, message: "Quotation ID is required" };
    }

    try {
        // Fetch Quotation Data
        // Ensure 'id' is indexed
        const qtnResult = await runSqlQuery('SELECT * FROM quotations WHERE id = ?', [quotationId]);
        const quotation = qtnResult.rows[0] as Quotation | undefined;

        if (!quotation) {
            return { success: false, message: "Quotation not found" };
        }

        if (quotation.status !== 'Accepted') {
             return { success: false, message: "Only 'Accepted' quotations can be converted." };
        }

        // Create Sales Order (addSalesOrder handles its own DB operation)
        const salesOrderFormData = new FormData();
        salesOrderFormData.append('customer', quotation.customer);
        // Default order date to today, delivery date maybe needs logic?
        salesOrderFormData.append('orderDate', format(new Date(), 'yyyy-MM-dd'));
        // Example: Delivery date 7 days from today
        const deliveryDate = new Date();
        deliveryDate.setDate(deliveryDate.getDate() + 7);
        salesOrderFormData.append('deliveryDate', format(deliveryDate, 'yyyy-MM-dd'));
        if (quotation.total !== null) {
             salesOrderFormData.append('total', quotation.total.toString());
        }
        salesOrderFormData.append('status', 'To Deliver and Bill'); // Default status for new SO from QTN

        const addOrderResult = await addSalesOrder(salesOrderFormData);

        if (!addOrderResult.success) {
             console.error("Failed to create Sales Order during conversion:", addOrderResult.errors || addOrderResult.error);
             return { success: false, message: `Failed to create Sales Order: ${addOrderResult.message}` };
        }

        // Optionally update Quotation status (e.g., to 'Converted' or similar if needed)
        // Ensure 'id' and 'status' are indexed
        // await runSqlQuery('UPDATE quotations SET status = ? WHERE id = ?', ['Converted', quotationId]);


        // Revalidate paths
        revalidatePath('/sales/quotations');
        revalidatePath('/sales/sales-orders');

        return { success: true, message: "Quotation converted to Sales Order successfully", salesOrderId: addOrderResult.id };

    } catch (error) {
        console.error("Failed to convert quotation:", error);
        // Consider rolling back Sales Order creation if UPDATE fails (requires transaction)
        return { success: false, message: "Database error occurred during conversion.", error: error instanceof Error ? error.message : String(error) };
    }
}


// TODO: Implement updateQuotation function
// Ensure UPDATE uses WHERE id = ? and updates only necessary fields
// Function signature should be async function updateQuotation(...) { ... }
