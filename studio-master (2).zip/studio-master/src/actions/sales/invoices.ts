'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { format, parseISO, isValid } from 'date-fns';
import { invoiceStatusOptions, type InvoiceStatus } from '@/types/sales'; // Import from types file

// Helper function, ensure consistency across actions
const validateAndFormatDate = (dateString: unknown): string | null => {
    if (typeof dateString !== 'string' || !dateString) return null;
    try {
         if (/^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
             const parsed = parseISO(dateString);
             if (isValid(parsed)) return format(parsed, 'yyyy-MM-dd');
         }
        const parsed = new Date(dateString);
        if (isValid(parsed)) return format(parsed, 'yyyy-MM-dd');
    } catch (e) { }
    return null;
};

const InvoiceSchema = z.object({
  id: z.string().optional(),
  customer: z.string().min(1, "Customer name is required"),
  postingDate: z.string().refine(val => validateAndFormatDate(val) !== null, {
      message: "Invalid posting date format (YYYY-MM-DD required)"
  }),
  dueDate: z.string().refine(val => validateAndFormatDate(val) !== null, {
      message: "Invalid due date format (YYYY-MM-DD required)"
  }),
  grandTotal: z.number().positive("Grand total must be positive"),
  // Outstanding amount can be zero or positive
  outstandingAmount: z.number().min(0, "Outstanding amount cannot be negative"),
  status: z.enum(invoiceStatusOptions), // Use imported enum
});

// Export the inferred type if needed by other server components/actions
// Client components can define their own types or import if this file structure allows
export type Invoice = z.infer<typeof InvoiceSchema>;

// Get all invoices
// Optimization: Add pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getInvoices(): Promise<Invoice[]> {
  try {
    // Removed UPDATE statement to avoid side effects during GET
    // await runSqlQuery(
    //     `UPDATE invoices SET status = 'Overdue' WHERE status IN ('Unpaid', 'Partly Paid') AND dueDate < ?`,
    //     [format(new Date(), 'yyyy-MM-dd')]
    // );

    // Ensure 'postingDate' and 'id' columns are indexed for sorting
    const result = await runSqlQuery('SELECT * FROM invoices ORDER BY postingDate DESC, id DESC');
    // Format/validate dates and numbers on retrieval
     return (result.rows as any[]).map(row => ({
         ...row,
         grandTotal: row.grandTotal != null ? Number(row.grandTotal) : 0,
         outstandingAmount: row.outstandingAmount != null ? Number(row.outstandingAmount) : 0,
         // Ensure dates are valid YYYY-MM-DD strings
         postingDate: validateAndFormatDate(row.postingDate) || format(new Date(), 'yyyy-MM-dd'),
         dueDate: validateAndFormatDate(row.dueDate) || format(new Date(), 'yyyy-MM-dd'),
         status: row.status as InvoiceStatus, // Assert type if needed
     }));
  } catch (error) {
    console.error("Failed to fetch invoices:", error);
    // Consider throwing the error or returning a more specific error indicator
    // instead of just an empty array if the caller needs to distinguish.
    return [];
  }
}

// Add a new invoice
export async function addInvoice(formData: FormData): Promise<{ success: boolean; message: string; id?: string; errors?: Record<string, string[]> | z.ZodIssue[]; error?: unknown }> {
    const rawData = Object.fromEntries(formData.entries());

    // Convert numbers or set to 0
    rawData.grandTotal = parseFloat(rawData.grandTotal as string || '0');
    rawData.outstandingAmount = parseFloat(rawData.outstandingAmount as string || '0');

    if (isNaN(rawData.grandTotal as number) || rawData.grandTotal <= 0) {
        return { success: false, message: "Validation failed", errors: { grandTotal: ["Grand total must be a positive number."] } };
    }
    if (isNaN(rawData.outstandingAmount as number) || rawData.outstandingAmount < 0) {
         rawData.outstandingAmount = rawData.grandTotal; // Default outstanding to total if invalid negative value
    }

    // Validate and format dates
     const formattedPostingDate = validateAndFormatDate(rawData.postingDate);
     const formattedDueDate = validateAndFormatDate(rawData.dueDate);

     if (!formattedPostingDate) {
        return { success: false, message: "Validation failed", errors: { postingDate: ["Invalid posting date format. Use YYYY-MM-DD."] } };
     }
      if (!formattedDueDate) {
         return { success: false, message: "Validation failed", errors: { dueDate: ["Invalid due date format. Use YYYY-MM-DD."] } };
     }

      rawData.postingDate = formattedPostingDate;
      rawData.dueDate = formattedDueDate;

      // Default status if missing or invalid
      if (!invoiceStatusOptions.includes(rawData.status as any)) {
          rawData.status = 'Unpaid'; // Sensible default for new invoices
      }

      // Ensure outstanding is not more than grand total
      if (rawData.outstandingAmount > rawData.grandTotal) {
          rawData.outstandingAmount = rawData.grandTotal;
      }


    const validatedData = InvoiceSchema.omit({ id: true }).safeParse(rawData);

    if (!validatedData.success) {
        console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
        return {
            success: false,
            message: "Validation failed",
            errors: validatedData.error.flatten().fieldErrors,
        };
    }

    const data = validatedData.data;
    // Optimization: Use crypto.randomUUID()
    const newId = `INV-${Date.now()}-${crypto.randomUUID().slice(0, 5)}`;

    try {
        // Ensure primary key 'id' is indexed
        await runSqlQuery(
        'INSERT INTO invoices (id, customer, postingDate, dueDate, grandTotal, outstandingAmount, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [
            newId,
            data.customer,
            data.postingDate,
            data.dueDate,
            data.grandTotal,
            data.outstandingAmount, // Use the validated/adjusted outstanding amount
            data.status,
        ]
        );
        revalidatePath('/sales/invoices');
        return { success: true, message: "Invoice added successfully", id: newId };
    } catch (error) {
        console.error("Failed to add invoice:", error);
        return { success: false, message: "Database error occurred while adding invoice.", error: error instanceof Error ? error.message : String(error) };
    }
}

// Delete an invoice
export async function deleteInvoice(id: string): Promise<{ success: boolean; message: string; error?: unknown }> {
    if (!id) {
      return { success: false, message: "Invoice ID is required" };
    }
    try {
        // Maybe prevent deletion if paid/partly paid? Or only allow for Draft/Cancelled?
        // Ensure 'id' and 'status' columns are indexed if performing checks
        const invResult = await runSqlQuery('SELECT status FROM invoices WHERE id = ?', [id]);
        const inv = invResult.rows[0] as Pick<Invoice, 'status'> | undefined;

        if (!inv) {
            return { success: false, message: "Invoice not found." };
        }

        // Allow deletion unless Paid? Adapt rule as needed.
        if (inv && inv.status === 'Paid') {
             return { success: false, message: `Cannot delete a 'Paid' invoice. Consider cancelling first if necessary.` };
        }

        // Ensure primary key 'id' is indexed
        const deleteResult = await runSqlQuery('DELETE FROM invoices WHERE id = ?', [id]);
        if (deleteResult.rowsAffected === 0) {
            return { success: false, message: "Invoice not found or already deleted." };
        }

        revalidatePath('/sales/invoices');
        return { success: true, message: "Invoice deleted successfully" };
    } catch (error) {
        console.error("Failed to delete invoice:", error);
        return { success: false, message: "Database error occurred while deleting invoice.", error: error instanceof Error ? error.message : String(error) };
    }
}

// Cancel an invoice
export async function cancelInvoice(id: string): Promise<{ success: boolean; message: string; error?: unknown }> {
    if (!id) {
        return { success: false, message: "Invoice ID is required" };
    }
    try {
        // Check if already cancelled or paid
        // Ensure 'id' and 'status' columns are indexed
        const invResult = await runSqlQuery('SELECT status FROM invoices WHERE id = ?', [id]);
        const inv = invResult.rows[0] as Pick<Invoice, 'status'> | undefined;

        if (!inv) {
            return { success: false, message: "Invoice not found" };
        }
        if (inv.status === 'Paid' || inv.status === 'Cancelled') {
            return { success: false, message: `Invoice is already ${inv.status}.` };
        }

        // Ensure 'id', 'status', 'outstandingAmount' columns are indexed
        const updateResult = await runSqlQuery('UPDATE invoices SET status = ?, outstandingAmount = 0 WHERE id = ?', ['Cancelled', id]);
        if (updateResult.rowsAffected === 0) {
             return { success: false, message: "Invoice not found or status not updated." };
        }

        revalidatePath('/sales/invoices');
        return { success: true, message: "Invoice cancelled successfully" };
    } catch (error) {
        console.error("Failed to cancel invoice:", error);
        return { success: false, message: "Database error occurred while cancelling invoice.", error: error instanceof Error ? error.message : String(error) };
    }
}


// Record Payment for an Invoice
const PaymentSchema = z.object({
  invoiceId: z.string().min(1),
  paymentAmount: z.number().positive("Payment amount must be positive"),
  paymentDate: z.string().refine(val => validateAndFormatDate(val) !== null, { // Reuse date validation
      message: "Invalid payment date format (YYYY-MM-DD required)"
  }).optional(), // Make date optional, default to today if not provided
});

export async function recordInvoicePayment(formData: FormData): Promise<{ success: boolean; message: string; errors?: Record<string, string[]> | z.ZodIssue[]; error?: unknown }> {
    const rawData = Object.fromEntries(formData.entries());

    // Convert amount
    const rawPaymentAmount = rawData.paymentAmount;
    if (rawPaymentAmount === null || rawPaymentAmount === '' || isNaN(parseFloat(rawPaymentAmount as string)) || parseFloat(rawPaymentAmount as string) <= 0) {
        return { success: false, message: "Invalid or non-positive payment amount." };
    }
    rawData.paymentAmount = parseFloat(rawPaymentAmount as string);

     // Validate/format date, default to today
     const paymentDateInput = rawData.paymentDate as string | undefined;
     const formattedPaymentDate = validateAndFormatDate(paymentDateInput);
     rawData.paymentDate = formattedPaymentDate || format(new Date(), 'yyyy-MM-dd');


    const validatedData = PaymentSchema.safeParse(rawData);

    if (!validatedData.success) {
         console.error("Payment Validation failed:", validatedData.error.flatten().fieldErrors);
        return {
            success: false,
            message: "Payment validation failed",
            errors: validatedData.error.flatten().fieldErrors,
        };
    }

    const { invoiceId, paymentAmount } = validatedData.data;

    try {
        // Fetch current invoice details
        // Ensure 'id' column is indexed
        const invResult = await runSqlQuery('SELECT grandTotal, outstandingAmount, status FROM invoices WHERE id = ?', [invoiceId]);
        const invoice = invResult.rows[0] as Pick<Invoice, 'grandTotal' | 'outstandingAmount' | 'status'> | undefined;

        if (!invoice) {
            return { success: false, message: "Invoice not found." };
        }

        if (invoice.status === 'Paid' || invoice.status === 'Cancelled') {
            return { success: false, message: `Cannot record payment for ${invoice.status} invoice.` };
        }

        const currentOutstanding = Number(invoice.outstandingAmount);
        const payment = Number(paymentAmount);

        if (payment > currentOutstanding + 0.001) { // Add tolerance for float comparison
            return { success: false, message: "Payment amount cannot exceed outstanding amount." };
        }

        const newOutstanding = Math.max(0, currentOutstanding - payment); // Ensure not negative
        const newStatus = newOutstanding <= 0.001 ? 'Paid' : 'Partly Paid'; // Use tolerance

        // TODO: In a real system, you'd insert into a Payment Entries table here.
        // For this example, we just update the invoice.
        // Ensure 'id', 'outstandingAmount', 'status' columns are indexed
        const updateResult = await runSqlQuery(
            'UPDATE invoices SET outstandingAmount = ?, status = ? WHERE id = ?',
            [newOutstanding.toFixed(2), newStatus, invoiceId] // Store outstanding amount with fixed precision
        );

         if (updateResult.rowsAffected === 0) {
             return { success: false, message: "Failed to update invoice during payment recording." };
         }

        revalidatePath('/sales/invoices');
        return { success: true, message: "Payment recorded successfully." };

    } catch (error) {
        console.error("Failed to record payment:", error);
        return { success: false, message: "Database error occurred while recording payment.", error: error instanceof Error ? error.message : String(error) };
    }
}


// TODO: Implement updateInvoice function
// Ensure UPDATE uses WHERE id = ? and updates only necessary fields
// Function signature should be async function updateInvoice(...) { ... }
export async function updateInvoice(id: string, formData: FormData): Promise<{ success: boolean; message: string; errors?: Record<string, string[]> | z.ZodIssue[]; error?: unknown }> {
    // Implementation needed
    return { success: false, message: "Update functionality not implemented." };
}

// --- Placeholder Actions (Not Implemented) ---

// Function to cancel an invoice (already partially implemented above)
// Function to create a payment entry from an invoice (partially in recordInvoicePayment)

// Placeholder for getting invoice items (would involve another table)
export async function getInvoiceItems(invoiceId: string): Promise<any[]> {
    // Implementation needed - requires an invoice_items table
    return [];
}