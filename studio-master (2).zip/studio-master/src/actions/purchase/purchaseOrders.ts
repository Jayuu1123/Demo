
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { format, parseISO, isValid } from 'date-fns';
import { purchaseOrderStatusOptions, type PurchaseOrderStatus } from '@/types/purchase'; // Import from types file

// Define status options for reuse and clarity - MOVED TO types/purchase.ts
// export const purchaseOrderStatusOptions = ['Draft', 'Ordered', 'Partly Received', 'Received', 'Completed', 'Cancelled'] as const;
// export type PurchaseOrderStatus = typeof purchaseOrderStatusOptions[number]; // MOVED TO types/purchase.ts


// Helper to validate and format date strings (reusable)
const validateAndFormatDate = (dateString: unknown): string | null => {
    if (typeof dateString !== 'string' || !dateString) return null; // Check for empty string too
    try {
        // Prioritize parsing YYYY-MM-DD
        if (/^\d{4}-\d{2}-\d{2}$/.test(dateString)) {
           const parsed = parseISO(dateString);
            if (isValid(parsed)) return format(parsed, 'yyyy-MM-dd');
        }
        // Fallback for other potential formats (less reliable)
        const parsed = new Date(dateString);
        if (isValid(parsed)) return format(parsed, 'yyyy-MM-dd');
    } catch (e) { /* Ignore parsing errors */ }
    return null;
};

// Define the schema for a Purchase Order
const PurchaseOrderSchema = z.object({
  id: z.string().optional(),
  vendor: z.string().min(1, "Vendor name is required"),
  orderDate: z.string().refine(val => validateAndFormatDate(val) !== null, {
      message: "Invalid order date format (YYYY-MM-DD required)"
  }),
  expectedDeliveryDate: z.string().refine(val => validateAndFormatDate(val) !== null, {
      message: "Invalid expected delivery date format (YYYY-MM-DD required)"
  }),
  totalAmount: z.number().positive("Total amount must be positive").optional().nullable(),
  status: z.enum(purchaseOrderStatusOptions), // Use imported enum
  // Consider adding items array later
  // items: z.array(z.object({...})).optional(),
});

export type PurchaseOrder = z.infer<typeof PurchaseOrderSchema>;

// Function to get all purchase orders
// Optimization: Add pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getPurchaseOrders(): Promise<PurchaseOrder[]> {
  try {
    // Optional: Update status based on expected delivery date for 'Ordered' status?
    // Consider if this logic should be here or triggered elsewhere (e.g., a cron job)
    // Ensure indexes on 'status' and 'expectedDeliveryDate' if implementing this
    // await runSqlQuery(
    //     `UPDATE purchase_orders SET status = 'Delayed' WHERE status = 'Ordered' AND expectedDeliveryDate < ?`,
    //     [format(new Date(), 'yyyy-MM-dd')]
    // );

    // Ensure 'orderDate', 'id', and potentially 'status' columns are indexed
    const result = await runSqlQuery('SELECT * FROM purchase_orders ORDER BY orderDate DESC, id DESC');
    // Format/validate dates and numbers on retrieval
    return (result.rows as any[]).map(row => ({
        ...row,
        totalAmount: row.totalAmount != null ? Number(row.totalAmount) : null,
        // Ensure dates are valid YYYY-MM-DD strings, default if invalid
        orderDate: validateAndFormatDate(row.orderDate) || format(new Date(), 'yyyy-MM-dd'),
        expectedDeliveryDate: validateAndFormatDate(row.expectedDeliveryDate) || format(new Date(), 'yyyy-MM-dd'),
        status: row.status as PurchaseOrderStatus, // Assert type
    }));
  } catch (error) {
    console.error("Failed to fetch purchase orders:", error);
    return [];
  }
}

// Function to add a new purchase order
export async function addPurchaseOrder(formData: FormData): Promise<{ success: boolean; message: string; id?: string; errors?: Record<string, string[]> | z.ZodIssue[] }> {
    const rawData = Object.fromEntries(formData.entries());

    // Convert totalAmount to number or null
    let totalAmountValue: number | null = null;
    const rawAmount = rawData.totalAmount;
    if (rawAmount !== '' && rawAmount !== undefined && rawAmount !== null) {
         const parsedAmount = parseFloat(rawAmount as string);
         if (!isNaN(parsedAmount) && parsedAmount > 0) { // Ensure positive
              totalAmountValue = parsedAmount;
         } else {
            // Return specific validation error for amount
            return { success: false, message: "Validation failed", errors: { totalAmount: ["Amount must be a positive number."] } };
         }
    }
    rawData.totalAmount = totalAmountValue;

    // Validate and format dates
    const formattedOrderDate = validateAndFormatDate(rawData.orderDate);
    const formattedExpectedDeliveryDate = validateAndFormatDate(rawData.expectedDeliveryDate);

    if (!formattedOrderDate) {
        return { success: false, message: "Validation failed", errors: { orderDate: ["Invalid order date format. Use YYYY-MM-DD."] } };
    }
    if (!formattedExpectedDeliveryDate) {
        return { success: false, message: "Validation failed", errors: { expectedDeliveryDate: ["Invalid expected delivery date format. Use YYYY-MM-DD."] } };
    }

    rawData.orderDate = formattedOrderDate;
    rawData.expectedDeliveryDate = formattedExpectedDeliveryDate;

    // Default status if missing or invalid
    if (!purchaseOrderStatusOptions.includes(rawData.status as any)) {
        rawData.status = 'Draft';
    }

    const validatedData = PurchaseOrderSchema.omit({ id: true }).safeParse(rawData);

    if (!validatedData.success) {
        console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
        return {
            success: false,
            message: "Validation failed",
            errors: validatedData.error.flatten().fieldErrors, // Return Zod errors directly
        };
    }

    const data = validatedData.data;
    // Optimization: Use crypto.randomUUID()
    const newId = `PO-${Date.now()}-${crypto.randomUUID().slice(0, 7)}`;

    try {
        // Ensure primary key 'id' is indexed
         await runSqlQuery(
             `INSERT INTO purchase_orders (id, vendor, orderDate, expectedDeliveryDate, totalAmount, status)
              VALUES (?, ?, ?, ?, ?, ?)`,
             [
                 newId,
                 data.vendor,
                 data.orderDate,
                 data.expectedDeliveryDate,
                 data.totalAmount, // Already validated number or null
                 data.status,
             ]
         );

        revalidatePath('/purchase/purchase-orders');
        return { success: true, message: "Purchase Order added successfully", id: newId };
    } catch (error) {
        console.error("Failed to add purchase order:", error);
        return { success: false, message: "Database error occurred while adding purchase order.", error: error instanceof Error ? error.message : String(error) };
    }
}


// Function to delete a purchase order
export async function deletePurchaseOrder(id: string): Promise<{ success: boolean; message: string }> {
   if (!id) {
     return { success: false, message: "Purchase Order ID is required" };
   }
   try {
       // Consider checks: Can't delete if received or billed?
       // Ensure 'id' and 'status' columns are indexed if performing this check often
       const orderResult = await runSqlQuery('SELECT status FROM purchase_orders WHERE id = ?', [id]);
       const order = orderResult.rows[0] as Pick<PurchaseOrder, 'status'> | undefined;

        if (!order) {
             return { success: false, message: "Purchase Order not found." };
        }

       if (order && ['Received', 'Completed', 'Partly Received'].includes(order.status)) {
             // Maybe allow deletion but warn, or prevent entirely
              return { success: false, message: `Cannot delete order with status '${order.status}'. Consider cancelling first.` };
       }

        // Ensure primary key 'id' is indexed
       const deleteResult = await runSqlQuery('DELETE FROM purchase_orders WHERE id = ?', [id]);
        if (deleteResult.rowsAffected === 0) {
             // Should have been caught by the SELECT earlier, but double-check
             return { success: false, message: "Purchase Order not found or already deleted." };
        }

       revalidatePath('/purchase/purchase-orders');
       return { success: true, message: "Purchase Order deleted successfully" };
   } catch (error) {
       console.error("Failed to delete purchase order:", error);
       return { success: false, message: "Database error occurred while deleting purchase order.", error: error instanceof Error ? error.message : String(error) };
   }
}

// --- Placeholder Actions (Implement Later) ---

// export async function updatePurchaseOrder(id: string, formData: FormData) { ... }
// Ensure UPDATE uses WHERE id = ? and updates only necessary fields
// Function signature should be async function updatePurchaseOrder(...) { ... }

// export async function cancelPurchaseOrder(id: string) { ... }
// Ensure UPDATE uses WHERE id = ? and indexes 'status'
// Function signature should be async function cancelPurchaseOrder(...) { ... }

// export async function receivePurchaseOrderItems(id: string, receivedItemsData: any) { ... }
// This would likely involve multiple tables and transactions
// Function signature should be async function receivePurchaseOrderItems(...) { ... }

// export async function createBillFromPurchaseOrder(id: string) { ... }
// This would likely involve INSERT into 'bills' table and potentially UPDATE PO status
// Function signature should be async function createBillFromPurchaseOrder(...) { ... }
