
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

const ItemGroupSchema = z.object({
  id: z.string().optional(), // Optional for creation
  name: z.string().min(1, "Name is required"),
  parentGroup: z.string().optional(),
  isGroup: z.boolean().default(true),
  description: z.string().optional(),
});

export type ItemGroup = z.infer<typeof ItemGroupSchema>;

// Get all item groups
// Optimization: Consider adding pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getItemGroups(): Promise<ItemGroup[]> {
  try {
    // Ensure 'name' column is indexed for faster sorting
    const result = await runSqlQuery('SELECT * FROM item_groups ORDER BY name');
    // Ensure boolean conversion for isGroup
    return (result.rows as any[]).map(row => ({
        ...row,
        isGroup: Boolean(row.isGroup), // SQLite might store boolean as 0 or 1
    }));
  } catch (error) {
    console.error("Failed to fetch item groups:", error);
    return [];
  }
}

// Add a new item group
export async function addItemGroup(formData: FormData) {
   const rawData = Object.fromEntries(formData.entries());

   // Handle checkbox value for isGroup
   rawData.isGroup = rawData.isGroup === 'on'; // HTML forms submit 'on' for checked checkboxes

   const validatedData = ItemGroupSchema.omit({ id: true }).safeParse(rawData);


  if (!validatedData.success) {
    console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
     return {
         success: false,
         message: "Validation failed",
         errors: validatedData.error.flatten().fieldErrors,
     };
  }

   const data = validatedData.data;
   // Optimization: Use crypto.randomUUID()
   const newId = `group-${Date.now()}-${crypto.randomUUID().slice(0, 7)}`;

  try {
    // Ensure primary key 'id' is indexed
    await runSqlQuery(
      'INSERT INTO item_groups (id, name, parentGroup, isGroup, description) VALUES (?, ?, ?, ?, ?)',
      [
        newId,
        data.name,
        data.parentGroup || 'All Item Groups', // Default parent if not provided
        data.isGroup ? 1 : 0, // Store boolean as 1 or 0 in SQLite
        data.description || null,
      ]
    );
    revalidatePath('/crm/item-groups');
     return { success: true, message: "Item group added successfully", id: newId };
  } catch (error) {
    console.error("Failed to add item group:", error);
     return { success: false, message: "Database error occurred while adding item group.", error: error instanceof Error ? error.message : String(error) };
  }
}

// Delete an item group
export async function deleteItemGroup(id: string) {
   if (!id) {
     return { success: false, message: "Item Group ID is required" };
   }
  try {
    // Ensure primary key 'id' is indexed
    // Consider implications: What happens to items in this group? Set FK to NULL or prevent deletion?
    const result = await runSqlQuery('DELETE FROM item_groups WHERE id = ?', [id]);
    if (result.rowsAffected === 0) {
        return { success: false, message: "Item group not found." };
    }
    revalidatePath('/crm/item-groups');
    return { success: true, message: "Item group deleted successfully" };
  } catch (error) {
    console.error("Failed to delete item group:", error);
     return { success: false, message: "Database error occurred while deleting item group.", error: error instanceof Error ? error.message : String(error) };
  }
}

// TODO: Implement updateItemGroup function
// Ensure UPDATE uses WHERE id = ? and updates only necessary fields
