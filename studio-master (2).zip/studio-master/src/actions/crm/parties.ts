
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

const PartySchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Name is required"),
  type: z.enum(['Customer', 'Supplier']),
  territory: z.string().optional(),
  status: z.enum(['Active', 'On Hold', 'Disabled']),
  email: z.string().email("Invalid email address").optional().or(z.literal('')), // Allow empty string or valid email
});

export type Party = z.infer<typeof PartySchema>;

// Get all parties
// Optimization: Add pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getParties(): Promise<Party[]> {
  try {
    // Ensure 'name' column is indexed for faster sorting
    const result = await runSqlQuery('SELECT * FROM parties ORDER BY name');
    return result.rows as Party[];
  } catch (error) {
    console.error("Failed to fetch parties:", error);
    return [];
  }
}

// Add a new party
export async function addParty(formData: FormData) {
  const rawData = Object.fromEntries(formData.entries());
  const validatedData = PartySchema.omit({ id: true }).safeParse(rawData);

  if (!validatedData.success) {
    console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
    return {
      success: false,
      message: "Validation failed",
      errors: validatedData.error.flatten().fieldErrors,
    };
  }

  const data = validatedData.data;
  // Optimization: Use crypto.randomUUID()
  const newId = `party-${Date.now()}-${crypto.randomUUID().slice(0, 7)}`;

  try {
    // Ensure primary key 'id' is indexed
    await runSqlQuery(
      'INSERT INTO parties (id, name, type, territory, status, email) VALUES (?, ?, ?, ?, ?, ?)',
      [
        newId,
        data.name,
        data.type,
        data.territory || null,
        data.status,
        data.email || null, // Ensure email is stored as null if empty/invalid
      ]
    );
    revalidatePath('/crm/parties');
    return { success: true, message: "Party added successfully", id: newId };
  } catch (error) {
    console.error("Failed to add party:", error);
    return { success: false, message: "Database error occurred while adding party.", error: error instanceof Error ? error.message : String(error) };
  }
}

// Delete a party
export async function deleteParty(id: string) {
  if (!id) {
    return { success: false, message: "Party ID is required" };
  }
  try {
    // Ensure primary key 'id' is indexed
    // Consider adding checks here for related records (e.g., contacts, orders)
    // before allowing deletion, or handle cascading deletes/set null in the DB schema.
    const result = await runSqlQuery('DELETE FROM parties WHERE id = ?', [id]);
     if (result.rowsAffected === 0) {
        return { success: false, message: "Party not found." };
     }
    revalidatePath('/crm/parties');
    return { success: true, message: "Party deleted successfully" };
  } catch (error) {
    console.error("Failed to delete party:", error);
    return { success: false, message: "Database error occurred while deleting party.", error: error instanceof Error ? error.message : String(error) };
  }
}

// TODO: Implement updateParty function
// Ensure UPDATE uses WHERE id = ? and updates only necessary fields
