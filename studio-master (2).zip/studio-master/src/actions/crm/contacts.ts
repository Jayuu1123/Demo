
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

const ContactSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Name is required"),
  company: z.string().optional(),
  title: z.string().optional(),
  email: z.string().email("Invalid email address").optional().or(z.literal('')),
  phone: z.string().optional(),
});

export type Contact = z.infer<typeof ContactSchema>;

// Get all contacts
// Optimization: Consider adding pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed on the list page
export async function getContacts(): Promise<Contact[]> {
  try {
    // Ensure 'name' column is indexed for faster sorting
    const result = await runSqlQuery('SELECT * FROM contacts ORDER BY name');
    return result.rows as Contact[];
  } catch (error) {
    console.error("Failed to fetch contacts:", error);
    return [];
  }
}

// Add a new contact
export async function addContact(formData: FormData) {
  const rawData = Object.fromEntries(formData.entries());
  const validatedData = ContactSchema.omit({ id: true }).safeParse(rawData);

  if (!validatedData.success) {
    console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
    return {
      success: false,
      message: "Validation failed",
      errors: validatedData.error.flatten().fieldErrors,
    };
  }

  const data = validatedData.data;
  // Optimization: Using crypto.randomUUID() is generally better for unique IDs
  const newId = `contact-${Date.now()}-${crypto.randomUUID().slice(0, 6)}`;

  try {
    // Ensure primary key 'id' is indexed for efficient INSERT/DELETE
    await runSqlQuery(
      'INSERT INTO contacts (id, name, company, title, email, phone) VALUES (?, ?, ?, ?, ?, ?)',
      [
        newId,
        data.name,
        data.company || null,
        data.title || null,
        data.email || null, // Ensure email is stored as null if empty/invalid after validation
        data.phone || null,
      ]
    );
    revalidatePath('/crm/contacts');
    return { success: true, message: "Contact added successfully", id: newId };
  } catch (error) {
    console.error("Failed to add contact:", error);
    // Provide more specific error feedback if possible (e.g., unique constraint violation)
    return { success: false, message: "Database error occurred while adding contact.", error: error instanceof Error ? error.message : String(error) };
  }
}

// Delete a contact
export async function deleteContact(id: string) {
  if (!id) {
    return { success: false, message: "Contact ID is required" };
  }
  try {
    // Ensure primary key 'id' is indexed
    const result = await runSqlQuery('DELETE FROM contacts WHERE id = ?', [id]);
     if (result.rowsAffected === 0) {
        return { success: false, message: "Contact not found." };
     }
    revalidatePath('/crm/contacts');
    return { success: true, message: "Contact deleted successfully" };
  } catch (error) {
    console.error("Failed to delete contact:", error);
    return { success: false, message: "Database error occurred while deleting contact.", error: error instanceof Error ? error.message : String(error) };
  }
}

// TODO: Implement updateContact function
// Ensure UPDATE uses WHERE id = ? and potentially updates only changed fields for efficiency
