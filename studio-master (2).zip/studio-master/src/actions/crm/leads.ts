
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { addContact } from './contacts'; // Import addContact action

const LeadSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Name is required"),
  company: z.string().optional(),
  email: z.string().email("Invalid email address").optional().or(z.literal('')),
  phone: z.string().optional(),
  status: z.enum(['New', 'Contacted', 'Qualified', 'Lost', 'Converted']), // Added 'Converted'
});

export type Lead = z.infer<typeof LeadSchema>;

// Get all leads (excluding converted ones by default)
// Optimization: Add pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getLeads(includeConverted = false): Promise<Lead[]> {
  try {
    let sql = 'SELECT * FROM leads';
    const args: any[] = []; // Explicitly type args
    if (!includeConverted) {
        sql += ' WHERE status != ?';
        args.push('Converted');
    }
    // Ensure 'name' and 'status' columns are indexed for faster querying/sorting
    sql += ' ORDER BY name';

    const result = await runSqlQuery(sql, args);
    return result.rows as Lead[];
  } catch (error) {
    console.error("Failed to fetch leads:", error);
    return [];
  }
}

// Add a new lead
export async function addLead(formData: FormData) {
  const rawData = Object.fromEntries(formData.entries());
   // Default status to 'New' if not provided or invalid
   if (!LeadSchema.shape.status.options.includes(rawData.status as any)) {
       rawData.status = 'New';
   }
  const validatedData = LeadSchema.omit({ id: true }).safeParse(rawData);


  if (!validatedData.success) {
    console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
     return {
         success: false,
         message: "Validation failed",
         errors: validatedData.error.flatten().fieldErrors,
     };
  }

   const data = validatedData.data;
   // Optimization: Use crypto.randomUUID()
   const newId = `lead-${Date.now()}-${crypto.randomUUID().slice(0, 7)}`;

  try {
    // Ensure primary key 'id' is indexed
    await runSqlQuery(
      'INSERT INTO leads (id, name, company, email, phone, status) VALUES (?, ?, ?, ?, ?, ?)',
      [
        newId,
        data.name,
        data.company || null,
        data.email || null,
        data.phone || null,
        data.status, // Use validated status
      ]
    );
    revalidatePath('/crm/leads');
     return { success: true, message: "Lead added successfully", id: newId };
  } catch (error) {
    console.error("Failed to add lead:", error);
     return { success: false, message: "Database error occurred while adding lead.", error: error instanceof Error ? error.message : String(error) };
  }
}

// Delete a lead
export async function deleteLead(id: string) {
   if (!id) {
     return { success: false, message: "Lead ID is required" };
   }
  try {
    // Ensure primary key 'id' is indexed
    const result = await runSqlQuery('DELETE FROM leads WHERE id = ?', [id]);
    if (result.rowsAffected === 0) {
        return { success: false, message: "Lead not found." };
    }
    revalidatePath('/crm/leads');
     return { success: true, message: "Lead deleted successfully" };
  } catch (error) {
    console.error("Failed to delete lead:", error);
     return { success: false, message: "Database error occurred while deleting lead.", error: error instanceof Error ? error.message : String(error) };
  }
}

// Convert a lead to a contact
// Optimization: Consider using a database transaction to ensure atomicity
export async function convertLeadToContact(leadId: string) {
    if (!leadId) {
        return { success: false, message: "Lead ID is required" };
    }

    try {
        // Ensure 'id' is indexed
        const leadResult = await runSqlQuery('SELECT * FROM leads WHERE id = ?', [leadId]);
        const lead = leadResult.rows[0] as Lead | undefined;

        if (!lead) {
            return { success: false, message: "Lead not found" };
        }

        if (lead.status === 'Converted') {
             return { success: false, message: "Lead already converted" };
        }

        // Create contact (addContact handles its own DB operation)
        const contactFormData = new FormData();
        contactFormData.append('name', lead.name);
        if (lead.company) contactFormData.append('company', lead.company);
        if (lead.email) contactFormData.append('email', lead.email);
        if (lead.phone) contactFormData.append('phone', lead.phone);
        // contactFormData.append('title', 'Converted Lead'); // Optional

        const addContactResult = await addContact(contactFormData);

        if (!addContactResult.success) {
             console.error("Failed to add contact during lead conversion:", addContactResult.errors || addContactResult.error);
             return { success: false, message: `Failed to create contact: ${addContactResult.message}`, error: addContactResult.error };
        }

        // Update lead status (ensure 'id' and 'status' are indexed)
        await runSqlQuery('UPDATE leads SET status = ? WHERE id = ?', ['Converted', leadId]);

        // Revalidate paths
        revalidatePath('/crm/leads');
        revalidatePath('/crm/contacts');

        return { success: true, message: "Lead converted to contact successfully", contactId: addContactResult.id };

    } catch (error) {
        console.error("Failed to convert lead:", error);
        // Consider rolling back contact creation if UPDATE fails (requires transaction)
        return { success: false, message: "Database error occurred during conversion.", error: error instanceof Error ? error.message : String(error) };
    }
}


// TODO: Implement updateLead function
// Ensure UPDATE uses WHERE id = ? and updates only necessary fields
