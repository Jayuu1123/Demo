
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

const ItemSchema = z.object({
    id: z.string().optional(), // Optional for creation, generated if missing
    name: z.string().min(1, "Name is required"),
    itemGroup: z.string().optional(), // Consider foreign key constraint to item_groups(id)
    description: z.string().optional(),
    stockUom: z.string().optional(),
    valuationRate: z.number().optional(), // Ensure type consistency
    imageHint: z.string().optional(),
});

export type Item = z.infer<typeof ItemSchema>;

// Get all items
// Optimization: Add pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getItems(): Promise<Item[]> {
  try {
    // Ensure 'name' column is indexed for faster sorting
    const result = await runSqlQuery('SELECT * FROM items ORDER BY name');
    return (result.rows as Item[]).map(row => ({
        ...row,
        // Ensure valuationRate is a number, default to null if null/undefined
        valuationRate: row.valuationRate != null ? Number(row.valuationRate) : null,
    }));
  } catch (error) {
    console.error("Failed to fetch items:", error);
    return []; // Return empty array on error
  }
}

// Add a new item
export async function addItem(formData: FormData) {
  const rawData = Object.fromEntries(formData.entries());

   // Ensure valuationRate is converted to number or null
   let valuationRateValue: number | null = null;
   const rawValuationRate = rawData.valuationRate;
   if (rawValuationRate !== '' && rawValuationRate !== undefined && rawValuationRate !== null) {
        const parsedRate = parseFloat(rawValuationRate as string);
        if (!isNaN(parsedRate)) {
            valuationRateValue = parsedRate;
        } else {
             console.warn(`Invalid valuationRate value: ${rawValuationRate}. Setting to null.`);
             // Optionally return a validation error here instead of setting to null
             // return { success: false, message: "Validation failed", errors: { valuationRate: ["Invalid number format"] } };
        }
   }
   rawData.valuationRate = valuationRateValue; // Assign the processed value back

  const validatedData = ItemSchema.omit({ id: true }).safeParse(rawData);

  if (!validatedData.success) {
    console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
    return {
        success: false,
        message: "Validation failed",
        errors: validatedData.error.flatten().fieldErrors,
    };
  }

  const data = validatedData.data;
  // Optimization: Use crypto.randomUUID()
  const newId = `item-${Date.now()}-${crypto.randomUUID().slice(0, 7)}`;

  try {
    // Ensure primary key 'id' and potentially 'itemGroup' are indexed
    await runSqlQuery(
      'INSERT INTO items (id, name, itemGroup, description, stockUom, valuationRate, imageHint) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [
        newId,
        data.name,
        data.itemGroup || null,
        data.description || null,
        data.stockUom || null,
        data.valuationRate, // Already validated/parsed number or null
        data.imageHint || null,
      ]
    );
    revalidatePath('/crm/items'); // Revalidate the items page cache
    return { success: true, message: "Item added successfully", id: newId };
  } catch (error) {
    console.error("Failed to add item:", error);
    return { success: false, message: "Database error occurred while adding item.", error: error instanceof Error ? error.message : String(error) };
  }
}

// Delete an item
export async function deleteItem(id: string) {
  if (!id) {
    return { success: false, message: "Item ID is required" };
  }
  try {
    // Ensure primary key 'id' is indexed
    const result = await runSqlQuery('DELETE FROM items WHERE id = ?', [id]);
    if (result.rowsAffected === 0) {
        return { success: false, message: "Item not found." };
    }
    revalidatePath('/crm/items'); // Revalidate the items page cache
     return { success: true, message: "Item deleted successfully" };
  } catch (error) {
    console.error("Failed to delete item:", error);
     return { success: false, message: "Database error occurred while deleting item.", error: error instanceof Error ? error.message : String(error) };
  }
}
