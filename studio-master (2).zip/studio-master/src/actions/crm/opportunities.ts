
'use server';

import { runSqlQuery } from '@/lib/db';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { format, parseISO, isValid } from 'date-fns'; // For date handling
import { opportunityStages, type OpportunityStage } from '@/types/crm'; // Import from types file

// Define stages explicitly for reuse and validation - MOVED TO types/crm.ts
// export const opportunityStages = ['Qualification', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost'] as const;
// export type OpportunityStage = typeof opportunityStages[number]; // MOVED TO types/crm.ts

const OpportunitySchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Name is required"),
  account: z.string().optional(), // Link to Party ID later if needed
  stage: z.enum(opportunityStages), // Use imported enum
  amount: z.number().positive("Amount must be positive").optional().nullable(),
  closeDate: z.string().refine((date) => {
      // Basic check for YYYY-MM-DD format, further validation happens in action
      return /^\d{4}-\d{2}-\d{2}$/.test(date);
  }, { message: "Invalid close date format (YYYY-MM-DD required)" }),
});

export type Opportunity = z.infer<typeof OpportunitySchema>;

// Function to safely format date, handling potentially invalid strings
// Keep this helper if needed elsewhere, or simplify if only used here
const safeFormatDate = (dateString: string | null | undefined): string | null => {
    if (!dateString) return null;
    try {
        const parsed = parseISO(dateString);
        if (isValid(parsed)) {
            return format(parsed, 'yyyy-MM-dd');
        }
    } catch (e) {
        console.error(`Error parsing date string "${dateString}":`, e);
    }
    return null; // Return null if parsing or formatting fails
}

// Get all opportunities
// Optimization: Add pagination (LIMIT, OFFSET) for large datasets
// Optimization: Select only necessary columns if not all are needed
export async function getOpportunities(): Promise<Opportunity[]> {
  try {
    // Ensure 'closeDate', 'name', and 'stage' columns are indexed for faster querying/sorting
    const result = await runSqlQuery('SELECT * FROM opportunities ORDER BY closeDate DESC, name');
    // Ensure amount is number and closeDate is correctly formatted string
    return (result.rows as any[]).map(row => ({
        ...row,
        amount: row.amount != null ? Number(row.amount) : null,
        // Ensure closeDate is in the correct format; DB should store YYYY-MM-DD
        closeDate: typeof row.closeDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(row.closeDate)
                     ? row.closeDate
                     : format(new Date(), 'yyyy-MM-dd'), // Default to today if invalid
        stage: row.stage as OpportunityStage, // Assert type
    }));
  } catch (error) {
    console.error("Failed to fetch opportunities:", error);
    return [];
  }
}

// Add a new opportunity
export async function addOpportunity(formData: FormData) {
    const rawData = Object.fromEntries(formData.entries());

    // Convert amount to number or null
    let amountValue: number | null = null;
    const rawAmount = rawData.amount;
    if (rawAmount !== '' && rawAmount !== undefined && rawAmount !== null) {
        const parsedAmount = parseFloat(rawAmount as string);
        if (!isNaN(parsedAmount) && parsedAmount > 0) { // Ensure positive
             amountValue = parsedAmount;
        } else {
            console.warn(`Invalid or non-positive amount value: ${rawAmount}. Setting to null.`);
            // Return validation error instead?
            // return { success: false, message: "Validation failed", errors: { amount: ["Amount must be a positive number."] } };
        }
    }
    rawData.amount = amountValue;

     // Validate and format closeDate
     const closeDateInput = rawData.closeDate as string;
     let formattedCloseDate: string | null = null;
     try {
         const parsedDate = parseISO(closeDateInput);
         if (isValid(parsedDate)) {
             formattedCloseDate = format(parsedDate, 'yyyy-MM-dd');
         }
     } catch (e) {}

     if (!formattedCloseDate) {
         return {
             success: false,
             message: "Validation failed",
             errors: { closeDate: ["Invalid close date format. Use YYYY-MM-DD."] }
         };
     }
     rawData.closeDate = formattedCloseDate;


    const validatedData = OpportunitySchema.omit({ id: true }).safeParse(rawData);

    if (!validatedData.success) {
        console.error("Validation failed:", validatedData.error.flatten().fieldErrors);
        return {
            success: false,
            message: "Validation failed",
            errors: validatedData.error.flatten().fieldErrors,
        };
    }


    const data = validatedData.data;
    // Optimization: Use crypto.randomUUID()
    const newId = `opp-${Date.now()}-${crypto.randomUUID().slice(0, 7)}`;

    try {
        // Ensure primary key 'id' is indexed
        await runSqlQuery(
        'INSERT INTO opportunities (id, name, account, stage, amount, closeDate) VALUES (?, ?, ?, ?, ?, ?)',
        [
            newId,
            data.name,
            data.account || null,
            data.stage,
            data.amount, // Already validated number or null
            data.closeDate, // Already validated/formatted string
        ]
        );
        revalidatePath('/crm/opportunities');
         revalidatePath('/crm/pipeline'); // Also revalidate pipeline
        return { success: true, message: "Opportunity added successfully", id: newId };
    } catch (error) {
        console.error("Failed to add opportunity:", error);
        return { success: false, message: "Database error occurred while adding opportunity.", error: error instanceof Error ? error.message : String(error) };
    }
}

// Delete an opportunity
export async function deleteOpportunity(id: string) {
   if (!id) {
     return { success: false, message: "Opportunity ID is required" };
   }
  try {
    // Ensure primary key 'id' is indexed
    const result = await runSqlQuery('DELETE FROM opportunities WHERE id = ?', [id]);
    if (result.rowsAffected === 0) {
        return { success: false, message: "Opportunity not found." };
    }
    revalidatePath('/crm/opportunities');
    revalidatePath('/crm/pipeline'); // Also revalidate pipeline
    return { success: true, message: "Opportunity deleted successfully" };
  } catch (error) {
    console.error("Failed to delete opportunity:", error);
    return { success: false, message: "Database error occurred while deleting opportunity.", error: error instanceof Error ? error.message : String(error) };
  }
}

// Update opportunity stage (used by pipeline drag-and-drop)
export async function updateOpportunityStage(id: string, newStage: Opportunity['stage']) {
    if (!id || !newStage) {
        return { success: false, message: "Opportunity ID and new stage are required" };
    }

    // Validate stage against the defined enum values
    if (!opportunityStages.includes(newStage)) {
        return { success: false, message: "Invalid stage value provided." };
    }

    try {
        // Ensure 'id' and 'stage' columns are indexed
        const result = await runSqlQuery('UPDATE opportunities SET stage = ? WHERE id = ?', [newStage, id]);
        if (result.rowsAffected === 0) {
            return { success: false, message: "Opportunity not found or stage not changed" };
        }
        revalidatePath('/crm/opportunities');
        revalidatePath('/crm/pipeline');
        return { success: true, message: "Opportunity stage updated successfully" };
    } catch (error) {
        console.error("Failed to update opportunity stage:", error);
        return { success: false, message: "Database error occurred while updating stage.", error: error instanceof Error ? error.message : String(error) };
    }
}


// TODO: Implement full updateOpportunity function
// Ensure UPDATE uses WHERE id = ? and updates only necessary fields
// Function signature should be async function updateOpportunity(...) { ... }
