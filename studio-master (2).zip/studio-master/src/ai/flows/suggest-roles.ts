'use server';

/**
 * @fileOverview AI-powered role suggestion tool for HR managers.
 *
 * - suggestRoles - A function that suggests roles and permissions for new employees.
 * - SuggestRolesInput - The input type for the suggestRoles function.
 * - SuggestRolesOutput - The return type for the suggestRoles function.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

const SuggestRolesInputSchema = z.object({
  jobDescription: z
    .string()
    .describe('The job description of the new employee.'),
  department: z.string().describe('The department the new employee will be working in.'),
});
export type SuggestRolesInput = z.infer<typeof SuggestRolesInputSchema>;

const SuggestRolesOutputSchema = z.object({
  suggestedRoles: z
    .array(z.string())
    .describe('An array of suggested roles for the new employee.'),
  suggestedPermissions: z
    .array(z.string())
    .describe('An array of suggested permissions for the new employee.'),
  justification: z.string().describe('The justification for the suggested roles and permissions.'),
});
export type SuggestRolesOutput = z.infer<typeof SuggestRolesOutputSchema>;

export async function suggestRoles(input: SuggestRolesInput): Promise<SuggestRolesOutput> {
  return suggestRolesFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestRolesPrompt',
  input: {
    schema: z.object({
      jobDescription: z
        .string()
        .describe('The job description of the new employee.'),
      department: z.string().describe('The department the new employee will be working in.'),
    }),
  },
  output: {
    schema: z.object({
      suggestedRoles: z
        .array(z.string())
        .describe('An array of suggested roles for the new employee.'),
      suggestedPermissions: z
        .array(z.string())
        .describe('An array of suggested permissions for the new employee.'),
      justification: z.string().describe('The justification for the suggested roles and permissions.'),
    }),
  },
  prompt: `You are an AI assistant helping HR managers to assign appropriate roles and permissions to new employees.

  Based on the job description and department of the new employee, you will suggest a list of roles and permissions that are suitable for the employee.
  Also, provide a justification for the suggested roles and permissions.

  Job Description: {{{jobDescription}}}
  Department: {{{department}}}

  Output the suggested roles, permissions and justification in JSON format.
  `,
});

const suggestRolesFlow = ai.defineFlow<
  typeof SuggestRolesInputSchema,
  typeof SuggestRolesOutputSchema
>(
  {
    name: 'suggestRolesFlow',
    inputSchema: SuggestRolesInputSchema,
    outputSchema: SuggestRolesOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
