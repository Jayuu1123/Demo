'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import {
  Box, // Icon for Items
  Boxes, // Icon for Item Groups
  Building, // Icon for Parties
  Target, // Icon for Leads
  Contact, // Icon for Contacts
  Handshake, // Icon for Opportunities
  ArrowLeft,
} from 'lucide-react';

// Define CRM entry types
const crmEntryTypes = [
  { name: 'New Item', href: '/crm/items/new', icon: Box, description: 'Add a new product or service.' },
  { name: 'New Item Group', href: '/crm/item-groups/new', icon: Boxes, description: 'Create a new group for items.' },
  { name: 'New Party', href: '/crm/parties/new', icon: Building, description: 'Add a new customer or supplier.' },
  { name: 'New Lead', href: '/crm/leads/new', icon: Target, description: 'Add a new potential customer.' },
  { name: 'New Contact', href: '/crm/contacts/new', icon: Contact, description: 'Add a new individual contact.' },
  { name: 'New Opportunity', href: '/crm/opportunities/new', icon: Handshake, description: 'Add a new sales opportunity.' },
];

export default function NewCrmEntryPage() {
   const router = useRouter();

  return (
    <>
       <div className="flex items-center gap-4 mb-6">
         <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back">
           <ArrowLeft className="h-4 w-4" />
         </Button>
         <h1 className="text-3xl font-semibold">New CRM Entry</h1>
       </div>
      <p className="text-muted-foreground mb-8">
        Select the type of CRM record you want to create.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {crmEntryTypes.map((entryType) => (
          <Link href={entryType.href} key={entryType.name} passHref>
            <Card className="shadow-sm hover:shadow-lg transition-shadow duration-200 cursor-pointer h-full flex flex-col">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                <entryType.icon className="h-8 w-8 text-primary" />
                <CardTitle className="text-xl font-medium">{entryType.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground">{entryType.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}
