

'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Box,
  Boxes,
  Building,
  Contact,
  Target,
  Handshake,
  Filter, // Replaced Pipeline with Filter
} from 'lucide-react';

// Define CRM modules
const crmModules = [
  { name: 'Items', href: '/crm/items', icon: Box, description: 'Manage products and services.' },
  { name: 'Item Groups', href: '/crm/item-groups', icon: Boxes, description: 'Organize items into groups.' },
  { name: 'Parties', href: '/crm/parties', icon: Building, description: 'Manage customers, suppliers, etc.' },
  { name: 'Leads', href: '/crm/leads', icon: Target, description: 'Track potential customers.' },
  { name: 'Contacts', href: '/crm/contacts', icon: Contact, description: 'Manage individual contacts.' },
  { name: 'Opportunities', href: '/crm/opportunities', icon: Handshake, description: 'Track sales deals.' },
  { name: 'Pipeline', href: '/crm/pipeline', icon: Filter, description: 'Visualize sales stages.' }, // Updated icon
];

export default function CrmHomePage() {
  return (
    <>
      <h1 className="text-3xl font-semibold mb-6">CRM Dashboard</h1>
      <p className="text-muted-foreground mb-8">
        Select a module below to manage your customer relationships, sales, and items.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {crmModules.map((module) => (
          <Link href={module.href} key={module.name} passHref>
            <Card className="shadow-sm hover:shadow-lg transition-shadow duration-200 cursor-pointer h-full flex flex-col">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                <module.icon className="h-8 w-8 text-primary" />
                <CardTitle className="text-xl font-medium">{module.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground">{module.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}
