
'use client';

import { Suspense } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import type { Item } from '@/actions/crm/items';
import { ItemsTable } from './items-table';
import { ItemsTableSkeleton } from './items-table-skeleton';

interface ItemsPageClientContentProps {
  items: Item[] | null; // Allow null if fetching fails
}

export function ItemsPageClientContent({ items }: ItemsPageClientContentProps) {
  const router = useRouter();

  const handleAddItemClick = () => {
    router.push('/crm/items/new');
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Items</h1>
        <Button onClick={handleAddItemClick}>
          <PlusCircle className="mr-2 h-4 w-4" /> Add Item
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
          <Suspense fallback={<ItemsTableSkeleton />}>
            {items ? (
              <ItemsTable items={items} />
            ) : (
              <Alert variant="destructive" className="m-4">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>Failed to fetch items.</AlertDescription>
              </Alert>
            )}
          </Suspense>
        </CardContent>
      </Card>
    </>
  );
}
