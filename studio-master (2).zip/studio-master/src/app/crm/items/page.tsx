
import { getItems } from '@/actions/crm/items';
import { ItemsPageClientContent } from './_components/items-page-client-content';

// This is now an async Server Component
export default async function ItemsPage() {
  // Fetch data directly on the server
  let items = null;
  try {
    items = await getItems();
    // Potential optimization: Add pagination or limit the number of contacts fetched initially
  } catch (error) {
      console.error("Failed to fetch items:", error);
      // items remains null, the client component will handle showing the error
  }


  // Pass the fetched data (or null on error) to the client component
  return <ItemsPageClientContent items={items} />;
}

// Removed the separate ItemsData async component as its logic is now in the main Server Component.
