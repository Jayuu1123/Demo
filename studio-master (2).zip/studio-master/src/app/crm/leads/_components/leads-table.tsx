
'use client';

import { useState, useTransition } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Trash2, Edit, Loader2, UserCheck } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { deleteLead, convertLeadToContact, type Lead } from '@/actions/crm/leads';
import { useToast } from "@/hooks/use-toast";

interface LeadsTableProps {
  leads: Lead[];
}

export function LeadsTable({ leads: initialLeads }: LeadsTableProps) {
  const [leads, setLeads] = useState<Lead[]>(initialLeads);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const handleDelete = (id: string) => {
     if (!id || isPending) return;
     if (!confirm('Are you sure you want to delete this lead?')) {
         return;
     }
    startTransition(async () => {
      try {
          const result = await deleteLead(id);
          if (result.success) {
              setLeads(prevLeads => prevLeads.filter(lead => lead.id !== id));
              toast({ title: "Success", description: result.message });
          } else {
              toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete lead." });
          }
      } catch (err) {
           toast({ variant: "destructive", title: "Error", description: "An unexpected error occurred." });
           console.error("Delete lead error:", err);
      }
    });
  };

  const handleConvert = (id: string) => {
    if (!id || isPending) return;
    startTransition(async () => {
        try {
            const result = await convertLeadToContact(id);
            if (result.success) {
                setLeads(prevLeads => prevLeads.filter(lead => lead.id !== id));
                toast({ title: "Success", description: result.message });
                // TODO: Optionally, revalidate contacts path or navigate
            } else {
                toast({ variant: "destructive", title: "Error", description: result.message || "Failed to convert lead." });
            }
        } catch (err) {
            toast({ variant: "destructive", title: "Error", description: "An unexpected error occurred during conversion." });
            console.error("Convert lead error:", err);
        }
    });
  };

  const handleEditLeadClick = (lead: Lead) => {
     if (isPending) return;
     console.log("Edit lead clicked:", lead);
     // TODO: Open edit dialog
     toast({ title: "Info", description: "Edit functionality not implemented."});
  };

  const getStatusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
      switch (status) {
          case 'New': return 'destructive';
          case 'Contacted': return 'secondary';
          case 'Qualified': return 'default';
          case 'Lost': return 'outline';
          case 'Converted': return 'default';
          default: return 'outline';
      }
  };

  return (
    <Table>
        <TableHeader>
            <TableRow>
            <TableHead className="pl-4">Name</TableHead>
            <TableHead>Company</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Phone</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {leads.length === 0 ? (
            <TableRow>
                <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                No active leads found.
                </TableCell>
            </TableRow>
            ) : (
            leads.map((lead) => (
                <TableRow key={lead.id}>
                <TableCell className="font-medium pl-4">{lead.name}</TableCell>
                <TableCell>{lead.company || '-'}</TableCell>
                <TableCell>{lead.email || '-'}</TableCell>
                <TableCell>{lead.phone || '-'}</TableCell>
                <TableCell>
                    <Badge variant={getStatusVariant(lead.status)} className='text-xs'>{lead.status}</Badge>
                </TableCell>
                <TableCell className="pr-4">
                    <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handleEditLeadClick(lead)} disabled={isPending}>
                        <Edit className="mr-2 h-4 w-4"/> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleConvert(lead.id!)} disabled={isPending}>
                            <UserCheck className="mr-2 h-4 w-4" /> Convert to Contact
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                            className="text-destructive focus:text-destructive focus:bg-destructive/10"
                            onClick={() => handleDelete(lead.id!)}
                            disabled={isPending}
                        >
                            {isPending ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            ) : (
                            <Trash2 className="mr-2 h-4 w-4" />
                            )}
                        Delete
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                    </DropdownMenu>
                </TableCell>
                </TableRow>
            ))
            )}
        </TableBody>
    </Table>
  );
}
