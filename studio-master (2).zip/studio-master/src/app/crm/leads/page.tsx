
'use client'; // Add "use client" directive

import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { getLeads } from '@/actions/crm/leads';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { LeadsTable } from './_components/leads-table';
import { LeadsTableSkeleton } from './_components/leads-table-skeleton';

// This is now a Client Component because it uses useRouter
export default function LeadsPage() {
  const router = useRouter(); // Hook for navigation

  const handleAddLeadClick = () => {
    router.push('/crm/leads/new'); // Navigate to the new lead page
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Leads</h1>
        <Button onClick={handleAddLeadClick}>
           <PlusCircle className="mr-2 h-4 w-4" />
          Add Lead
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<LeadsTableSkeleton />}>
             <LeadsData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Server component to fetch data
async function LeadsData() {
  const leads = await getLeads(); // Fetch only non-converted leads by default

   if (!leads) {
      return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch leads.</AlertDescription>
         </Alert>
       );
   }

  return <LeadsTable leads={leads} />;
}
