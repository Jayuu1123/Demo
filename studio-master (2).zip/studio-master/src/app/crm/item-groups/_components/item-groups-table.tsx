
'use client';

import { useState, useTransition } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { FolderTree, MoreHorizontal, Trash2, Edit, Loader2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { deleteItemGroup, type ItemGroup } from '@/actions/crm/itemGroups';
import { useToast } from "@/hooks/use-toast";

interface ItemGroupsTableProps {
  itemGroups: ItemGroup[];
}

export function ItemGroupsTable({ itemGroups: initialItemGroups }: ItemGroupsTableProps) {
  const [itemGroups, setItemGroups] = useState<ItemGroup[]>(initialItemGroups);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const handleDelete = (id: string) => {
     if (!id || isPending) return;
     if (!confirm('Are you sure you want to delete this item group? This might affect items within this group.')) {
        return;
     }
    startTransition(async () => {
      try {
         const result = await deleteItemGroup(id);
         if (result.success) {
           setItemGroups(prevGroups => prevGroups.filter(group => group.id !== id));
            toast({ title: "Success", description: result.message });
         } else {
             toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete item group." });
         }
      } catch (err) {
          toast({ variant: "destructive", title: "Error", description: "An unexpected error occurred." });
          console.error("Delete item group error:", err);
      }
    });
  };

   const handleEditItemGroupClick = (group: ItemGroup) => {
     if (isPending) return;
     console.log("Edit item group clicked:", group);
     // TODO: Open edit dialog
      toast({ title: "Info", description: "Edit functionality not implemented."});
   };

  return (
    <Table>
        <TableHeader>
            <TableRow>
            <TableHead className="w-[50px] pl-4">
                <Checkbox />
            </TableHead>
            <TableHead className="w-[80px]">Icon</TableHead>
            <TableHead>Group Name</TableHead>
            <TableHead>Parent Group</TableHead>
            <TableHead>Is Group</TableHead>
            <TableHead>Description</TableHead>
            <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {itemGroups.length === 0 ? (
                <TableRow>
                <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                    No item groups found.
                </TableCell>
                </TableRow>
            ) : (
            itemGroups.map((group) => (
                <TableRow key={group.id}>
                <TableCell className="pl-4">
                    <Checkbox aria-label={`Select group ${group.name}`} />
                </TableCell>
                <TableCell>
                    <FolderTree className="h-5 w-5 text-muted-foreground" />
                </TableCell>
                <TableCell className="font-medium">{group.name}</TableCell>
                <TableCell>{group.parentGroup || 'All Item Groups'}</TableCell>
                <TableCell>
                    <Checkbox checked={!!group.isGroup} disabled aria-label={group.isGroup ? 'Is a group' : 'Is not a group'}/>
                </TableCell>
                <TableCell className="text-muted-foreground text-xs max-w-xs truncate">
                    {group.description || '-'}
                </TableCell>
                <TableCell className="pr-4">
                    <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handleEditItemGroupClick(group)} disabled={isPending}>
                            <Edit className="mr-2 h-4 w-4"/>
                            Edit
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                        className="text-destructive focus:text-destructive focus:bg-destructive/10"
                        onClick={() => handleDelete(group.id!)}
                        disabled={isPending}
                        >
                            {isPending ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            ) : (
                            <Trash2 className="mr-2 h-4 w-4" />
                            )}
                        Delete
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                    </DropdownMenu>
                </TableCell>
                </TableRow>
            ))
            )}
        </TableBody>
    </Table>
  );
}
