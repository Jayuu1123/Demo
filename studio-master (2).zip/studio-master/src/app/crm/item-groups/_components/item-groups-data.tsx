'use client'; // Add 'use client' directive

import { useState, useEffect } from 'react'; // Import React hooks
import { getItemGroups, type ItemGroup } from '@/actions/crm/itemGroups'; // Import type
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Loader2 } from "lucide-react";
import { ItemGroupsTable } from './item-groups-table';
import { ItemGroupsTableSkeleton } from './item-groups-table-skeleton'; // Import Skeleton


export function ItemGroupsData() {
  const [itemGroups, setItemGroups] = useState<ItemGroup[] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const data = await getItemGroups();
        setItemGroups(data || []); // Set empty array if data is null/undefined
      } catch (err) {
        console.error("Failed to fetch item groups:", err);
        setError(err instanceof Error ? err.message : "An unknown error occurred.");
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []); // Empty dependency array means this runs once on mount

  if (isLoading) {
    return <ItemGroupsTableSkeleton />; // Show skeleton while loading
  }

  if (error) {
    return (
      <Alert variant="destructive" className="m-4">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!itemGroups) {
       // This case should ideally not be hit if loading finishes and no error occurs,
       // but included for completeness.
       return (
          <Alert variant="destructive" className="m-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>Could not load item groups data.</AlertDescription>
          </Alert>
        );
  }


  return <ItemGroupsTable itemGroups={itemGroups} />;
}