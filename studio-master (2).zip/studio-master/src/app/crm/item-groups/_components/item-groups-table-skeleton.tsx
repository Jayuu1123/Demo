
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export function ItemGroupsTableSkeleton() {
  return (
     <Table>
        <TableHeader>
            <TableRow>
            <TableHead className="w-[50px] pl-4"><Skeleton className="h-4 w-4" /></TableHead>
            <TableHead className="w-[80px]">Icon</TableHead>
            <TableHead>Group Name</TableHead>
            <TableHead>Parent Group</TableHead>
            <TableHead>Is Group</TableHead>
            <TableHead>Description</TableHead>
            <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {Array.from({ length: 5 }).map((_, index) => (
            <TableRow key={`skeleton-${index}`}>
                <TableCell className="pl-4"><Skeleton className="h-4 w-4" /></TableCell>
                <TableCell><Skeleton className="h-5 w-5" /></TableCell>
                <TableCell><Skeleton className="h-4 w-3/4" /></TableCell>
                <TableCell><Skeleton className="h-4 w-1/2" /></TableCell>
                <TableCell><Skeleton className="h-4 w-4" /></TableCell>
                <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                <TableCell className="pr-4"><Skeleton className="h-8 w-8" /></TableCell>
            </TableRow>
            ))}
        </TableBody>
    </Table>
  );
}
