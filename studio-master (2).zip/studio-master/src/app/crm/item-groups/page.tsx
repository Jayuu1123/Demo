
'use client'; // Add "use client" directive

import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle } from "lucide-react";
import { ItemGroupsTableSkeleton } from './_components/item-groups-table-skeleton';
import { ItemGroupsData } from './_components/item-groups-data'; // Import the server component

// This is now a Client Component because it uses useRouter
export default function ItemGroupsPage() {
  const router = useRouter(); // Hook for navigation

  const handleAddItemGroupClick = () => {
    router.push('/crm/item-groups/new'); // Navigate to the new item group page
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Item Groups</h1>
         <Button onClick={handleAddItemGroupClick}>
           <PlusCircle className="mr-2 h-4 w-4" />
          Add Item Group
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<ItemGroupsTableSkeleton />}>
             <ItemGroupsData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Removed the local async function definition for ItemGroupsData
