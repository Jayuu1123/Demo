
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox"; // Import Checkbox
import { Loader2, ArrowLeft } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { addItemGroup } from '@/actions/crm/itemGroups'; // Import the server action

// Schema based on the server action, excluding ID
const ItemGroupFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  parentGroup: z.string().optional(),
  isGroup: z.boolean().default(true),
  description: z.string().optional(),
});

type ItemGroupFormValues = z.infer<typeof ItemGroupFormSchema>;

export default function NewItemGroupPage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<ItemGroupFormValues>({
    resolver: zodResolver(ItemGroupFormSchema),
    defaultValues: {
      name: '',
      parentGroup: '', // Or fetch defaults/options
      isGroup: true,
      description: '',
    },
  });

  const onSubmit = (values: ItemGroupFormValues) => {
    startTransition(async () => {
      const formData = new FormData();
      formData.append('name', values.name);
      if (values.parentGroup) formData.append('parentGroup', values.parentGroup);
      // FormData handles booleans weirdly, send 'on' if true
      if (values.isGroup) formData.append('isGroup', 'on');
      if (values.description) formData.append('description', values.description);

      try {
        const result = await addItemGroup(formData);
        if (result.success && result.id) {
          toast({
            title: "Success",
            description: "Item Group created successfully.",
          });
          router.push('/crm/item-groups'); // Redirect back to the list
        } else {
          const errorMessages = result.errors
              ? Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ')
              : result.message || "An unknown error occurred.";
          toast({
            variant: "destructive",
            title: "Error creating Item Group",
            description: errorMessages,
          });
           if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
                Object.entries(result.errors).forEach(([field, messages]) => {
                    if (messages && messages.length > 0) {
                       form.setError(field as keyof ItemGroupFormValues, { type: 'server', message: messages[0] });
                    }
                });
            }
          console.error("Server validation errors:", result.errors || result.error);
        }
      } catch (error) {
        console.error("Failed to create item group:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred.",
        });
      }
    });
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Item Group</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-2xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Item Group Details</CardTitle>
            <CardDescription className="text-muted-foreground">Enter the details for the new item group.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 space-y-4">

            {/* Group Name */}
            <div className="space-y-2">
              <Label htmlFor="name" className="font-medium">Group Name <span className="text-destructive">*</span></Label>
              <Input
                id="name"
                {...form.register('name')}
                placeholder="e.g., Electronics, Services"
                className="border-input focus:ring-primary focus:border-primary"
                aria-invalid={!!form.formState.errors.name}
              />
              {form.formState.errors.name && (
                <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
              )}
            </div>

            {/* Parent Group */}
            <div className="space-y-2">
              <Label htmlFor="parentGroup" className="font-medium">Parent Group</Label>
              {/* Replace with Select if you have parent groups */}
              <Input
                id="parentGroup"
                {...form.register('parentGroup')}
                placeholder="Leave empty for root group"
                className="border-input focus:ring-primary focus:border-primary"
              />
              {form.formState.errors.parentGroup && (
                <p className="text-sm text-destructive">{form.formState.errors.parentGroup.message}</p>
              )}
            </div>

             {/* Is Group Checkbox */}
            <div className="flex items-center space-x-2 pt-2">
               <Checkbox
                  id="isGroup"
                  {...form.register('isGroup')}
                  checked={form.watch('isGroup')}
                  onCheckedChange={(checked) => form.setValue('isGroup', Boolean(checked))}
               />
              <Label htmlFor="isGroup" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                Is Group (Allows adding items to this group)
              </Label>
              {form.formState.errors.isGroup && (
                 <p className="text-sm text-destructive pl-6">{form.formState.errors.isGroup.message}</p>
              )}
            </div>

            {/* Description */}
            <div className="space-y-2">
              <Label htmlFor="description" className="font-medium">Description</Label>
              <Textarea
                id="description"
                {...form.register('description')}
                placeholder="Enter a description for the group..."
                rows={3}
                className="resize-y border-input focus:ring-primary focus:border-primary"
              />
              {form.formState.errors.description && (
                <p className="text-sm text-destructive">{form.formState.errors.description.message}</p>
              )}
            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Creating...' : 'Create Item Group'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
