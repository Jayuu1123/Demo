
'use client'; // Add "use client" directive

import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { getParties } from '@/actions/crm/parties';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { PartiesTable } from './_components/parties-table';
import { PartiesTableSkeleton } from './_components/parties-table-skeleton';

// This is now a Client Component because it uses useRouter
export default function PartiesPage() {
  const router = useRouter(); // Hook for navigation

  const handleAddPartyClick = () => {
    router.push('/crm/parties/new'); // Navigate to the new party page
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Parties (Customers/Suppliers)</h1>
        <Button onClick={handleAddPartyClick}>
           <PlusCircle className="mr-2 h-4 w-4" />
          Add Party
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<PartiesTableSkeleton />}>
             <PartiesData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Server component to fetch data
async function PartiesData() {
  const parties = await getParties();

   if (!parties) {
      return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch parties.</AlertDescription>
         </Alert>
       );
   }

  return <PartiesTable parties={parties} />;
}
