
'use client';

import { useState, useTransition } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Trash2, Edit, Loader2, ShoppingCart, Handshake } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { deleteParty, type Party } from '@/actions/crm/parties';
import { useToast } from "@/hooks/use-toast";

interface PartiesTableProps {
  parties: Party[];
}

export function PartiesTable({ parties: initialParties }: PartiesTableProps) {
  const [parties, setParties] = useState<Party[]>(initialParties);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const handleDelete = (id: string) => {
      if (!id || isPending) return;
      if (!confirm('Are you sure you want to delete this party? Related records might be affected.')) {
          return;
      }
    startTransition(async () => {
      try {
          const result = await deleteParty(id);
          if (result.success) {
            setParties(prevParties => prevParties.filter(party => party.id !== id));
              toast({ title: "Success", description: result.message });
          } else {
              toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete party." });
          }
      } catch (err) {
           toast({ variant: "destructive", title: "Error", description: "An unexpected error occurred." });
           console.error("Delete party error:", err);
      }
    });
  };

   const handleEditPartyClick = (party: Party) => {
     if (isPending) return;
     console.log("Edit party clicked:", party);
     // TODO: Open edit dialog
      toast({ title: "Info", description: "Edit functionality not implemented."});
   };

   const getStatusVariant = (status: string): "default" | "secondary" | "destructive" => {
        switch (status) {
            case 'Active': return 'default';
            case 'On Hold': return 'secondary';
            case 'Disabled': return 'destructive';
            default: return 'default';
        }
   }

  return (
    <Table>
        <TableHeader>
            <TableRow>
            <TableHead className="w-[50px] pl-4">
                <Checkbox />
            </TableHead>
            <TableHead>Party Name</TableHead>
            <TableHead>Party Type</TableHead>
            <TableHead>Territory</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {parties.length === 0 ? (
            <TableRow>
                <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                No parties found.
                </TableCell>
            </TableRow>
            ) : (
            parties.map((party) => (
                <TableRow key={party.id}>
                <TableCell className="pl-4">
                    <Checkbox aria-label={`Select party ${party.name}`} />
                </TableCell>
                <TableCell className="font-medium">{party.name}</TableCell>
                <TableCell>
                    <Badge variant={party.type === 'Customer' ? 'secondary' : 'outline'}>{party.type}</Badge>
                </TableCell>
                <TableCell>{party.territory || '-'}</TableCell>
                <TableCell>{party.email || '-'}</TableCell>
                <TableCell>
                    <Badge variant={getStatusVariant(party.status)} className='text-xs'>{party.status}</Badge>
                </TableCell>
                <TableCell className="pr-4">
                    <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                        <span className="sr-only">Open menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => handleEditPartyClick(party)} disabled={isPending}>
                            <Edit className="mr-2 h-4 w-4"/>
                            Edit
                        </DropdownMenuItem>
                        {party.type === 'Customer' && (
                        <DropdownMenuItem onClick={() => console.log(`Create Opportunity for ${party.id}`)} disabled={isPending}>
                            <Handshake className="mr-2 h-4 w-4"/> Create Opportunity
                        </DropdownMenuItem>
                        )}
                        {party.type === 'Supplier' && (
                        <DropdownMenuItem onClick={() => console.log(`Create Purchase Order for ${party.id}`)} disabled={isPending}>
                            <ShoppingCart className="mr-2 h-4 w-4"/> Create Purchase Order
                        </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                            className="text-destructive focus:text-destructive focus:bg-destructive/10"
                            onClick={() => handleDelete(party.id!)}
                            disabled={isPending}
                        >
                            {isPending ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            ) : (
                            <Trash2 className="mr-2 h-4 w-4" />
                            )}
                        Delete
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                    </DropdownMenu>
                </TableCell>
                </TableRow>
            ))
            )}
        </TableBody>
    </Table>
  );
}
