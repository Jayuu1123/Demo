
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, ArrowLeft } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { addParty } from '@/actions/crm/parties'; // Import the server action

// Define the schema matching the server action, excluding ID
const PartyFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  type: z.enum(['Customer', 'Supplier']),
  territory: z.string().optional(),
  status: z.enum(['Active', 'On Hold', 'Disabled']),
  email: z.string().email("Invalid email address").optional().or(z.literal('')),
});

type PartyFormValues = z.infer<typeof PartyFormSchema>;

export default function NewPartyPage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<PartyFormValues>({
    resolver: zodResolver(PartyFormSchema),
    defaultValues: {
      name: '',
      type: 'Customer', // Default type
      territory: '',
      status: 'Active', // Default status
      email: '',
    },
  });

  const onSubmit = (values: PartyFormValues) => {
    startTransition(async () => {
      const formData = new FormData();
      formData.append('name', values.name);
      formData.append('type', values.type);
      if (values.territory) formData.append('territory', values.territory);
      formData.append('status', values.status);
      if (values.email) formData.append('email', values.email);

      try {
        const result = await addParty(formData);
        if (result.success && result.id) {
          toast({
            title: "Success",
            description: "Party created successfully.",
          });
          router.push('/crm/parties'); // Redirect back to the list
        } else {
           const errorMessages = result.errors
              ? Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ')
              : result.message || "An unknown error occurred.";
          toast({
            variant: "destructive",
            title: "Error creating Party",
            description: errorMessages,
          });
           if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
                Object.entries(result.errors).forEach(([field, messages]) => {
                    if (messages && messages.length > 0) {
                       form.setError(field as keyof PartyFormValues, { type: 'server', message: messages[0] });
                    }
                });
            }
          console.error("Server validation errors:", result.errors || result.error);
        }
      } catch (error) {
        console.error("Failed to create party:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred.",
        });
      }
    });
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Party (Customer/Supplier)</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-2xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Party Details</CardTitle>
            <CardDescription className="text-muted-foreground">Enter the details for the new party.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Left Column */}
            <div className="space-y-4">
              {/* Party Name */}
              <div className="space-y-2">
                <Label htmlFor="name" className="font-medium">Party Name <span className="text-destructive">*</span></Label>
                <Input
                  id="name"
                  {...form.register('name')}
                  placeholder="e.g., Acme Corp, Supplier Ltd"
                  className="border-input focus:ring-primary focus:border-primary"
                   aria-invalid={!!form.formState.errors.name}
                />
                {form.formState.errors.name && (
                  <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
                )}
              </div>

              {/* Party Type */}
              <div className="space-y-2">
                <Label htmlFor="type" className="font-medium">Party Type <span className="text-destructive">*</span></Label>
                <Controller
                   control={form.control}
                   name="type"
                   render={({ field }) => (
                     <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger id="type" className="border-input focus:ring-primary focus:border-primary">
                            <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border">
                            <SelectItem value="Customer">Customer</SelectItem>
                            <SelectItem value="Supplier">Supplier</SelectItem>
                        </SelectContent>
                     </Select>
                   )}
                 />
                 {form.formState.errors.type && (
                    <p className="text-sm text-destructive">{form.formState.errors.type.message}</p>
                 )}
              </div>

               {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email" className="font-medium">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...form.register('email')}
                  placeholder="e.g., contact@acme.com"
                  className="border-input focus:ring-primary focus:border-primary"
                   aria-invalid={!!form.formState.errors.email}
                />
                {form.formState.errors.email && (
                  <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
                )}
              </div>

            </div>

            {/* Right Column */}
            <div className="space-y-4">
               {/* Territory */}
              <div className="space-y-2">
                <Label htmlFor="territory" className="font-medium">Territory</Label>
                <Input
                  id="territory"
                  {...form.register('territory')}
                  placeholder="e.g., North, West"
                  className="border-input focus:ring-primary focus:border-primary"
                />
                {form.formState.errors.territory && (
                  <p className="text-sm text-destructive">{form.formState.errors.territory.message}</p>
                )}
              </div>

               {/* Status */}
              <div className="space-y-2">
                <Label htmlFor="status" className="font-medium">Status <span className="text-destructive">*</span></Label>
                 <Controller
                   control={form.control}
                   name="status"
                   render={({ field }) => (
                     <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger id="status" className="border-input focus:ring-primary focus:border-primary">
                            <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border">
                            <SelectItem value="Active">Active</SelectItem>
                            <SelectItem value="On Hold">On Hold</SelectItem>
                            <SelectItem value="Disabled">Disabled</SelectItem>
                        </SelectContent>
                     </Select>
                   )}
                 />
                {form.formState.errors.status && (
                  <p className="text-sm text-destructive">{form.formState.errors.status.message}</p>
                )}
              </div>
            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground">
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Creating...' : 'Create Party'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
