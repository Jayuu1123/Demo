

'use client';
import type React from 'react'; // Ensure React is imported for type usage
import { useState, useEffect } from 'react'; // Import useState and useEffect

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarFooter,
  SidebarTrigger,
  SidebarMenuAction,
} from '@/components/ui/sidebar';
import { Header } from '@/components/layout/header';
import {
  Users,
  DollarSign,
  ShoppingCart,
  Settings,
  LifeBuoy,
  Contact,
  LineChart,
  LayoutDashboard,
  Plus,
  Box, // Icon for Items
  Boxes, // Icon for Item Groups
  Building, // Icon for Parties (or similar like Briefcase)
  Target, // Icon for Leads
  Handshake, // Icon for Opportunities
  Filter, // Replaced Pipeline
  FileText, // For Quotations
  ClipboardList, // For Sales Orders
  Receipt, // For Invoices
} from 'lucide-react';


export default function CrmLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // State to track the active path for client-side rendering
  const [activePath, setActivePath] = useState('');

  useEffect(() => {
    // Set the active path only on the client side after mount
    setActivePath(window.location.pathname);
  }, []);

  const isCrmActive = activePath.startsWith('/crm');


  return (
    <div className="flex min-h-screen w-full">
      <Sidebar collapsible="icon" variant="sidebar">
        <SidebarHeader className="flex items-center justify-between p-4">
          <div className="flex items-center gap-2">
             <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6 text-primary"
             >
               <path d="M12 2L2 7l10 5 10-5-10-5z" />
               <path d="M2 17l10 5 10-5" />
               <path d="M2 12l10 5 10-5" />
             </svg>
            <span className="font-semibold text-lg group-data-[collapsible=icon]:hidden">EraErp</span>
          </div>
          <SidebarTrigger className="md:hidden" />
        </SidebarHeader>
        <SidebarContent className="flex-1 overflow-auto">
          <SidebarMenu>
             <SidebarMenuItem>
              <SidebarMenuButton href="/" isActive={activePath === '/'}>
                <LayoutDashboard />
                <span>Dashboard</span>
              </SidebarMenuButton>
            </SidebarMenuItem>

            {/* CRM Module */}
            <SidebarMenuItem>
               {/* Main CRM link now points to /crm */}
              <SidebarMenuButton href="/crm" isActive={isCrmActive}>
                <Contact />
                <span>CRM</span>
              </SidebarMenuButton>
               <SidebarMenuAction aria-label="Add CRM Item" title="Add CRM Item" showOnHover>
                 <Plus />
               </SidebarMenuAction>
              <SidebarMenuSub>
                 {/* New CRM Sub-items */}
                 <SidebarMenuSubItem>
                   <SidebarMenuSubButton href="/crm/items" isActive={activePath === '/crm/items'}>
                     <Box className="h-3.5 w-3.5 mr-1.5" /> Items
                   </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                   <SidebarMenuSubButton href="/crm/item-groups" isActive={activePath === '/crm/item-groups'}>
                     <Boxes className="h-3.5 w-3.5 mr-1.5" /> Item Groups
                   </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                   <SidebarMenuSubButton href="/crm/parties" isActive={activePath === '/crm/parties'}>
                      <Building className="h-3.5 w-3.5 mr-1.5" /> Parties
                   </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/crm/leads" isActive={activePath === '/crm/leads'}>
                     <Target className="h-3.5 w-3.5 mr-1.5" /> Leads
                  </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/crm/contacts" isActive={activePath === '/crm/contacts'}>
                    <Contact className="h-3.5 w-3.5 mr-1.5" /> Contacts
                  </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/crm/opportunities" isActive={activePath === '/crm/opportunities'}>
                     <Handshake className="h-3.5 w-3.5 mr-1.5" /> Opportunities
                  </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                  <SidebarMenuSubItem>
                   <SidebarMenuSubButton href="/crm/pipeline" isActive={activePath === '/crm/pipeline'}>
                     <Filter className="h-3.5 w-3.5 mr-1.5" /> Pipeline
                   </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

             {/* Sales Module */}
            <SidebarMenuItem>
              <SidebarMenuButton href="/sales" isActive={activePath.startsWith('/sales')}>
                <LineChart />
                <span>Sales</span>
              </SidebarMenuButton>
               <SidebarMenuAction aria-label="Add Sales Item" title="Add Sales Item" showOnHover>
                 <Plus />
               </SidebarMenuAction>
               <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/sales/quotations" isActive={activePath === '/sales/quotations'}>
                    <FileText className="h-3.5 w-3.5 mr-1.5" /> Quotations
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/sales/sales-orders" isActive={activePath === '/sales/sales-orders'}>
                    <ClipboardList className="h-3.5 w-3.5 mr-1.5" /> Sales Orders
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/sales/invoices" isActive={activePath === '/sales/invoices'}>
                    <Receipt className="h-3.5 w-3.5 mr-1.5" /> Invoices
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

            {/* HR Module */}
            <SidebarMenuItem>
              <SidebarMenuButton href="#" isActive={activePath.startsWith('/hr') || activePath === '/suggest-roles'}>
                <Users />
                <span>Human Resources</span>
              </SidebarMenuButton>
               <SidebarMenuAction aria-label="Add HR Item" title="Add HR Item" showOnHover>
                 <Plus />
               </SidebarMenuAction>
              <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Employees</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Roles & Permissions</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                   <SidebarMenuSubButton href="/suggest-roles" isActive={activePath === '/suggest-roles'}>Suggest Roles (AI)</SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Attendance</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Payroll</SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

            {/* Finance Module */}
            <SidebarMenuItem>
              <SidebarMenuButton href="#">
                <DollarSign />
                <span>Finance</span>
              </SidebarMenuButton>
               <SidebarMenuAction aria-label="Add Finance Item" title="Add Finance Item" showOnHover>
                 <Plus />
               </SidebarMenuAction>
              <SidebarMenuSub>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Chart of Accounts</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Invoices</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Payments</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Expenses</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Reports</SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

             {/* Purchase Module */}
            <SidebarMenuItem>
              <SidebarMenuButton href="#">
                <ShoppingCart />
                <span>Purchase</span>
              </SidebarMenuButton>
               <SidebarMenuAction aria-label="Add Purchase Item" title="Add Purchase Item" showOnHover>
                 <Plus />
               </SidebarMenuAction>
              <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Purchase Orders</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Vendors</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="#">Bills</SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="mt-auto">
           <SidebarMenu>
             <SidebarMenuItem>
              <SidebarMenuButton href="#">
                <Settings />
                <span>Settings</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton href="#">
                <LifeBuoy />
                <span>Support</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
           </SidebarMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset className="flex flex-col">
        <Header />
        <main className="flex-1 overflow-auto p-6 bg-secondary/30">
          {children}
        </main>
      </SidebarInset>
    </div>
  );
}
