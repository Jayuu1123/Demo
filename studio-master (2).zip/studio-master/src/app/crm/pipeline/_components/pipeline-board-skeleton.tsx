
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import type { OpportunityStage } from '@/types/crm'; // Import type from types file

interface PipelineBoardSkeletonProps {
  stages: OpportunityStage[]; // Use imported type
}

export function PipelineBoardSkeleton({ stages }: PipelineBoardSkeletonProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 items-start">
      {stages.map((stage) => (
        <div
          key={stage}
          className="flex flex-col gap-4 p-3 bg-muted/30 rounded-lg min-h-[300px]"
        >
          <h2 className="font-semibold text-base mb-1 px-1"><Skeleton className="h-5 w-24" /></h2>
          <div className="flex flex-col gap-3 overflow-y-auto flex-grow">
            {Array.from({ length: 3 }).map((_, idx) => (
              <OpportunityCardSkeleton key={`${stage}-skel-${idx}`} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// Skeleton for individual opportunity card
function OpportunityCardSkeleton({ key }: { key: string }) {
    return (
         <Card key={key} className="shadow-sm opacity-50">
            <CardHeader className="p-3 pb-1 flex flex-row items-start justify-between">
                <Skeleton className="h-4 w-3/4" />
                 <Skeleton className="h-4 w-4" />
            </CardHeader>
            <CardContent className="p-3 pt-0 text-xs">
                <Skeleton className="h-3 w-1/2 mb-2" />
                <div className="flex justify-between items-center">
                    <Skeleton className="h-3 w-1/3" />
                    <Skeleton className="h-3 w-1/4" />
                </div>
            </CardContent>
        </Card>
    );
}
