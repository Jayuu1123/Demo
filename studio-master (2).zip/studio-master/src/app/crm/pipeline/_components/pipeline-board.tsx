
'use client';

import React, { useState, useTransition, useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CircleDollarSign, Calendar, GripVertical, Loader2 } from "lucide-react";
import { format, parseISO, isValid } from 'date-fns';
import { updateOpportunityStage, type Opportunity } from '@/actions/crm/opportunities';
import { type OpportunityStage } from '@/types/crm'; // Import type from types file
import { useToast } from "@/hooks/use-toast";

interface PipelineBoardProps {
  stages: OpportunityStage[]; // Use imported type
  opportunities: Opportunity[];
}

export function PipelineBoard({ stages, opportunities: initialOpportunities }: PipelineBoardProps) {
    const [opportunities, setOpportunities] = useState<Opportunity[]>(initialOpportunities);
    const [isPending, startTransition] = useTransition();
    const { toast } = useToast();

    const handleDragStart = (e: React.DragEvent<HTMLDivElement>, id: string) => {
        if (isPending) {
            e.preventDefault();
            return;
        }
        e.dataTransfer.setData('opportunityId', id);
        e.currentTarget.classList.add('opacity-50', 'cursor-grabbing', 'ring-2', 'ring-primary');
    };

    const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
         e.currentTarget.classList.remove('opacity-50', 'cursor-grabbing', 'ring-2', 'ring-primary');
    }

    const handleDrop = (e: React.DragEvent<HTMLDivElement>, targetStage: OpportunityStage) => { // Use imported type
        e.preventDefault();
        if (isPending) return;

        const opportunityId = e.dataTransfer.getData('opportunityId');
        const draggedOpportunity = opportunities.find(opp => opp.id === opportunityId);

        e.currentTarget.classList.remove('bg-primary/10', 'ring-2', 'ring-primary/50');

        if (!opportunityId || !draggedOpportunity || draggedOpportunity.stage === targetStage) {
            return;
        }

        const originalOpportunities = [...opportunities];
        setOpportunities(prev =>
            prev.map(opp =>
                opp.id === opportunityId ? { ...opp, stage: targetStage } : opp
            )
        );

        startTransition(async () => {
            try {
                const result = await updateOpportunityStage(opportunityId, targetStage);
                if (!result.success) {
                    setOpportunities(originalOpportunities);
                    toast({
                        variant: "destructive",
                        title: "Error",
                        description: result.message || "Failed to update opportunity stage.",
                    });
                } else {
                     toast({
                         title: "Success",
                         description: "Opportunity stage updated.",
                     });
                     // Revalidation should handle consistency, no explicit refetch needed typically
                }
            } catch (err) {
                 setOpportunities(originalOpportunities);
                 let errorMessage = "An unexpected error occurred while updating stage.";
                  if (err instanceof Error) {
                    errorMessage = err.message.includes('401')
                      ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                      : err.message;
                  }
                 toast({
                     variant: "destructive",
                     title: "Error",
                     description: errorMessage,
                 });
                 console.error("Update stage error:", err);
            }
        });
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        const targetColumn = e.currentTarget;
        if (!targetColumn.classList.contains('bg-primary/10')) {
           targetColumn.classList.add('bg-primary/10', 'ring-2', 'ring-primary/50');
        }
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        const targetColumn = e.currentTarget;
         if (!targetColumn.contains(e.relatedTarget as Node)) {
             targetColumn.classList.remove('bg-primary/10', 'ring-2', 'ring-primary/50');
         }
    };

    const sortedOpportunities = (stage: OpportunityStage) => { // Use imported type
        return opportunities
            .filter(opp => opp.stage === stage)
            .sort((a, b) => (new Date(a.closeDate)).getTime() - (new Date(b.closeDate)).getTime());
    }

  return (
     <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 items-start">
         {stages.map(stage => (
             <div
                key={stage}
                className="flex flex-col gap-4 p-3 bg-muted/30 rounded-lg min-h-[300px] transition-colors duration-150 border border-transparent"
                onDrop={(e) => handleDrop(e, stage)}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                aria-label={`Pipeline stage: ${stage}`}
              >
                 <h2 className="font-semibold text-base mb-1 px-1 sticky top-0 bg-muted/30 py-1 z-10">{stage}</h2>
                 <div className="flex flex-col gap-3 overflow-y-auto flex-grow ">
                     {sortedOpportunities(stage).map(opp => (
                        <OpportunityCard
                            key={opp.id}
                            opportunity={opp}
                            onDragStart={handleDragStart}
                            onDragEnd={handleDragEnd}
                            isPending={isPending}
                        />
                     ))}
                     {sortedOpportunities(stage).length === 0 && (
                         <p className="text-center text-xs text-muted-foreground mt-4">No opportunities in this stage.</p>
                     )}
                 </div>
                  {isPending && <Loader2 className="h-4 w-4 animate-spin text-muted-foreground mx-auto mt-2" />}
            </div>
         ))}
      </div>
  );
}

// --- Opportunity Card Component (Memoized) ---

interface OpportunityCardProps {
    opportunity: Opportunity;
    onDragStart: (e: React.DragEvent<HTMLDivElement>, id: string) => void;
    onDragEnd: (e: React.DragEvent<HTMLDivElement>) => void;
    isPending: boolean;
}

const OpportunityCard = React.memo(function OpportunityCard({ opportunity, onDragStart, onDragEnd, isPending }: OpportunityCardProps) {

     const formatCurrency = (value: number | null | undefined) => {
         if (value == null) return '-';
         // Changed currency to INR
         return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(value);
     }

     const formatDate = (dateString: string | null | undefined): string => {
        if (!dateString) return '-';
         try {
             const date = parseISO(dateString);
              if (isValid(date)) {
                 return format(date, 'MMM d');
             }
         } catch (e) { console.error("Error formatting date:", dateString, e); }
         return 'Invalid Date';
     }

    return (
         <Card
            className={`shadow-sm cursor-grab hover:shadow-md transition-shadow bg-card ${isPending ? 'opacity-70 cursor-not-allowed' : ''}`}
            draggable={!isPending}
            onDragStart={(e) => onDragStart(e, opportunity.id!)}
            onDragEnd={onDragEnd}
            aria-label={`Opportunity: ${opportunity.name}, Stage: ${opportunity.stage}`}
        >
            <CardHeader className="p-3 pb-1 flex flex-row items-start justify-between">
                <CardTitle className="text-sm font-medium leading-tight">{opportunity.name}</CardTitle>
                {!isPending && <GripVertical className="h-4 w-4 text-muted-foreground flex-shrink-0 cursor-grab ml-1" />}
            </CardHeader>
            <CardContent className="p-3 pt-0 text-xs">
                <p className="text-muted-foreground mb-1 truncate">{opportunity.account || 'No Account'}</p>
                <div className="flex justify-between items-center">
                    <span className="flex items-center gap-1 font-medium">
                            <CircleDollarSign className="h-3 w-3 text-muted-foreground" />
                            {formatCurrency(opportunity.amount)}
                    </span>
                    <span className="flex items-center gap-1 text-muted-foreground">
                            <Calendar className="h-3 w-3" />
                            {formatDate(opportunity.closeDate)}
                    </span>
                </div>
            </CardContent>
        </Card>
    );
});
