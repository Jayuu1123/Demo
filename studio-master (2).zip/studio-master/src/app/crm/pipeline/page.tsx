
import { Suspense } from 'react';
import { getOpportunities } from '@/actions/crm/opportunities';
import { Button } from "@/components/ui/button";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { PipelineBoard } from './_components/pipeline-board';
import { PipelineBoardSkeleton } from './_components/pipeline-board-skeleton';
import type { OpportunityStage } from '@/types/crm'; // Import type from types file

// Define the order of stages for the pipeline view
const stages: OpportunityStage[] = ['Qualification', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost']; // Use imported type

// This is now a Server Component
export default function PipelinePage() {

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Opportunity Pipeline</h1>
        <Button disabled> {/* TODO: Implement Add */}
          <PlusCircle className="mr-2 h-4 w-4" /> Add Opportunity
        </Button>
      </div>

       {/* Error handling can be improved with Error Boundaries */}

       <Suspense fallback={<PipelineBoardSkeleton stages={stages} />}>
         <PipelineData stages={stages} />
       </Suspense>
    </>
  );
}

// Server component to fetch data
async function PipelineData({ stages }: { stages: OpportunityStage[] }) { // Use imported type
  const opportunities = await getOpportunities();

   if (!opportunities) {
      return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch opportunities for pipeline.</AlertDescription>
         </Alert>
       );
   }

  return <PipelineBoard stages={stages} opportunities={opportunities} />;
}
