
'use client';

import { useState, useTransition } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Trash2, Edit, Loader2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { deleteContact, type Contact } from '@/actions/crm/contacts';
import { useToast } from "@/hooks/use-toast";

interface ContactsTableProps {
  contacts: Contact[];
}

export function ContactsTable({ contacts: initialContacts }: ContactsTableProps) {
  const [contacts, setContacts] = useState<Contact[]>(initialContacts);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const getInitials = (name: string | null | undefined): string => {
      if (!name) return '?';
      const names = name.split(' ');
      if (names.length === 0) return '?';
      return names.map(n => n[0]).join('').toUpperCase();
  }

  const handleDelete = (id: string) => {
      if (!id || isPending) return;
      if (!confirm('Are you sure you want to delete this contact?')) {
          return;
      }
      startTransition(async () => {
        try {
            const result = await deleteContact(id);
            if (result.success) {
                setContacts(prevContacts => prevContacts.filter(contact => contact.id !== id));
                toast({ title: "Success", description: result.message });
            } else {
                toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete contact." });
            }
        } catch (err) {
             toast({ variant: "destructive", title: "Error", description: "An unexpected error occurred." });
             console.error("Delete contact error:", err);
        }
      });
  };

   const handleEditContactClick = (contact: Contact) => {
     if (isPending) return;
     console.log("Edit contact clicked:", contact);
     // TODO: Open edit dialog
     toast({ title: "Info", description: "Edit functionality not implemented."});
   };

  return (
     <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="pl-4">Name</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead className="pr-4">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
             {contacts.length === 0 ? (
                 <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                      No contacts found.
                    </TableCell>
                 </TableRow>
               ) : (
                contacts.map((contact) => (
                  <TableRow key={contact.id}>
                    <TableCell className="font-medium flex items-center gap-2 pl-4">
                      <Avatar className="h-8 w-8">
                        {/* Using picsum.photos is fine for demos, real apps need optimized images */}
                        <AvatarImage src={`https://picsum.photos/40/40?random=contact-${contact.id}`} alt={contact.name || 'Contact'} data-ai-hint="person portrait" />
                        <AvatarFallback>{getInitials(contact.name)}</AvatarFallback>
                      </Avatar>
                      {contact.name}
                    </TableCell>
                    <TableCell>{contact.company || '-'}</TableCell>
                    <TableCell>{contact.title || '-'}</TableCell>
                    <TableCell>{contact.email || '-'}</TableCell>
                    <TableCell>{contact.phone || '-'}</TableCell>
                    <TableCell className="pr-4">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                           <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                           <DropdownMenuItem onClick={() => handleEditContactClick(contact)} disabled={isPending}>
                             <Edit className="mr-2 h-4 w-4"/> Edit
                           </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                             className="text-destructive focus:text-destructive focus:bg-destructive/10"
                             onClick={() => handleDelete(contact.id!)}
                             disabled={isPending}
                           >
                               {isPending ? (
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              ) : (
                                <Trash2 className="mr-2 h-4 w-4" />
                              )}
                             Delete
                           </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
  );
}
