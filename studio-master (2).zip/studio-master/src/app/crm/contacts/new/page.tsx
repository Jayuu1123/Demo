
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, ArrowLeft } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { addContact } from '@/actions/crm/contacts'; // Import the server action

// Schema based on the server action, excluding ID
const ContactFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  company: z.string().optional(),
  title: z.string().optional(),
  email: z.string().email("Invalid email address").optional().or(z.literal('')),
  phone: z.string().optional(),
});

type ContactFormValues = z.infer<typeof ContactFormSchema>;

export default function NewContactPage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(ContactFormSchema),
    defaultValues: {
      name: '',
      company: '',
      title: '',
      email: '',
      phone: '',
    },
  });

  const onSubmit = (values: ContactFormValues) => {
    startTransition(async () => {
      const formData = new FormData();
      formData.append('name', values.name);
      if (values.company) formData.append('company', values.company);
      if (values.title) formData.append('title', values.title);
      if (values.email) formData.append('email', values.email);
      if (values.phone) formData.append('phone', values.phone);

      try {
        const result = await addContact(formData);
        if (result.success && result.id) {
          toast({
            title: "Success",
            description: "Contact created successfully.",
          });
          router.push('/crm/contacts'); // Redirect back to the list
        } else {
           const errorMessages = result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)
              ? Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ')
              : result.message || "An unknown error occurred.";
          toast({
            variant: "destructive",
            title: "Error creating Contact",
            description: errorMessages,
          });
          if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
                Object.entries(result.errors).forEach(([field, messages]) => {
                    if (messages && messages.length > 0) {
                       form.setError(field as keyof ContactFormValues, { type: 'server', message: messages[0] });
                    }
                });
            }
          console.error("Server validation errors:", result.errors || result.error);
        }
      } catch (error) {
        console.error("Failed to create contact:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred.",
        });
      }
    });
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back" suppressHydrationWarning>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Contact</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-2xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Contact Details</CardTitle>
            <CardDescription className="text-muted-foreground">Enter the details for the new contact.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Left Column */}
            <div className="space-y-4">
              {/* Contact Name */}
              <div className="space-y-2">
                <Label htmlFor="name" className="font-medium">Contact Name <span className="text-destructive">*</span></Label>
                <Input
                  id="name"
                  {...form.register('name')}
                  placeholder="e.g., Jane Doe"
                  className="border-input focus:ring-primary focus:border-primary"
                   aria-invalid={!!form.formState.errors.name}
                   suppressHydrationWarning
                />
                {form.formState.errors.name && (
                  <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
                )}
              </div>

              {/* Company */}
              <div className="space-y-2">
                <Label htmlFor="company" className="font-medium">Company</Label>
                <Input
                  id="company"
                  {...form.register('company')}
                  placeholder="e.g., Acme Corporation"
                  className="border-input focus:ring-primary focus:border-primary"
                  suppressHydrationWarning
                />
                 {form.formState.errors.company && (
                   <p className="text-sm text-destructive">{form.formState.errors.company.message}</p>
                 )}
              </div>

               {/* Phone */}
              <div className="space-y-2">
                <Label htmlFor="phone" className="font-medium">Phone</Label>
                <Input
                  id="phone"
                  type="tel"
                  {...form.register('phone')}
                  placeholder="e.g., +1 555-987-6543"
                  className="border-input focus:ring-primary focus:border-primary"
                  suppressHydrationWarning
                />
                 {form.formState.errors.phone && (
                   <p className="text-sm text-destructive">{form.formState.errors.phone.message}</p>
                 )}
              </div>

            </div>

            {/* Right Column */}
            <div className="space-y-4">
               {/* Title */}
              <div className="space-y-2">
                <Label htmlFor="title" className="font-medium">Title</Label>
                <Input
                  id="title"
                  {...form.register('title')}
                  placeholder="e.g., Marketing Manager"
                  className="border-input focus:ring-primary focus:border-primary"
                  suppressHydrationWarning
                />
                {form.formState.errors.title && (
                  <p className="text-sm text-destructive">{form.formState.errors.title.message}</p>
                )}
              </div>

              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email" className="font-medium">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...form.register('email')}
                  placeholder="e.g., jane.doe@acme.com"
                  className="border-input focus:ring-primary focus:border-primary"
                   aria-invalid={!!form.formState.errors.email}
                   suppressHydrationWarning
                />
                {form.formState.errors.email && (
                  <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
                )}
              </div>

            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending} suppressHydrationWarning>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground" suppressHydrationWarning>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Creating...' : 'Create Contact'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
