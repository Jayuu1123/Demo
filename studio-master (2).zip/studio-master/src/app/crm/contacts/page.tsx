
'use client'; // Add "use client" directive

import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { getContacts } from '@/actions/crm/contacts';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ContactsTable } from './_components/contacts-table'; // Create this client component
import { ContactsTableSkeleton } from './_components/contacts-table-skeleton'; // Create this skeleton component

// This is now a Client Component because it uses useRouter
export default function ContactsPage() {
  const router = useRouter(); // Hook for navigation

  const handleAddContactClick = () => {
    router.push('/crm/contacts/new'); // Navigate to the new contact page
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Contacts</h1>
         <Button onClick={handleAddContactClick}>
             <PlusCircle className="mr-2 h-4 w-4" />
             Add Contact
         </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<ContactsTableSkeleton />}>
             <ContactsData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Server component logic moved to a separate component
// This part still runs on the server during initial load
async function ContactsData() {
  // Fetch data directly on the server
  const contacts = await getContacts();
  // Potential optimization: Add pagination or limit the number of contacts fetched initially

  if (!contacts) {
      // Handle case where fetching failed (e.g., show an error message)
       return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch contacts.</AlertDescription>
         </Alert>
       );
  }

  return <ContactsTable contacts={contacts} />;
}
