
'use client'; // Add "use client" directive

import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { getOpportunities } from '@/actions/crm/opportunities';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { OpportunitiesTable } from './_components/opportunities-table';
import { OpportunitiesTableSkeleton } from './_components/opportunities-table-skeleton';

// This is now a Client Component because it uses useRouter
export default function OpportunitiesPage() {
  const router = useRouter(); // Hook for navigation

  const handleAddOpportunityClick = () => {
    router.push('/crm/opportunities/new'); // Navigate to the new opportunity page
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Opportunities</h1>
         <Button onClick={handleAddOpportunityClick}>
           <PlusCircle className="mr-2 h-4 w-4" />
          Add Opportunity
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<OpportunitiesTableSkeleton />}>
             <OpportunitiesData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Server component to fetch data
async function OpportunitiesData() {
  const opportunities = await getOpportunities();

   if (!opportunities) {
      return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch opportunities.</AlertDescription>
         </Alert>
       );
   }

  return <OpportunitiesTable opportunities={opportunities} />;
}
