
'use client';

import { useState, useTransition } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Trash2, Edit, Loader2, CircleDollarSign, Calendar } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, parseISO, isValid } from 'date-fns';
import { deleteOpportunity, type Opportunity } from '@/actions/crm/opportunities';
import { type OpportunityStage } from '@/types/crm'; // Import type from types file
import { useToast } from "@/hooks/use-toast";

interface OpportunitiesTableProps {
  opportunities: Opportunity[];
}

export function OpportunitiesTable({ opportunities: initialOpportunities }: OpportunitiesTableProps) {
  const [opportunities, setOpportunities] = useState<Opportunity[]>(initialOpportunities);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const formatCurrency = (value: number | null | undefined) => {
     if (value == null) return '-';
     // Changed currency to INR
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value);
  }

  const formatDate = (dateString: string | null | undefined): string => {
      if (!dateString) return '-';
      try {
          const date = parseISO(dateString);
          if (isValid(date)) {
             return format(date, 'PP');
          }
      } catch (e) {
        console.error("Error formatting date:", dateString, e);
      }
      return 'Invalid Date';
  }

  const handleDelete = (id: string) => {
       if (!id || isPending) return;
       if (!confirm('Are you sure you want to delete this opportunity?')) {
           return;
       }
    startTransition(async () => {
      try {
           const result = await deleteOpportunity(id);
           if (result.success) {
               setOpportunities(prevOpps => prevOpps.filter(opp => opp.id !== id));
               toast({ title: "Success", description: result.message });
           } else {
               toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete opportunity." });
           }
      } catch (err) {
            let errorMessage = "An unexpected error occurred.";
             if (err instanceof Error) {
               errorMessage = err.message;
               if (err.message.includes('401')) {
                 errorMessage = "Database authentication failed (401). Check your TURSO_AUTH_TOKEN.";
               }
             }
            toast({ variant: "destructive", title: "Error", description: errorMessage });
            console.error("Delete opportunity error:", err);
      }
    });
  };

  const handleEditOpportunityClick = (opp: Opportunity) => {
     if (isPending) return;
     console.log("Edit opportunity clicked:", opp);
     // TODO: Open edit dialog
     toast({ title: "Info", description: "Edit functionality not implemented."});
  };

  const getStageVariant = (stage: OpportunityStage): "default" | "secondary" | "destructive" | "outline" => {
      switch (stage) {
          case 'Closed Won': return 'default';
          case 'Closed Lost': return 'destructive';
          case 'Negotiation': return 'secondary';
          case 'Proposal':
          case 'Qualification':
          default: return 'outline';
      }
  };

  return (
     <Table>
        <TableHeader>
            <TableRow>
                <TableHead className="pl-4">Opportunity Name</TableHead>
                <TableHead>Account</TableHead>
                <TableHead>Stage</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Close Date</TableHead>
                <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {opportunities.length === 0 ? (
            <TableRow>
                <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
                No opportunities found.
                </TableCell>
            </TableRow>
            ) : (
            opportunities.map((opp) => (
                <TableRow key={opp.id}>
                    <TableCell className="font-medium pl-4">{opp.name}</TableCell>
                    <TableCell>{opp.account || '-'}</TableCell>
                    <TableCell>
                        <Badge variant={getStageVariant(opp.stage)} className='text-xs'>{opp.stage}</Badge>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <CircleDollarSign className="h-3 w-3 text-muted-foreground" />
                        {formatCurrency(opp.amount)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {formatDate(opp.closeDate)}
                        </div>
                    </TableCell>
                    <TableCell className="pr-4">
                        <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleEditOpportunityClick(opp)} disabled={isPending}>
                                <Edit className="mr-2 h-4 w-4"/> Edit
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                                className="text-destructive focus:text-destructive focus:bg-destructive/10"
                                onClick={() => handleDelete(opp.id!)}
                                disabled={isPending}
                            >
                                {isPending ? (
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                ) : (
                                <Trash2 className="mr-2 h-4 w-4" />
                                )}
                            Delete
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                        </DropdownMenu>
                    </TableCell>
                </TableRow>
            ))
            )}
        </TableBody>
    </Table>
  );
}
