
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export function OpportunitiesTableSkeleton() {
  return (
    <Table>
        <TableHeader>
            <TableRow>
            <TableHead className="pl-4">Opportunity Name</TableHead>
            <TableHead>Account</TableHead>
            <TableHead>Stage</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Close Date</TableHead>
            <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {Array.from({ length: 5 }).map((_, index) => (
            <TableRow key={`skeleton-${index}`}>
                <TableCell className="pl-4"><Skeleton className="h-4 w-3/4" /></TableCell>
                <TableCell><Skeleton className="h-4 w-1/2" /></TableCell>
                <TableCell><Skeleton className="h-6 w-24 rounded-full" /></TableCell>
                <TableCell><Skeleton className="h-4 w-1/3" /></TableCell>
                <TableCell><Skeleton className="h-4 w-1/3" /></TableCell>
                <TableCell className="pr-4"><Skeleton className="h-8 w-8" /></TableCell>
            </TableRow>
            ))}
        </TableBody>
    </Table>
  );
}
