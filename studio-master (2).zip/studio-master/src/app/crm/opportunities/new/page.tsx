
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { CalendarIcon, Loader2, ArrowLeft } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { addOpportunity } from '@/actions/crm/opportunities'; // Import the server action
import { opportunityStages } from '@/types/crm'; // Import stages

// Schema based on the server action, excluding ID
const OpportunityFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  account: z.string().optional(),
  stage: z.enum(opportunityStages).default('Qualification'),
  amount: z.preprocess(
    (val) => (val === "" || val === null || val === undefined ? null : Number(val)),
    z.number().positive("Amount must be positive").nullable().optional()
  ),
  closeDate: z.date({ required_error: "Close date is required."}),
});

type OpportunityFormValues = z.infer<typeof OpportunityFormSchema>;

export default function NewOpportunityPage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<OpportunityFormValues>({
    resolver: zodResolver(OpportunityFormSchema),
    defaultValues: {
      name: '',
      account: '',
      stage: 'Qualification',
      amount: null,
      closeDate: new Date(),
    },
  });

  const onSubmit = (values: OpportunityFormValues) => {
    startTransition(async () => {
      const formData = new FormData();
      formData.append('name', values.name);
      if (values.account) formData.append('account', values.account);
      formData.append('stage', values.stage);
      if (values.amount !== null && values.amount !== undefined) {
           formData.append('amount', values.amount.toString());
      }
      formData.append('closeDate', format(values.closeDate, 'yyyy-MM-dd')); // Format date

      try {
        const result = await addOpportunity(formData);
        if (result.success && result.id) {
          toast({
            title: "Success",
            description: "Opportunity created successfully.",
          });
          router.push('/crm/opportunities'); // Redirect back to the list
        } else {
           let errorMessages = "An unknown error occurred.";
           if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
                errorMessages = Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ');
           } else if (result.message) {
                errorMessages = result.message;
           } else if (result.error instanceof Error) {
                 errorMessages = result.error.message;
                 if (result.error.message.includes('401')) {
                    errorMessages = "Database authentication failed (401). Check your TURSO_AUTH_TOKEN.";
                 }
            }

          toast({
            variant: "destructive",
            title: "Error creating Opportunity",
            description: errorMessages,
          });
           if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
                Object.entries(result.errors).forEach(([field, messages]) => {
                    if (messages && messages.length > 0) {
                       form.setError(field as keyof OpportunityFormValues, { type: 'server', message: messages[0] });
                    }
                });
            }
          console.error("Server validation errors:", result.errors || result.error);
        }
      } catch (error) {
        console.error("Failed to create opportunity:", error);
         let clientErrorMessage = "An unexpected error occurred.";
          if (error instanceof Error) {
            clientErrorMessage = error.message.includes('401')
              ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
              : error.message;
          }
        toast({
          variant: "destructive",
          title: "Error",
          description: clientErrorMessage,
        });
      }
    });
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back" suppressHydrationWarning>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Opportunity</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-2xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Opportunity Details</CardTitle>
            <CardDescription className="text-muted-foreground">Enter the details for the new sales opportunity.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Left Column */}
            <div className="space-y-4">
              {/* Opportunity Name */}
              <div className="space-y-2">
                <Label htmlFor="name" className="font-medium">Opportunity Name <span className="text-destructive">*</span></Label>
                <Input
                  id="name"
                  {...form.register('name')}
                  placeholder="e.g., Q3 Website Redesign Project"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.name}
                  suppressHydrationWarning
                />
                {form.formState.errors.name && (
                  <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
                )}
              </div>

              {/* Account */}
              <div className="space-y-2">
                <Label htmlFor="account" className="font-medium">Account (Customer)</Label>
                <Input
                  id="account"
                  {...form.register('account')}
                  placeholder="e.g., Acme Corporation"
                  className="border-input focus:ring-primary focus:border-primary"
                  suppressHydrationWarning
                />
                {form.formState.errors.account && (
                  <p className="text-sm text-destructive">{form.formState.errors.account.message}</p>
                )}
              </div>

               {/* Close Date */}
              <div className="space-y-2">
                 <Label htmlFor="closeDate" className="font-medium">Expected Close Date <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="closeDate"
                    render={({ field }) => (
                       <Popover>
                          <PopoverTrigger asChild>
                              <Button
                                  variant={"outline"}
                                  className={cn(
                                  "w-full justify-start text-left font-normal border-input bg-input hover:bg-accent",
                                  !field.value && "text-muted-foreground"
                                  )}
                                  suppressHydrationWarning
                              >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                              <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                              />
                          </PopoverContent>
                       </Popover>
                     )}
                   />
                   {form.formState.errors.closeDate && (
                      <p className="text-sm text-destructive">{form.formState.errors.closeDate.message}</p>
                   )}
              </div>

            </div>

            {/* Right Column */}
            <div className="space-y-4">
              {/* Stage */}
              <div className="space-y-2">
                <Label htmlFor="stage" className="font-medium">Stage <span className="text-destructive">*</span></Label>
                 <Controller
                   control={form.control}
                   name="stage"
                   render={({ field }) => (
                      <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger id="stage" className="border-input focus:ring-primary focus:border-primary" suppressHydrationWarning>
                          <SelectValue placeholder="Select stage" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border">
                          {opportunityStages.map((stageOption) => (
                            <SelectItem key={stageOption} value={stageOption}>{stageOption}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                   )}
                 />
                {form.formState.errors.stage && (
                  <p className="text-sm text-destructive">{form.formState.errors.stage.message}</p>
                )}
              </div>

              {/* Amount */}
              <div className="space-y-2">
                 {/* Updated currency label */}
                <Label htmlFor="amount" className="font-medium">Amount (₹)</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  {...form.register('amount')}
                  placeholder="e.g., 500000.00" // Example in INR
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.amount}
                  suppressHydrationWarning
                />
                {form.formState.errors.amount && (
                  <p className="text-sm text-destructive">{form.formState.errors.amount.message}</p>
                )}
              </div>
            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending} suppressHydrationWarning>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground" suppressHydrationWarning>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Creating...' : 'Create Opportunity'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
