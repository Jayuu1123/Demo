
'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, CircleDollarSign, Calendar, BookUser, Trash2, Edit, Loader2, Truck, Eye, Receipt } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, parseISO, isValid } from 'date-fns';
import { deletePurchaseOrder, type PurchaseOrder } from '@/actions/purchase/purchaseOrders';
import { type PurchaseOrderStatus } from '@/types/purchase'; // Import type from types file
import { useToast } from "@/hooks/use-toast";

interface PurchaseOrdersTableProps {
  purchaseOrders: PurchaseOrder[];
}

export function PurchaseOrdersTable({ purchaseOrders: initialPurchaseOrders }: PurchaseOrdersTableProps) {
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(initialPurchaseOrders);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();
  const router = useRouter();

  const formatCurrency = (value: number | null | undefined) => {
      if (value == null) return '-';
      // Changed currency to INR
      return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(value);
  }

  const formatDate = (dateString: string | null | undefined): string => {
      if (!dateString) return '-';
      try {
          const date = parseISO(dateString);
          if (isValid(date)) return format(date, 'PP');
      } catch (e) { console.error("Date format error:", e); }
      return 'Invalid Date';
  }

  const getStatusVariant = (status: PurchaseOrderStatus): "default" | "secondary" | "destructive" | "outline" => {
      switch (status?.toLowerCase()) {
          case 'draft': return 'outline';
          case 'ordered': return 'secondary';
          case 'partly received': return 'secondary';
          case 'received': return 'default';
          case 'completed': return 'default';
          case 'cancelled': return 'destructive';
          default: return 'outline';
      }
  }

  const handleDelete = (id: string) => {
      if (!id || isPending) return;
      if (!confirm('Are you sure you want to delete this Purchase Order?')) {
          return;
      }
      startTransition(async () => {
          try {
              const result = await deletePurchaseOrder(id);
              if (result.success) {
                  setPurchaseOrders(prevOrders => prevOrders.filter(po => po.id !== id));
                  toast({ title: "Success", description: result.message });
              } else {
                  toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete purchase order." });
              }
          } catch (err) {
              let errorMessage = "An unexpected error occurred.";
               if (err instanceof Error) {
                 errorMessage = err.message.includes('401')
                   ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                   : err.message;
               }
              toast({ variant: "destructive", title: "Error", description: errorMessage });
              console.error("Delete PO error:", err);
          }
      });
   };

   const handleEditPurchaseOrderClick = (po: PurchaseOrder) => {
      if (isPending) return;
      console.log("Edit Purchase Order clicked:", po);
      // TODO: Implement edit functionality
      // router.push(`/purchase/purchase-orders/${po.id}/edit`);
      toast({ title: "Info", description: "Edit functionality not yet implemented." });
   };

   const handleViewDetailsClick = (po: PurchaseOrder) => {
      if (isPending) return;
      console.log("View Details clicked:", po);
      // TODO: Implement view details functionality
      // router.push(`/purchase/purchase-orders/${po.id}`);
      toast({ title: "Info", description: "View details functionality not yet implemented." });
   };

   const handleReceiveItemsClick = (po: PurchaseOrder) => {
      if (isPending) return;
      console.log("Receive Items clicked:", po);
      // TODO: Implement receive items functionality
      toast({ title: "Info", description: "Receive items functionality not yet implemented." });
   }

   const handleCreateBillClick = (po: PurchaseOrder) => {
      if (isPending) return;
      console.log("Create Bill clicked:", po);
      // TODO: Implement create bill functionality
       toast({ title: "Info", description: "Create bill functionality not yet implemented." });
   }

  return (
    <Table>
        <TableHeader>
            <TableRow>
                <TableHead className="pl-4">PO ID</TableHead>
                <TableHead>Vendor</TableHead>
                <TableHead>Order Date</TableHead>
                <TableHead>Expected Delivery</TableHead>
                <TableHead>Total Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {purchaseOrders.length === 0 ? (
            <TableRow>
                <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                No purchase orders found.
                </TableCell>
            </TableRow>
            ) : (
            purchaseOrders.map((po) => (
                <TableRow key={po.id}>
                    <TableCell className="font-medium pl-4">{po.id}</TableCell>
                    <TableCell>
                        <div className="flex items-center gap-2">
                        <BookUser className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{po.vendor}</span>
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {formatDate(po.orderDate)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {formatDate(po.expectedDeliveryDate)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <CircleDollarSign className="h-3 w-3 text-muted-foreground" />
                        {formatCurrency(po.totalAmount)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <Badge variant={getStatusVariant(po.status)} className='text-xs'>{po.status}</Badge>
                    </TableCell>
                    <TableCell className="pr-4">
                        <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleViewDetailsClick(po)} disabled={isPending}>
                                <Eye className="mr-2 h-4 w-4"/> View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditPurchaseOrderClick(po)} disabled={isPending || po.status === 'Completed' || po.status === 'Cancelled'}>
                                <Edit className="mr-2 h-4 w-4"/> Edit
                            </DropdownMenuItem>
                            { (po.status === 'Ordered' || po.status === 'Partly Received') && (
                                <DropdownMenuItem onClick={() => handleReceiveItemsClick(po)} disabled={isPending}>
                                    <Truck className="mr-2 h-4 w-4"/> Receive Items
                                </DropdownMenuItem>
                            )}
                            { (po.status === 'Received' || po.status === 'Partly Received') && (
                                <DropdownMenuItem onClick={() => handleCreateBillClick(po)} disabled={isPending}>
                                    <Receipt className="mr-2 h-4 w-4"/> Create Bill
                                </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            {(po.status === 'Draft' || po.status === 'Cancelled') && (
                                <DropdownMenuItem
                                    className="text-destructive focus:text-destructive focus:bg-destructive/10"
                                    onClick={() => handleDelete(po.id!)}
                                    disabled={isPending}
                                >
                                    {isPending ? (
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    ) : (
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    )}
                                Delete
                                </DropdownMenuItem>
                            )}
                        </DropdownMenuContent>
                        </DropdownMenu>
                    </TableCell>
                </TableRow>
            ))
            )}
        </TableBody>
    </Table>
  );
}
