
import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Keep for navigation
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { getPurchaseOrders } from '@/actions/purchase/purchaseOrders';
import { PurchaseOrdersTable } from './_components/purchase-orders-table'; // Create this client component
import { PurchaseOrdersTableSkeleton } from './_components/purchase-orders-table-skeleton'; // Create this skeleton component

// This is now a Server Component
export default function PurchaseOrdersPage() {
  const router = useRouter(); // Keep for navigation

  const handleAddPurchaseOrderClick = () => {
     router.push('/purchase/purchase-orders/new');
   };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Purchase Orders</h1>
        <Button onClick={handleAddPurchaseOrderClick}>
          <PlusCircle className="mr-2 h-4 w-4" /> Add Purchase Order
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<PurchaseOrdersTableSkeleton />}>
             <PurchaseOrdersData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Server component to fetch data
async function PurchaseOrdersData() {
  const purchaseOrders = await getPurchaseOrders();

   if (!purchaseOrders) {
      return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch purchase orders.</AlertDescription>
         </Alert>
       );
   }

  return <PurchaseOrdersTable purchaseOrders={purchaseOrders} />;
}
