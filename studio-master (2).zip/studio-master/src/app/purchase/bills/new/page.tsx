
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { CalendarIcon, Loader2, ArrowLeft } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
// Assume an action `addBill` exists in `@/actions/purchase/bills`
// import { addBill } from '@/actions/purchase/bills';

// Define bill status options based on schema
const billStatusOptions = ['Draft', 'Submitted', 'Partly Paid', 'Paid', 'Cancelled'] as const;

// Define the Zod schema matching the database table
const BillFormSchema = z.object({
  vendor_id: z.string().min(1, "Vendor is required"), // Link to vendor table (consider lookup)
  po_id: z.string().optional(), // Link to purchase order
  bill_date: z.date({ required_error: "Bill date is required."}),
  due_date: z.date({ required_error: "Due date is required."}),
  total_amount: z.preprocess(
    (val) => (val === "" || val === null || val === undefined ? 0 : Number(val)),
    z.number().positive("Total amount must be positive")
  ),
  status: z.enum(billStatusOptions).default('Draft'),
});

type BillFormValues = z.infer<typeof BillFormSchema>;

export default function NewBillPage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<BillFormValues>({
    resolver: zodResolver(BillFormSchema),
    defaultValues: {
      vendor_id: '',
      po_id: '',
      bill_date: new Date(),
      due_date: new Date(new Date().setDate(new Date().getDate() + 30)), // Default due 30 days
      total_amount: 0,
      status: 'Draft',
    },
  });

  const onSubmit = (values: BillFormValues) => {
      toast({ title: "Info", description: "Bill creation not yet implemented." });
      console.log("Form Submitted (Not Implemented):", values);
    // TODO: Implement form submission logic using server action
    /*
    startTransition(async () => {
      const formData = new FormData();
      formData.append('vendor_id', values.vendor_id);
      if (values.po_id) formData.append('po_id', values.po_id);
      formData.append('bill_date', format(values.bill_date, 'yyyy-MM-dd'));
      formData.append('due_date', format(values.due_date, 'yyyy-MM-dd'));
      formData.append('total_amount', values.total_amount.toString());
      formData.append('status', values.status);

      try {
        // const result = await addBill(formData); // Call the server action
        // if (result.success && result.id) {
        //   toast({
        //     title: "Success",
        //     description: "Bill created successfully.",
        //   });
        //   router.push('/purchase/bills'); // Redirect back to the list
        // } else {
        //    const errorMessages = result.errors
        //       ? Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ')
        //       : result.message || "An unknown error occurred.";
        //   toast({
        //     variant: "destructive",
        //     title: "Error creating Bill",
        //     description: errorMessages,
        //   });
        //    if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
        //         Object.entries(result.errors).forEach(([field, messages]) => {
        //             if (messages && messages.length > 0) {
        //                form.setError(field as keyof BillFormValues, { type: 'server', message: messages[0] });
        //             }
        //         });
        //     }
        //   console.error("Server validation errors:", result.errors || result.error);
        // }
      } catch (error) {
        console.error("Failed to create bill:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred.",
        });
      }
    });
    */
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back" suppressHydrationWarning>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Bill</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-2xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Bill Information</CardTitle>
            <CardDescription className="text-muted-foreground">Enter details for the new vendor bill.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Left Column */}
            <div className="space-y-4">
              {/* Vendor ID */}
              <div className="space-y-2">
                <Label htmlFor="vendor_id" className="font-medium">Vendor <span className="text-destructive">*</span></Label>
                 {/* Consider using a searchable Select or Autocomplete */}
                <Input
                  id="vendor_id"
                  {...form.register('vendor_id')}
                  placeholder="Enter Vendor Name or ID"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.vendor_id}
                  suppressHydrationWarning
                />
                {form.formState.errors.vendor_id && (
                  <p className="text-sm text-destructive">{form.formState.errors.vendor_id.message}</p>
                )}
              </div>

              {/* Purchase Order ID */}
              <div className="space-y-2">
                <Label htmlFor="po_id" className="font-medium">Purchase Order ID (Optional)</Label>
                <Input
                  id="po_id"
                  {...form.register('po_id')}
                  placeholder="e.g., PO-101"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.po_id}
                  suppressHydrationWarning
                />
                {form.formState.errors.po_id && (
                  <p className="text-sm text-destructive">{form.formState.errors.po_id.message}</p>
                )}
              </div>

              {/* Total Amount */}
              <div className="space-y-2">
                 {/* Updated currency label */}
                <Label htmlFor="total_amount" className="font-medium">Total Amount (₹) <span className="text-destructive">*</span></Label>
                <Input
                  id="total_amount"
                  type="number"
                  step="0.01"
                  {...form.register('total_amount')}
                  placeholder="e.g., 150000.00" // Example in INR
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.total_amount}
                  suppressHydrationWarning
                />
                {form.formState.errors.total_amount && (
                  <p className="text-sm text-destructive">{form.formState.errors.total_amount.message}</p>
                )}
              </div>

            </div>

            {/* Right Column */}
            <div className="space-y-4">
               {/* Bill Date */}
              <div className="space-y-2">
                 <Label htmlFor="bill_date" className="font-medium">Bill Date <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="bill_date"
                    render={({ field }) => (
                      <Popover>
                          <PopoverTrigger asChild>
                              <Button
                                  variant={"outline"}
                                  className={cn(
                                  "w-full justify-start text-left font-normal border-input bg-input hover:bg-accent",
                                  !field.value && "text-muted-foreground"
                                  )}
                                  suppressHydrationWarning
                              >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                              <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                              />
                          </PopoverContent>
                       </Popover>
                    )}
                  />
                   {form.formState.errors.bill_date && (
                      <p className="text-sm text-destructive">{form.formState.errors.bill_date.message}</p>
                   )}
              </div>

              {/* Due Date */}
              <div className="space-y-2">
                 <Label htmlFor="due_date" className="font-medium">Due Date <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="due_date"
                    render={({ field }) => (
                      <Popover>
                          <PopoverTrigger asChild>
                              <Button
                                  variant={"outline"}
                                  className={cn(
                                  "w-full justify-start text-left font-normal border-input bg-input hover:bg-accent",
                                  !field.value && "text-muted-foreground"
                                  )}
                                  suppressHydrationWarning
                              >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                              <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                              />
                          </PopoverContent>
                       </Popover>
                    )}
                  />
                   {form.formState.errors.due_date && (
                      <p className="text-sm text-destructive">{form.formState.errors.due_date.message}</p>
                   )}
              </div>

               {/* Status */}
              <div className="space-y-2">
                <Label htmlFor="status" className="font-medium">Status <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger id="status" className="border-input focus:ring-primary focus:border-primary" suppressHydrationWarning>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border">
                          {billStatusOptions.map((statusOption) => (
                            <SelectItem key={statusOption} value={statusOption}>{statusOption}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                {form.formState.errors.status && (
                  <p className="text-sm text-destructive">{form.formState.errors.status.message}</p>
                )}
              </div>
            </div>

             {/* Placeholder for Bill Items */}
             <div className="md:col-span-2 space-y-2 pt-4">
                    <Label className="font-medium">Bill Items</Label>
                    <Card className="bg-muted/50 border-dashed border-border">
                        <CardContent className="p-6 text-center text-muted-foreground flex flex-col items-center justify-center min-h-[120px]">
                             <p className="text-sm">Items from the PO or added manually will appear here.</p>
                             <Button variant="secondary" size="sm" className="mt-3" disabled suppressHydrationWarning>+ Add Item</Button>
                        </CardContent>
                    </Card>
             </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending} suppressHydrationWarning>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground" suppressHydrationWarning>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Creating...' : 'Create Bill'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
