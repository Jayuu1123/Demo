
'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Truck, // Purchase Orders
  BookUser, // Vendors
  FileStack, // Bills
} from 'lucide-react';

// Define Purchase modules
const purchaseModules = [
  { name: 'Purchase Orders', href: '/purchase/purchase-orders', icon: Truck, description: 'Manage orders placed with suppliers.' },
  { name: 'Vendors', href: '/purchase/vendors', icon: BookUser, description: 'Manage supplier information.' },
  { name: 'Bills', href: '/purchase/bills', icon: FileStack, description: 'Track and manage supplier bills.' },
];

export default function PurchaseHomePage() {
  return (
    <>
      <h1 className="text-3xl font-semibold mb-6">Purchase Dashboard</h1>
      <p className="text-muted-foreground mb-8">
        Select a module below to manage your purchasing activities.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {purchaseModules.map((module) => (
          <Link href={module.href} key={module.name} passHref>
            <Card className="shadow-sm hover:shadow-lg transition-shadow duration-200 cursor-pointer h-full flex flex-col">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                <module.icon className="h-8 w-8 text-primary" />
                <CardTitle className="text-xl font-medium">{module.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground">{module.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}
