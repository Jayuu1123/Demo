
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, ArrowLeft } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
// Assume an action `addAccount` exists in `@/actions/finance/accounts`
// import { addAccount } from '@/actions/finance/accounts';

// Define account types based on schema
const accountTypes = ['Asset', 'Liability', 'Equity', 'Income', 'Expense'] as const;

// Define the Zod schema matching the database table
const AccountFormSchema = z.object({
  name: z.string().min(1, "Account name is required"),
  type: z.enum(accountTypes),
  currency: z.string().length(3, "Currency code must be 3 letters").default('INR'), // Default currency to INR
  balance: z.preprocess(
    (val) => (val === "" || val === null || val === undefined ? 0 : Number(val)),
    z.number().default(0) // Default balance to 0
  ),
});

type AccountFormValues = z.infer<typeof AccountFormSchema>;

export default function NewAccountPage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<AccountFormValues>({
    resolver: zodResolver(AccountFormSchema),
    defaultValues: {
      name: '',
      type: 'Expense', // Default type
      currency: 'INR', // Default currency to INR
      balance: 0,
    },
  });

  const onSubmit = (values: AccountFormValues) => {
      toast({ title: "Info", description: "Account creation not yet implemented." });
      console.log("Form Submitted (Not Implemented):", values);
    // TODO: Implement form submission logic using server action
    /*
    startTransition(async () => {
      const formData = new FormData();
      formData.append('name', values.name);
      formData.append('type', values.type);
      formData.append('currency', values.currency);
      formData.append('balance', values.balance.toString());

      try {
        // const result = await addAccount(formData); // Call the server action
        // if (result.success && result.id) {
        //   toast({
        //     title: "Success",
        //     description: "Account created successfully.",
        //   });
        //   router.push('/finance/accounts'); // Redirect back to the list
        // } else {
        //    const errorMessages = result.errors
        //       ? Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ')
        //       : result.message || "An unknown error occurred.";
        //   toast({
        //     variant: "destructive",
        //     title: "Error creating Account",
        //     description: errorMessages,
        //   });
        //    if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
        //         Object.entries(result.errors).forEach(([field, messages]) => {
        //             if (messages && messages.length > 0) {
        //                form.setError(field as keyof AccountFormValues, { type: 'server', message: messages[0] });
        //             }
        //         });
        //     }
        //   console.error("Server validation errors:", result.errors || result.error);
        // }
      } catch (error) {
        console.error("Failed to create account:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred.",
        });
      }
    });
    */
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back" suppressHydrationWarning>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Account</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-lg mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Account Details</CardTitle>
            <CardDescription className="text-muted-foreground">Enter details for the new financial account.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 space-y-4">

            {/* Account Name */}
            <div className="space-y-2">
              <Label htmlFor="name" className="font-medium">Account Name <span className="text-destructive">*</span></Label>
              <Input
                id="name"
                {...form.register('name')}
                placeholder="e.g., Office Supplies, Bank Account"
                className="border-input focus:ring-primary focus:border-primary"
                aria-invalid={!!form.formState.errors.name}
                suppressHydrationWarning
              />
              {form.formState.errors.name && (
                <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
              )}
            </div>

            {/* Account Type */}
            <div className="space-y-2">
              <Label htmlFor="type" className="font-medium">Account Type <span className="text-destructive">*</span></Label>
              <Controller
                 control={form.control}
                 name="type"
                 render={({ field }) => (
                   <Select onValueChange={field.onChange} value={field.value}>
                     <SelectTrigger id="type" className="border-input focus:ring-primary focus:border-primary" suppressHydrationWarning>
                       <SelectValue placeholder="Select account type" />
                     </SelectTrigger>
                     <SelectContent className="bg-popover border-border">
                       {accountTypes.map((typeOption) => (
                         <SelectItem key={typeOption} value={typeOption}>{typeOption}</SelectItem>
                       ))}
                     </SelectContent>
                   </Select>
                 )}
               />
              {form.formState.errors.type && (
                <p className="text-sm text-destructive">{form.formState.errors.type.message}</p>
              )}
            </div>

            {/* Currency */}
            <div className="space-y-2">
              <Label htmlFor="currency" className="font-medium">Currency</Label>
              <Input
                id="currency"
                {...form.register('currency')}
                placeholder="e.g., INR" // Updated placeholder
                maxLength={3}
                className="border-input focus:ring-primary focus:border-primary"
                aria-invalid={!!form.formState.errors.currency}
                suppressHydrationWarning
              />
               {form.formState.errors.currency && (
                 <p className="text-sm text-destructive">{form.formState.errors.currency.message}</p>
               )}
               <p className="text-xs text-muted-foreground">Default is INR. Use 3-letter code.</p> {/* Updated description */}
            </div>

             {/* Opening Balance */}
            <div className="space-y-2">
               {/* Updated currency label */}
              <Label htmlFor="balance" className="font-medium">Opening Balance (₹)</Label>
              <Input
                id="balance"
                type="number"
                step="0.01"
                {...form.register('balance')}
                placeholder="0.00"
                className="border-input focus:ring-primary focus:border-primary"
                aria-invalid={!!form.formState.errors.balance}
                suppressHydrationWarning
              />
               {form.formState.errors.balance && (
                 <p className="text-sm text-destructive">{form.formState.errors.balance.message}</p>
               )}
            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending} suppressHydrationWarning>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground" suppressHydrationWarning>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Creating...' : 'Create Account'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
