
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { CalendarIcon, Loader2, ArrowLeft } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
// Assume an action `addPayment` exists in `@/actions/finance/payments`
// import { addPayment } from '@/actions/finance/payments';

// Define payment status options based on schema
const paymentStatusOptions = ['Draft', 'Cleared', 'Reconciled', 'Cancelled'] as const;
const partyTypes = ['Customer', 'Supplier'] as const;

// Define the Zod schema matching the database table
const PaymentFormSchema = z.object({
  date: z.date({ required_error: "Payment date is required."}),
  party_id: z.string().optional(), // Link to party (Customer/Supplier)
  party_type: z.enum(partyTypes).optional(),
  amount: z.preprocess(
    (val) => (val === "" || val === null || val === undefined ? 0 : Number(val)),
    z.number().positive("Amount must be positive")
  ),
  reference: z.string().optional(),
  payment_method: z.string().optional(),
  status: z.enum(paymentStatusOptions).default('Cleared'),
});

type PaymentFormValues = z.infer<typeof PaymentFormSchema>;

export default function NewPaymentPage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<PaymentFormValues>({
    resolver: zodResolver(PaymentFormSchema),
    defaultValues: {
      date: new Date(),
      party_id: '',
      party_type: undefined,
      amount: 0,
      reference: '',
      payment_method: '',
      status: 'Cleared',
    },
  });

   // Conditional validation: party_id is required if party_type is set
   // This needs more complex client-side logic or server-side check
   // For simplicity, we'll rely on user input correctness or server validation


  const onSubmit = (values: PaymentFormValues) => {
      toast({ title: "Info", description: "Payment recording not yet implemented." });
      console.log("Form Submitted (Not Implemented):", values);
    // TODO: Implement form submission logic using server action
    /*
    startTransition(async () => {
      const formData = new FormData();
      formData.append('date', format(values.date, 'yyyy-MM-dd'));
      if (values.party_id) formData.append('party_id', values.party_id);
      if (values.party_type) formData.append('party_type', values.party_type);
      formData.append('amount', values.amount.toString());
      if (values.reference) formData.append('reference', values.reference);
      if (values.payment_method) formData.append('payment_method', values.payment_method);
      formData.append('status', values.status);

      try {
        // const result = await addPayment(formData); // Call the server action
        // if (result.success && result.id) {
        //   toast({
        //     title: "Success",
        //     description: "Payment recorded successfully.",
        //   });
        //   router.push('/finance/payments'); // Redirect back to the list
        // } else {
        //    const errorMessages = result.errors
        //       ? Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ')
        //       : result.message || "An unknown error occurred.";
        //   toast({
        //     variant: "destructive",
        //     title: "Error recording Payment",
        //     description: errorMessages,
        //   });
        //    if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
        //         Object.entries(result.errors).forEach(([field, messages]) => {
        //             if (messages && messages.length > 0) {
        //                form.setError(field as keyof PaymentFormValues, { type: 'server', message: messages[0] });
        //             }
        //         });
        //     }
        //   console.error("Server validation errors:", result.errors || result.error);
        // }
      } catch (error) {
        console.error("Failed to record payment:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred.",
        });
      }
    });
    */
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back" suppressHydrationWarning>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Payment</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-2xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Payment Details</CardTitle>
            <CardDescription className="text-muted-foreground">Enter details for the new payment record.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Left Column */}
            <div className="space-y-4">
              {/* Payment Date */}
              <div className="space-y-2">
                 <Label htmlFor="date" className="font-medium">Payment Date <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <Popover>
                          <PopoverTrigger asChild>
                              <Button
                                  variant={"outline"}
                                  className={cn(
                                  "w-full justify-start text-left font-normal border-input bg-input hover:bg-accent",
                                  !field.value && "text-muted-foreground"
                                  )}
                                  suppressHydrationWarning
                              >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                              <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                              />
                          </PopoverContent>
                       </Popover>
                    )}
                  />
                   {form.formState.errors.date && (
                      <p className="text-sm text-destructive">{form.formState.errors.date.message}</p>
                   )}
              </div>

               {/* Amount */}
              <div className="space-y-2">
                 {/* Updated currency label */}
                <Label htmlFor="amount" className="font-medium">Amount (₹) <span className="text-destructive">*</span></Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  {...form.register('amount')}
                  placeholder="e.g., 10000.00" // Example in INR
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.amount}
                  suppressHydrationWarning
                />
                {form.formState.errors.amount && (
                  <p className="text-sm text-destructive">{form.formState.errors.amount.message}</p>
                )}
              </div>

                {/* Payment Method */}
               <div className="space-y-2">
                <Label htmlFor="payment_method" className="font-medium">Payment Method</Label>
                <Input
                    id="payment_method"
                    {...form.register('payment_method')}
                    placeholder="e.g., Bank Transfer, Credit Card"
                    className="border-input focus:ring-primary focus:border-primary"
                    aria-invalid={!!form.formState.errors.payment_method}
                    suppressHydrationWarning
                />
                {form.formState.errors.payment_method && (
                    <p className="text-sm text-destructive">{form.formState.errors.payment_method.message}</p>
                )}
               </div>

            </div>

            {/* Right Column */}
            <div className="space-y-4">
               {/* Party Type */}
               <div className="space-y-2">
                    <Label htmlFor="party_type" className="font-medium">Party Type</Label>
                    <Controller
                        control={form.control}
                        name="party_type"
                        render={({ field }) => (
                        <Select onValueChange={field.onChange} value={field.value ?? ''}>
                            <SelectTrigger id="party_type" className="border-input focus:ring-primary focus:border-primary" suppressHydrationWarning>
                            <SelectValue placeholder="Select party type" />
                            </SelectTrigger>
                            <SelectContent className="bg-popover border-border">
                                <SelectItem value="">-- Select --</SelectItem>
                                {partyTypes.map((typeOption) => (
                                    <SelectItem key={typeOption} value={typeOption}>{typeOption}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        )}
                    />
                    {form.formState.errors.party_type && (
                        <p className="text-sm text-destructive">{form.formState.errors.party_type.message}</p>
                    )}
               </div>

                {/* Party ID (e.g., Customer/Supplier Name/ID) */}
                <div className="space-y-2">
                    <Label htmlFor="party_id" className="font-medium">Party Name/ID</Label>
                    {/* Consider replacing with a searchable Select or Autocomplete */}
                    <Input
                        id="party_id"
                        {...form.register('party_id')}
                        placeholder="Enter Customer or Supplier name/ID"
                        className="border-input focus:ring-primary focus:border-primary"
                        aria-invalid={!!form.formState.errors.party_id}
                        suppressHydrationWarning
                    />
                    {form.formState.errors.party_id && (
                        <p className="text-sm text-destructive">{form.formState.errors.party_id.message}</p>
                    )}
                </div>

                {/* Reference */}
               <div className="space-y-2">
                <Label htmlFor="reference" className="font-medium">Reference</Label>
                <Input
                    id="reference"
                    {...form.register('reference')}
                    placeholder="e.g., Invoice #INV-001, Check #123"
                    className="border-input focus:ring-primary focus:border-primary"
                    aria-invalid={!!form.formState.errors.reference}
                    suppressHydrationWarning
                />
                {form.formState.errors.reference && (
                    <p className="text-sm text-destructive">{form.formState.errors.reference.message}</p>
                )}
               </div>

               {/* Status */}
              <div className="space-y-2">
                <Label htmlFor="status" className="font-medium">Status <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger id="status" className="border-input focus:ring-primary focus:border-primary" suppressHydrationWarning>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border">
                          {paymentStatusOptions.map((statusOption) => (
                            <SelectItem key={statusOption} value={statusOption}>{statusOption}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                {form.formState.errors.status && (
                  <p className="text-sm text-destructive">{form.formState.errors.status.message}</p>
                )}
              </div>
            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending} suppressHydrationWarning>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground" suppressHydrationWarning>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Recording...' : 'Record Payment'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
