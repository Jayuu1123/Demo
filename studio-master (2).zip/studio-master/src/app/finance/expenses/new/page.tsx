
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea"; // Import Textarea
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { CalendarIcon, Loader2, ArrowLeft, ImagePlus } from 'lucide-react'; // Import ImagePlus for receipt
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
// Assume an action `addExpense` exists in `@/actions/finance/expenses`
// import { addExpense } from '@/actions/finance/expenses';

// Define the Zod schema matching the database table
const ExpenseFormSchema = z.object({
  date: z.date({ required_error: "Expense date is required."}),
  category: z.string().min(1, "Category is required"),
  description: z.string().optional(),
  amount: z.preprocess(
    (val) => (val === "" || val === null || val === undefined ? 0 : Number(val)),
    z.number().positive("Amount must be positive")
  ),
  paid_by: z.string().optional(), // E.g., Employee name, Petty cash, Company card
  // receipt_url: z.string().url("Invalid URL format").optional(), // Validate as URL if needed
  receipt_url: z.string().optional(), // Keep as optional string for now
});

type ExpenseFormValues = z.infer<typeof ExpenseFormSchema>;

export default function NewExpensePage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<ExpenseFormValues>({
    resolver: zodResolver(ExpenseFormSchema),
    defaultValues: {
      date: new Date(),
      category: '',
      description: '',
      amount: 0,
      paid_by: '',
      receipt_url: '',
    },
  });

  const onSubmit = (values: ExpenseFormValues) => {
      toast({ title: "Info", description: "Expense recording not yet implemented." });
      console.log("Form Submitted (Not Implemented):", values);
    // TODO: Implement form submission logic using server action
    /*
    startTransition(async () => {
      const formData = new FormData();
      formData.append('date', format(values.date, 'yyyy-MM-dd'));
      formData.append('category', values.category);
      if (values.description) formData.append('description', values.description);
      formData.append('amount', values.amount.toString());
      if (values.paid_by) formData.append('paid_by', values.paid_by);
      if (values.receipt_url) formData.append('receipt_url', values.receipt_url);
      // Handle file upload for receipt if implementing that

      try {
        // const result = await addExpense(formData); // Call the server action
        // if (result.success && result.id) {
        //   toast({
        //     title: "Success",
        //     description: "Expense recorded successfully.",
        //   });
        //   router.push('/finance/expenses'); // Redirect back to the list
        // } else {
        //    const errorMessages = result.errors
        //       ? Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ')
        //       : result.message || "An unknown error occurred.";
        //   toast({
        //     variant: "destructive",
        //     title: "Error recording Expense",
        //     description: errorMessages,
        //   });
        //    if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
        //         Object.entries(result.errors).forEach(([field, messages]) => {
        //             if (messages && messages.length > 0) {
        //                form.setError(field as keyof ExpenseFormValues, { type: 'server', message: messages[0] });
        //             }
        //         });
        //     }
        //   console.error("Server validation errors:", result.errors || result.error);
        // }
      } catch (error) {
        console.error("Failed to record expense:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred.",
        });
      }
    });
    */
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back" suppressHydrationWarning>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Expense</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-2xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Expense Details</CardTitle>
            <CardDescription className="text-muted-foreground">Enter details for the new company expense.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Left Column */}
            <div className="space-y-4">
              {/* Expense Date */}
              <div className="space-y-2">
                 <Label htmlFor="date" className="font-medium">Expense Date <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <Popover>
                          <PopoverTrigger asChild>
                              <Button
                                  variant={"outline"}
                                  className={cn(
                                  "w-full justify-start text-left font-normal border-input bg-input hover:bg-accent",
                                  !field.value && "text-muted-foreground"
                                  )}
                                  suppressHydrationWarning
                              >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                              <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                              />
                          </PopoverContent>
                       </Popover>
                    )}
                  />
                   {form.formState.errors.date && (
                      <p className="text-sm text-destructive">{form.formState.errors.date.message}</p>
                   )}
              </div>

               {/* Amount */}
              <div className="space-y-2">
                 {/* Updated currency label */}
                <Label htmlFor="amount" className="font-medium">Amount (₹) <span className="text-destructive">*</span></Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  {...form.register('amount')}
                  placeholder="e.g., 5500.00" // Example in INR
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.amount}
                  suppressHydrationWarning
                />
                {form.formState.errors.amount && (
                  <p className="text-sm text-destructive">{form.formState.errors.amount.message}</p>
                )}
              </div>

                {/* Paid By */}
               <div className="space-y-2">
                <Label htmlFor="paid_by" className="font-medium">Paid By</Label>
                <Input
                    id="paid_by"
                    {...form.register('paid_by')}
                    placeholder="e.g., John Doe, Company Card"
                    className="border-input focus:ring-primary focus:border-primary"
                    aria-invalid={!!form.formState.errors.paid_by}
                    suppressHydrationWarning
                />
                {form.formState.errors.paid_by && (
                    <p className="text-sm text-destructive">{form.formState.errors.paid_by.message}</p>
                )}
               </div>

            </div>

            {/* Right Column */}
            <div className="space-y-4">
               {/* Category */}
               <div className="space-y-2">
                    <Label htmlFor="category" className="font-medium">Category <span className="text-destructive">*</span></Label>
                    <Input
                        id="category"
                        {...form.register('category')}
                        placeholder="e.g., Office Supplies, Travel, Meals"
                        className="border-input focus:ring-primary focus:border-primary"
                        aria-invalid={!!form.formState.errors.category}
                        suppressHydrationWarning
                    />
                    {form.formState.errors.category && (
                        <p className="text-sm text-destructive">{form.formState.errors.category.message}</p>
                    )}
               </div>

                {/* Description */}
                <div className="space-y-2">
                    <Label htmlFor="description" className="font-medium">Description</Label>
                    <Textarea
                        id="description"
                        {...form.register('description')}
                        placeholder="Enter a brief description of the expense..."
                        rows={3}
                        className="resize-y border-input focus:ring-primary focus:border-primary"
                        suppressHydrationWarning
                    />
                    {form.formState.errors.description && (
                        <p className="text-sm text-destructive">{form.formState.errors.description.message}</p>
                    )}
                </div>

                 {/* Receipt Upload Placeholder */}
                <div className="space-y-2">
                    <Label htmlFor="receipt" className="font-medium">Receipt</Label>
                    <div className="flex items-center justify-center w-full h-24 border-2 border-dashed border-border rounded-lg bg-muted/50 hover:bg-muted/70 transition-colors cursor-pointer">
                        <div className="text-center">
                        <ImagePlus className="mx-auto h-6 w-6 text-muted-foreground" />
                        <p className="mt-1 text-sm text-muted-foreground">Upload Receipt</p>
                        <p className="text-xs text-muted-foreground">(Upload not implemented)</p>
                        <Input id="receipt" type="file" className="sr-only" disabled suppressHydrationWarning/>
                        </div>
                    </div>
                    {/* Optional: Input for receipt URL if not uploading */}
                    {/* <Input
                        id="receipt_url"
                        {...form.register('receipt_url')}
                        placeholder="Or enter receipt URL"
                        className="border-input focus:ring-primary focus:border-primary mt-2"
                        aria-invalid={!!form.formState.errors.receipt_url}
                    />
                    {form.formState.errors.receipt_url && (
                        <p className="text-sm text-destructive">{form.formState.errors.receipt_url.message}</p>
                    )} */}
                </div>
            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending} suppressHydrationWarning>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground" suppressHydrationWarning>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Recording...' : 'Record Expense'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
