'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ListChecks, // Chart of Accounts
  Receipt, // Invoices
  Landmark, // Payments (or Banknote)
  CreditCard, // Expenses
  AreaChart, // Reports
} from 'lucide-react';

// Define Finance modules
const financeModules = [
  { name: 'Chart of Accounts', href: '/finance/accounts', icon: ListChecks, description: 'Manage your company\'s financial accounts.' },
  // Linking Finance Invoices to Sales Invoices for now
  { name: 'Invoices', href: '/sales/invoices', icon: Receipt, description: 'View and manage customer invoices.' },
  { name: 'Payments', href: '/finance/payments', icon: Landmark, description: 'Track incoming and outgoing payments.' },
  { name: 'Expenses', href: '/finance/expenses', icon: CreditCard, description: 'Record and manage company expenses.' },
  { name: 'Reports', href: '/finance/reports', icon: AreaChart, description: 'Generate financial reports.' },
];

export default function FinanceHomePage() {
  return (
    <>
      <h1 className="text-3xl font-semibold mb-6">Finance Dashboard</h1>
      <p className="text-muted-foreground mb-8">
        Select a module below to manage your financial operations.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {financeModules.map((module) => (
          <Link href={module.href} key={module.name} passHref>
            <Card className="shadow-sm hover:shadow-lg transition-shadow duration-200 cursor-pointer h-full flex flex-col">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                <module.icon className="h-8 w-8 text-primary" />
                <CardTitle className="text-xl font-medium">{module.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground">{module.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}
