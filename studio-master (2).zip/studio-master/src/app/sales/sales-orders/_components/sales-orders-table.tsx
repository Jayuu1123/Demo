
'use client';

import { useState, useTransition, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, CircleDollarSign, Calendar, User, Truck, Trash2, Edit, Loader2, Receipt, Ban, FileOutput } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, parseISO, isValid } from 'date-fns';
import { getSalesOrders, deleteSalesOrder, cancelSalesOrder, createInvoiceFromSalesOrder, type SalesOrder } from '@/actions/sales/salesOrders';
import { type SalesOrderStatus } from '@/types/sales'; // Import type from types file
import { useToast } from "@/hooks/use-toast";

interface SalesOrdersTableProps {
  salesOrders: SalesOrder[];
}

export function SalesOrdersTable({ salesOrders: initialSalesOrders }: SalesOrdersTableProps) {
  const [salesOrders, setSalesOrders] = useState<SalesOrder[]>(initialSalesOrders);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  // Function to refetch sales orders, needed after cancel/invoice creation
  const fetchSalesOrders = async () => {
      // No setLoading for background refetch
      try {
          const fetchedOrders = await getSalesOrders(); // Call server action
           if (fetchedOrders) {
               setSalesOrders(fetchedOrders);
           } else {
                toast({ variant: "destructive", title: "Error", description: "Could not refresh sales order list." });
           }
      } catch (err) {
          let errorMessage = "An error occurred while refreshing sales orders.";
           if (err instanceof Error) {
                errorMessage = err.message.includes('401')
                  ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                  : err.message;
           }
          console.error("Failed to refetch sales orders:", err);
           toast({ variant: "destructive", title: "Error", description: errorMessage });
      }
  };

  const formatCurrency = (value: number | null | undefined) => {
      if (value == null) return '-';
      // Changed currency to INR
    return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
  }

  const formatDate = (dateString: string | null | undefined): string => {
      if (!dateString) return '-';
      try {
          const date = parseISO(dateString);
          if (isValid(date)) {
              return format(date, 'PP');
          }
      } catch (e) { console.error("Date format error:", e) }
      return 'Invalid Date';
  }

 const getStatusVariant = (status: SalesOrderStatus): "default" | "secondary" | "destructive" | "outline" => {
      switch (status?.toLowerCase()) {
          case 'to deliver and bill': return 'secondary';
          case 'to bill': return 'secondary';
          case 'delivered': return 'outline';
          case 'completed': return 'default';
          case 'cancelled': return 'destructive';
          case 'draft': return 'outline';
          default: return 'outline';
      }
  }

  const handleDelete = (id: string) => {
      if (!id || isPending) return;
      if (!confirm('Are you sure you want to delete this Sales Order? This action cannot be undone.')) {
          return;
      }
    startTransition(async () => {
      try {
          const result = await deleteSalesOrder(id);
          if (result.success) {
              setSalesOrders(prevOrders => prevOrders.filter(so => so.id !== id));
              toast({ title: "Success", description: result.message });
          } else {
              toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete Sales Order." });
          }
      } catch (err) {
           let errorMessage = "An unexpected error occurred.";
           if (err instanceof Error) {
                errorMessage = err.message.includes('401')
                  ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                  : err.message;
           }
           toast({ variant: "destructive", title: "Error", description: errorMessage });
           console.error("Delete SO error:", err);
      }
    });
  };

   const handleCancel = (id: string) => {
       if (!id || isPending) return;
       if (!confirm('Are you sure you want to cancel this Sales Order?')) {
           return;
       }
       startTransition(async () => {
           try {
               const result = await cancelSalesOrder(id);
               if (result.success) {
                   await fetchSalesOrders(); // Refetch needed
                   toast({ title: "Success", description: result.message });
               } else {
                   toast({ variant: "destructive", title: "Error", description: result.message || "Failed to cancel Sales Order." });
               }
           } catch (err) {
               let errorMessage = "An unexpected error occurred while cancelling.";
                 if (err instanceof Error) {
                    errorMessage = err.message.includes('401')
                      ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                      : err.message;
                 }
               toast({ variant: "destructive", title: "Error", description: errorMessage });
               console.error("Cancel SO error:", err);
           }
       });
   };

  const handleCreateInvoice = (id: string) => {
    if (!id || isPending) return;
    startTransition(async () => {
        try {
            const result = await createInvoiceFromSalesOrder(id);
            if (result.success) {
                await fetchSalesOrders(); // Refetch needed
                toast({ title: "Success", description: result.message });
                // TODO: Optionally revalidate invoices path or navigate
            } else {
                toast({ variant: "destructive", title: "Error", description: result.message || "Failed to create invoice." });
            }
        } catch (err) {
             let errorMessage = "An unexpected error occurred during invoice creation.";
             if (err instanceof Error) {
                errorMessage = err.message.includes('401')
                  ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                  : err.message;
             }
            toast({ variant: "destructive", title: "Error", description: errorMessage });
            console.error("Create Invoice error:", err);
        }
    });
  };

  const handleEditSalesOrderClick = (so: SalesOrder) => {
     if (isPending) return;
     console.log("Edit Sales Order clicked:", so);
     // TODO: Open edit dialog
      toast({ title: "Info", description: "Edit functionality not implemented."});
   };

  return (
    <Table>
        <TableHeader>
            <TableRow>
                <TableHead className="pl-4">Order ID</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Order Date</TableHead>
                <TableHead>Delivery Date</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {salesOrders.length === 0 ? (
            <TableRow>
                <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                No sales orders found.
                </TableCell>
            </TableRow>
            ) : (
            salesOrders.map((so) => (
                <TableRow key={so.id}>
                    <TableCell className="font-medium pl-4">{so.id}</TableCell>
                    <TableCell>
                        <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{so.customer}</span>
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {formatDate(so.orderDate)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Truck className="h-3 w-3 text-muted-foreground" />
                        {formatDate(so.deliveryDate)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <CircleDollarSign className="h-3 w-3 text-muted-foreground" />
                        {formatCurrency(so.total)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <Badge variant={getStatusVariant(so.status)} className='text-xs'>{so.status}</Badge>
                    </TableCell>
                    <TableCell className="pr-4">
                        <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleEditSalesOrderClick(so)} disabled={isPending || so.status === 'Completed' || so.status === 'Cancelled'}>
                                <Edit className="mr-2 h-4 w-4"/> Edit
                            </DropdownMenuItem>
                            {(so.status === 'To Deliver and Bill' || so.status === 'To Bill' || so.status === 'Delivered') && (
                                <DropdownMenuItem onClick={() => handleCreateInvoice(so.id!)} disabled={isPending}>
                                <Receipt className="mr-2 h-4 w-4"/> Create Invoice
                                </DropdownMenuItem>
                            )}
                            {so.status === 'To Deliver and Bill' && (
                                <DropdownMenuItem onClick={() => console.log(`Create Delivery Note for ${so.id}`)} disabled> {/* TODO: Enable */}
                                <FileOutput className="mr-2 h-4 w-4"/> Create Delivery Note
                                </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            {so.status !== 'Cancelled' && so.status !== 'Completed' && (
                                <DropdownMenuItem className="text-orange-600 focus:text-orange-600 focus:bg-orange-100" onClick={() => handleCancel(so.id!)} disabled={isPending}>
                                    <Ban className="mr-2 h-4 w-4" /> Cancel Order
                                </DropdownMenuItem>
                            )}
                            {(so.status === 'Draft' || so.status === 'Cancelled') && (
                                <DropdownMenuItem
                                    className="text-destructive focus:text-destructive focus:bg-destructive/10"
                                    onClick={() => handleDelete(so.id!)}
                                    disabled={isPending}
                                >
                                    {isPending ? (
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    ) : (
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    )}
                                Delete
                                </DropdownMenuItem>
                            )}
                        </DropdownMenuContent>
                        </DropdownMenu>
                    </TableCell>
                </TableRow>
            ))
            )}
        </TableBody>
    </Table>
  );
}
