
'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { CalendarIcon, Loader2, ArrowLeft } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { addSalesOrder } from '@/actions/sales/salesOrders'; // Import the server action
import { salesOrderStatusOptions } from '@/types/sales'; // Import status options

// Schema based on the server action, excluding ID
const SalesOrderFormSchema = z.object({
  customer: z.string().min(1, "Customer name is required"),
  orderDate: z.date({ required_error: "Order date is required."}),
  deliveryDate: z.date({ required_error: "Delivery date is required."}),
  total: z.preprocess(
    (val) => (val === "" || val === null || val === undefined ? null : Number(val)),
     z.number().positive("Total must be a positive number").nullable().optional()
   ),
  status: z.enum(salesOrderStatusOptions).default('Draft'),
});

type SalesOrderFormValues = z.infer<typeof SalesOrderFormSchema>;

export default function NewSalesOrderPage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<SalesOrderFormValues>({
    resolver: zodResolver(SalesOrderFormSchema),
    defaultValues: {
      customer: '',
      orderDate: new Date(),
      deliveryDate: new Date(new Date().setDate(new Date().getDate() + 7)), // Default delivery 7 days from now
      total: null,
      status: 'Draft',
    },
  });

  const onSubmit = (values: SalesOrderFormValues) => {
    startTransition(async () => {
      const formData = new FormData();
      formData.append('customer', values.customer);
      formData.append('orderDate', format(values.orderDate, 'yyyy-MM-dd'));
      formData.append('deliveryDate', format(values.deliveryDate, 'yyyy-MM-dd'));
      if (values.total !== null && values.total !== undefined) {
           formData.append('total', values.total.toString());
      }
      formData.append('status', values.status);

      try {
        const result = await addSalesOrder(formData);
        if (result.success && result.id) {
          toast({
            title: "Success",
            description: "Sales Order created successfully.",
          });
          router.push('/sales/sales-orders'); // Redirect back to the list
        } else {
           let errorMessages = "An unknown error occurred.";
           if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
                errorMessages = Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ');
            } else if (result.message) {
                errorMessages = result.message;
                if (result.message.includes('401')) {
                    errorMessages = "Database authentication failed (401). Check your TURSO_AUTH_TOKEN.";
                 }
            } else if (result.error instanceof Error) {
                 errorMessages = result.error.message;
                  if (result.error.message.includes('401')) {
                     errorMessages = "Database authentication failed (401). Check your TURSO_AUTH_TOKEN.";
                  }
             }
          toast({
            variant: "destructive",
            title: "Error creating Sales Order",
            description: errorMessages,
          });
           if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
                Object.entries(result.errors).forEach(([field, messages]) => {
                    if (messages && messages.length > 0) {
                       form.setError(field as keyof SalesOrderFormValues, { type: 'server', message: messages[0] });
                    }
                });
            }
          console.error("Server validation errors:", result.errors || result.error);
        }
      } catch (error) {
        console.error("Failed to create sales order:", error);
        let clientErrorMessage = "An unexpected error occurred.";
          if (error instanceof Error) {
            clientErrorMessage = error.message.includes('401')
              ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
              : error.message;
          }
        toast({
          variant: "destructive",
          title: "Error",
          description: clientErrorMessage,
        });
      }
    });
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back" suppressHydrationWarning>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Sales Order</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-2xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Sales Order Details</CardTitle>
            <CardDescription className="text-muted-foreground">Enter the details for the new sales order.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Left Column */}
            <div className="space-y-4">
              {/* Customer Name */}
              <div className="space-y-2">
                <Label htmlFor="customer" className="font-medium">Customer Name <span className="text-destructive">*</span></Label>
                <Input
                  id="customer"
                  {...form.register('customer')}
                  placeholder="e.g., Stark Industries"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.customer}
                  suppressHydrationWarning
                />
                {form.formState.errors.customer && (
                  <p className="text-sm text-destructive">{form.formState.errors.customer.message}</p>
                )}
              </div>

              {/* Order Date */}
              <div className="space-y-2">
                 <Label htmlFor="orderDate" className="font-medium">Order Date <span className="text-destructive">*</span></Label>
                  <Controller
                    control={form.control}
                    name="orderDate"
                    render={({ field }) => (
                      <Popover>
                          <PopoverTrigger asChild>
                              <Button
                                  variant={"outline"}
                                  className={cn(
                                  "w-full justify-start text-left font-normal border-input bg-input hover:bg-accent",
                                  !field.value && "text-muted-foreground"
                                  )}
                                  suppressHydrationWarning
                              >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                              <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                              />
                          </PopoverContent>
                       </Popover>
                    )}
                  />
                   {form.formState.errors.orderDate && (
                      <p className="text-sm text-destructive">{form.formState.errors.orderDate.message}</p>
                   )}
              </div>

               {/* Total */}
              <div className="space-y-2">
                 {/* Updated currency label */}
                <Label htmlFor="total" className="font-medium">Total Amount (₹)</Label>
                <Input
                  id="total"
                  type="number"
                  step="0.01"
                  {...form.register('total')}
                  placeholder="e.g., 250000.00" // Example in INR
                  className="border-input focus:ring-primary focus:border-primary"
                   aria-invalid={!!form.formState.errors.total}
                   suppressHydrationWarning
                />
                {form.formState.errors.total && (
                  <p className="text-sm text-destructive">{form.formState.errors.total.message}</p>
                )}
              </div>

            </div>

            {/* Right Column */}
            <div className="space-y-4">
               {/* Delivery Date */}
              <div className="space-y-2">
                 <Label htmlFor="deliveryDate" className="font-medium">Delivery Date <span className="text-destructive">*</span></Label>
                  <Controller
                    control={form.control}
                    name="deliveryDate"
                    render={({ field }) => (
                       <Popover>
                          <PopoverTrigger asChild>
                              <Button
                                  variant={"outline"}
                                  className={cn(
                                  "w-full justify-start text-left font-normal border-input bg-input hover:bg-accent",
                                  !field.value && "text-muted-foreground"
                                  )}
                                  suppressHydrationWarning
                              >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                              <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                              />
                          </PopoverContent>
                       </Popover>
                    )}
                  />
                   {form.formState.errors.deliveryDate && (
                      <p className="text-sm text-destructive">{form.formState.errors.deliveryDate.message}</p>
                   )}
              </div>

               {/* Status */}
              <div className="space-y-2">
                <Label htmlFor="status" className="font-medium">Status <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                       <Select onValueChange={field.onChange} value={field.value}>
                          <SelectTrigger id="status" className="border-input focus:ring-primary focus:border-primary" suppressHydrationWarning>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent className="bg-popover border-border">
                            {salesOrderStatusOptions.map((statusOption) => (
                              <SelectItem key={statusOption} value={statusOption}>{statusOption}</SelectItem>
                            ))}
                          </SelectContent>
                       </Select>
                    )}
                  />
                {form.formState.errors.status && (
                  <p className="text-sm text-destructive">{form.formState.errors.status.message}</p>
                )}
              </div>

                 {/* Placeholder for Items Section */}
                 <div className="space-y-2 pt-4">
                    <Label className="font-medium">Items</Label>
                    <Card className="bg-muted/50 border-dashed border-border">
                        <CardContent className="p-6 text-center text-muted-foreground flex flex-col items-center justify-center min-h-[100px]">
                             <p className="text-sm">Sales order items will be added here.</p>
                             <Button variant="secondary" size="sm" className="mt-3" disabled suppressHydrationWarning>+ Add Item</Button>
                        </CardContent>
                    </Card>
                 </div>

            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending} suppressHydrationWarning>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground" suppressHydrationWarning>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Creating...' : 'Create Sales Order'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
