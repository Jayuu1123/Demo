
'use client'; // Add "use client" directive

import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { getSalesOrders } from '@/actions/sales/salesOrders';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { SalesOrdersTable } from './_components/sales-orders-table';
import { SalesOrdersTableSkeleton } from './_components/sales-orders-table-skeleton';

// This is now a Client Component because it uses useRouter
export default function SalesOrdersPage() {
  const router = useRouter(); // Hook for navigation

  const handleAddSalesOrderClick = () => {
    router.push('/sales/sales-orders/new'); // Navigate to the new sales order page
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Sales Orders</h1>
        <Button onClick={handleAddSalesOrderClick}>
           <PlusCircle className="mr-2 h-4 w-4" />
          Add Sales Order
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<SalesOrdersTableSkeleton />}>
             <SalesOrdersData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Server component logic moved to a separate component
// This part still runs on the server during initial load
async function SalesOrdersData() {
  const salesOrders = await getSalesOrders();

   if (!salesOrders) {
      return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch sales orders.</AlertDescription>
         </Alert>
       );
   }

  return <SalesOrdersTable salesOrders={salesOrders} />;
}
