
'use client'; // Add "use client" directive

import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { getInvoices } from '@/actions/sales/invoices';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { InvoicesTable } from './_components/invoices-table';
import { InvoicesTableSkeleton } from './_components/invoices-table-skeleton';

// This is now a Client Component because it uses useRouter
export default function InvoicesPage() {
  const router = useRouter(); // Hook for navigation

  const handleAddInvoiceClick = () => {
    router.push('/sales/invoices/new'); // Navigate to the new invoice page
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Sales Invoices</h1>
         <Button onClick={handleAddInvoiceClick}>
           <PlusCircle className="mr-2 h-4 w-4" />
          Add Invoice
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<InvoicesTableSkeleton />}>
             <InvoicesData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Server component logic moved to a separate component
// This part still runs on the server during initial load
async function InvoicesData() {
  const invoices = await getInvoices();

   if (!invoices) {
      return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch invoices.</AlertDescription>
         </Alert>
       );
   }

  return <InvoicesTable invoices={invoices} />;
}
