
'use client';

import { useState, useTransition, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, CircleDollarSign, Calendar, User, Percent, Trash2, Edit, Loader2, Ban, HandCoins } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, parseISO, isValid } from 'date-fns';
import { getInvoices, deleteInvoice, cancelInvoice, recordInvoicePayment, type Invoice } from '@/actions/sales/invoices';
import { type InvoiceStatus } from '@/types/sales'; // Import type from types file
import { useToast } from "@/hooks/use-toast";

interface InvoicesTableProps {
  invoices: Invoice[];
}

export function InvoicesTable({ invoices: initialInvoices }: InvoicesTableProps) {
  const [invoices, setInvoices] = useState<Invoice[]>(initialInvoices);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

   // Function to refetch invoices, needed after updates like cancel/payment
    const fetchInvoices = async () => {
        // No setLoading needed here as it's a background refetch
        try {
            const fetchedInvoices = await getInvoices(); // Call the server action
             if (fetchedInvoices) {
                setInvoices(fetchedInvoices);
             } else {
                 // Handle case where refetch fails, maybe show a toast?
                  toast({ variant: "destructive", title: "Error", description: "Could not refresh invoice list." });
             }
        } catch (err) {
            let errorMessage = "An error occurred while refreshing invoices.";
             if (err instanceof Error) {
                errorMessage = err.message.includes('401')
                  ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                  : err.message;
            }
            console.error("Failed to refetch invoices:", err);
            toast({ variant: "destructive", title: "Error", description: errorMessage });
        }
    };

  const formatCurrency = (value: number | null | undefined) => {
      if (value == null) return '-';
      // Changed currency to INR
      return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
  }

  const formatDate = (dateString: string | null | undefined): string => {
       if (!dateString) return '-';
       try {
           const date = parseISO(dateString);
           if (isValid(date)) return format(date, 'PP');
       } catch(e) { console.error("Date Format Error:", e); }
       return 'Invalid Date';
  }

 const getStatusVariant = (status: InvoiceStatus): "default" | "secondary" | "destructive" | "outline" => {
      switch (status?.toLowerCase()) {
          case 'paid': return 'default';
          case 'partly paid': return 'secondary';
          case 'unpaid': return 'outline';
          case 'overdue': return 'destructive';
          case 'cancelled': return 'destructive';
          case 'draft': return 'outline';
          default: return 'outline';
      }
  }

   const getPaidPercentage = (grandTotal: number, outstandingAmount: number) => {
      if (grandTotal <= 0) return 0;
      const paidAmount = grandTotal - outstandingAmount;
      return Math.max(0, Math.min(100, Math.round((paidAmount / grandTotal) * 100)));
   }

  const handleDelete = (id: string) => {
       if (!id || isPending) return;
       if (!confirm('Are you sure you want to delete this invoice? This action may not be reversible.')) {
           return;
       }
       startTransition(async () => {
           try {
               const result = await deleteInvoice(id);
               if (result.success) {
                   setInvoices(prevInvs => prevInvs.filter(inv => inv.id !== id));
                   toast({ title: "Success", description: result.message });
               } else {
                   toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete invoice." });
               }
           } catch (err) {
               let errorMessage = "An unexpected error occurred.";
                 if (err instanceof Error) {
                    errorMessage = err.message.includes('401')
                      ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                      : err.message;
                 }
               toast({ variant: "destructive", title: "Error", description: errorMessage });
               console.error("Delete Invoice error:", err);
           }
       });
   };

    const handleCancel = (id: string) => {
        if (!id || isPending) return;
        if (!confirm('Are you sure you want to cancel this invoice? Outstanding amount will be set to zero.')) {
            return;
        }
        startTransition(async () => {
            try {
                const result = await cancelInvoice(id);
                if (result.success) {
                    await fetchInvoices(); // Refetch needed
                    toast({ title: "Success", description: result.message });
                } else {
                    toast({ variant: "destructive", title: "Error", description: result.message || "Failed to cancel invoice." });
                }
            } catch (err) {
                let errorMessage = "An unexpected error occurred while cancelling.";
                 if (err instanceof Error) {
                    errorMessage = err.message.includes('401')
                      ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                      : err.message;
                 }
                toast({ variant: "destructive", title: "Error", description: errorMessage });
                console.error("Cancel Invoice error:", err);
            }
        });
    };

   const handleEditInvoiceClick = (inv: Invoice) => {
     if (isPending) return;
     console.log("Edit Invoice clicked:", inv);
     // TODO: Open edit dialog
      toast({ title: "Info", description: "Edit functionality not implemented."});
   };

    const handleRecordPaymentClick = (inv: Invoice) => {
        if (isPending) return;
        console.log("Record Payment clicked:", inv);
         const paymentAmount = prompt(`Enter payment amount for Invoice ${inv.id} (Outstanding: ${formatCurrency(inv.outstandingAmount)}):`, (inv.outstandingAmount / 2).toFixed(2));
         if (paymentAmount === null || paymentAmount === '' || isNaN(parseFloat(paymentAmount)) || parseFloat(paymentAmount) <= 0) {
             toast({ variant: "destructive", title: "Error", description: "Invalid or non-positive payment amount entered." });
             return;
         }

          const formData = new FormData();
          formData.append('invoiceId', inv.id!);
          formData.append('paymentAmount', paymentAmount);

           startTransition(async () => {
                try {
                    const result = await recordInvoicePayment(formData);
                    if (result.success) {
                        await fetchInvoices(); // Refetch needed
                        toast({ title: "Success", description: result.message });
                    } else {
                        toast({ variant: "destructive", title: "Error", description: result.message || "Failed to record payment." });
                        console.error("Record Payment failed:", result.errors || result.error);
                    }
                } catch(err) {
                     let errorMessage = "An unexpected error occurred.";
                      if (err instanceof Error) {
                        errorMessage = err.message.includes('401')
                          ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                          : err.message;
                     }
                    toast({ variant: "destructive", title: "Error", description: errorMessage });
                    console.error("Record payment error:", err);
                }
           });
    };

  return (
    <Table>
        <TableHeader>
            <TableRow>
                <TableHead className="pl-4">Invoice ID</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Posting Date</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Grand Total</TableHead>
                <TableHead>Outstanding</TableHead>
                <TableHead>Paid %</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {invoices.length === 0 ? (
            <TableRow>
                <TableCell colSpan={9} className="h-24 text-center text-muted-foreground">
                No invoices found.
                </TableCell>
            </TableRow>
            ) : (
            invoices.map((inv) => (
                <TableRow key={inv.id}>
                    <TableCell className="font-medium pl-4">{inv.id}</TableCell>
                    <TableCell>
                        <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{inv.customer}</span>
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {formatDate(inv.postingDate)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {formatDate(inv.dueDate)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <CircleDollarSign className="h-3 w-3 text-muted-foreground" />
                        {formatCurrency(inv.grandTotal)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <CircleDollarSign className="h-3 w-3 text-muted-foreground" />
                        {formatCurrency(inv.outstandingAmount)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Percent className="h-3 w-3 text-muted-foreground" />
                        {getPaidPercentage(inv.grandTotal, inv.outstandingAmount)}%
                        </div>
                    </TableCell>
                    <TableCell>
                        <Badge variant={getStatusVariant(inv.status)} className='text-xs'>{inv.status}</Badge>
                    </TableCell>
                    <TableCell className="pr-4">
                        <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleEditInvoiceClick(inv)} disabled={isPending || inv.status === 'Paid' || inv.status === 'Cancelled'}>
                                <Edit className="mr-2 h-4 w-4"/> Edit
                            </DropdownMenuItem>
                            {(inv.status === 'Unpaid' || inv.status === 'Partly Paid' || inv.status === 'Overdue') && (
                                <DropdownMenuItem onClick={() => handleRecordPaymentClick(inv)} disabled={isPending}>
                                <HandCoins className="mr-2 h-4 w-4"/> Record Payment
                                </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            {inv.status !== 'Paid' && inv.status !== 'Cancelled' && (
                                <DropdownMenuItem className="text-orange-600 focus:text-orange-600 focus:bg-orange-100" onClick={() => handleCancel(inv.id!)} disabled={isPending}>
                                <Ban className="mr-2 h-4 w-4" /> Cancel Invoice
                                </DropdownMenuItem>
                            )}
                            {(inv.status === 'Draft') && (
                                <DropdownMenuItem
                                    className="text-destructive focus:text-destructive focus:bg-destructive/10"
                                    onClick={() => handleDelete(inv.id!)}
                                    disabled={isPending}
                                >
                                    {isPending ? (
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    ) : (
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    )}
                                Delete
                                </DropdownMenuItem>
                            )}
                        </DropdownMenuContent>
                        </DropdownMenu>
                    </TableCell>
                </TableRow>
            ))
            )}
        </TableBody>
    </Table>
  );
}
