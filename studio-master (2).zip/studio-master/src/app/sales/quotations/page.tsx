
'use client'; // Add "use client" directive

import { Suspense } from 'react';
import { useRouter } from 'next/navigation'; // Import useRouter
import { getQuotations } from '@/actions/sales/quotations';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PlusCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { QuotationsTable } from './_components/quotations-table';
import { QuotationsTableSkeleton } from './_components/quotations-table-skeleton';

// This is now a Client Component because it uses useRouter
export default function QuotationsPage() {
  const router = useRouter(); // Hook for navigation

  const handleAddQuotationClick = () => {
    router.push('/sales/quotations/new'); // Navigate to the new quotation page
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Quotations</h1>
         <Button onClick={handleAddQuotationClick}>
           <PlusCircle className="mr-2 h-4 w-4" />
          Add Quotation
        </Button>
      </div>

      <Card className="shadow-sm">
        <CardContent className="p-0">
           <Suspense fallback={<QuotationsTableSkeleton />}>
             <QuotationsData />
           </Suspense>
        </CardContent>
      </Card>
    </>
  );
}

// Server component logic moved to a separate component
// This part still runs on the server during initial load
async function QuotationsData() {
  const quotations = await getQuotations();

   if (!quotations) {
      return (
         <Alert variant="destructive" className="m-4">
           <AlertCircle className="h-4 w-4" />
           <AlertTitle>Error</AlertTitle>
           <AlertDescription>Failed to fetch quotations.</AlertDescription>
         </Alert>
       );
   }

  return <QuotationsTable quotations={quotations} />;
}
