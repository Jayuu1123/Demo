
'use client';

import { useState, useTransition, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, CircleDollarSign, Calendar, User, Trash2, Edit, Loader2, FileCheck } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, parseISO, isValid } from 'date-fns';
import { getQuotations, deleteQuotation, convertQuotationToSalesOrder, type Quotation } from '@/actions/sales/quotations';
import { type QuotationStatus } from '@/types/sales'; // Import type from types file
import { useToast } from "@/hooks/use-toast";

interface QuotationsTableProps {
  quotations: Quotation[];
}

export function QuotationsTable({ quotations: initialQuotations }: QuotationsTableProps) {
  const [quotations, setQuotations] = useState<Quotation[]>(initialQuotations);
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  // Function to refetch quotations, needed after conversion
  const fetchQuotations = async () => {
    // No setLoading for background refetch
    try {
        const fetchedQuotations = await getQuotations();
        if (fetchedQuotations) {
             setQuotations(fetchedQuotations);
        } else {
             toast({ variant: "destructive", title: "Error", description: "Could not refresh quotation list." });
        }
    } catch (err) {
        let errorMessage = "An error occurred while refreshing quotations.";
         if (err instanceof Error) {
            errorMessage = err.message.includes('401')
              ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
              : err.message;
        }
        console.error("Failed to refetch quotations:", err);
        toast({ variant: "destructive", title: "Error", description: errorMessage });
    }
  };

  const formatCurrency = (value: number | null | undefined) => {
      if (value == null) return '-';
      // Changed currency to INR
      return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
  }

  const formatDate = (dateString: string | null | undefined): string => {
      if (!dateString) return '-';
      try {
          const date = parseISO(dateString);
          if (isValid(date)) {
              return format(date, 'PP');
          }
      } catch (e) { console.error("Error formatting date:", dateString, e); }
      return 'Invalid Date';
  }

  const getStatusVariant = (status: QuotationStatus): "default" | "secondary" | "destructive" | "outline" => {
      switch (status?.toLowerCase()) {
          case 'draft': return 'outline';
          case 'sent': return 'secondary';
          case 'accepted': return 'default';
          case 'rejected':
          case 'expired':
          case 'cancelled': return 'destructive';
          default: return 'outline';
      }
  }

  const handleDelete = (id: string) => {
      if (!id || isPending) return;
      if (!confirm('Are you sure you want to delete this quotation?')) {
          return;
      }
    startTransition(async () => {
      try {
           const result = await deleteQuotation(id);
           if (result.success) {
               setQuotations(prevQtns => prevQtns.filter(qtn => qtn.id !== id));
               toast({ title: "Success", description: result.message });
           } else {
               toast({ variant: "destructive", title: "Error", description: result.message || "Failed to delete quotation." });
           }
      } catch (err) {
             let errorMessage = "An unexpected error occurred.";
             if (err instanceof Error) {
                errorMessage = err.message.includes('401')
                  ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                  : err.message;
             }
            toast({ variant: "destructive", title: "Error", description: errorMessage });
            console.error("Delete quotation error:", err);
      }
    });
  };

  const handleConvertToSO = (id: string) => {
    if (!id || isPending) return;
    startTransition(async () => {
        try {
            const result = await convertQuotationToSalesOrder(id);
            if (result.success) {
                await fetchQuotations(); // Refetch needed
                toast({ title: "Success", description: result.message });
                // TODO: Maybe navigate to the new SO or revalidate SO path
            } else {
                toast({ variant: "destructive", title: "Error", description: result.message || "Failed to convert quotation." });
            }
        } catch (err) {
             let errorMessage = "An unexpected error occurred during conversion.";
             if (err instanceof Error) {
                errorMessage = err.message.includes('401')
                  ? "Database authentication failed (401). Check your TURSO_AUTH_TOKEN."
                  : err.message;
             }
            toast({ variant: "destructive", title: "Error", description: errorMessage });
            console.error("Convert quotation error:", err);
        }
    });
  };

  const handleEditQuotationClick = (qtn: Quotation) => {
     if (isPending) return;
     console.log("Edit quotation clicked:", qtn);
     // TODO: Open edit dialog
     toast({ title: "Info", description: "Edit functionality not implemented."});
  };

  return (
    <Table>
        <TableHeader>
            <TableRow>
                <TableHead className="pl-4">Quotation ID</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Expiry Date</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="pr-4">Actions</TableHead>
            </TableRow>
        </TableHeader>
        <TableBody>
            {quotations.length === 0 ? (
            <TableRow>
                <TableCell colSpan={7} className="h-24 text-center text-muted-foreground">
                No quotations found.
                </TableCell>
            </TableRow>
            ) : (
            quotations.map((qtn) => (
                <TableRow key={qtn.id}>
                    <TableCell className="font-medium pl-4">{qtn.id}</TableCell>
                    <TableCell>
                        <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{qtn.customer}</span>
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {formatDate(qtn.date)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        {formatDate(qtn.expiryDate)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <div className="flex items-center gap-1">
                        <CircleDollarSign className="h-3 w-3 text-muted-foreground" />
                        {formatCurrency(qtn.total)}
                        </div>
                    </TableCell>
                    <TableCell>
                        <Badge variant={getStatusVariant(qtn.status)} className='text-xs'>{qtn.status}</Badge>
                    </TableCell>
                    <TableCell className="pr-4">
                        <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0" disabled={isPending}>
                            <span className="sr-only">Open menu</span>
                            <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleEditQuotationClick(qtn)} disabled={isPending}>
                                <Edit className="mr-2 h-4 w-4"/> Edit
                            </DropdownMenuItem>
                            {qtn.status === 'Accepted' && (
                            <DropdownMenuItem onClick={() => handleConvertToSO(qtn.id!)} disabled={isPending}>
                                <FileCheck className="mr-2 h-4 w-4"/> Create Sales Order
                            </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                                className="text-destructive focus:text-destructive focus:bg-destructive/10"
                                onClick={() => handleDelete(qtn.id!)}
                                disabled={isPending || qtn.status === 'Accepted'}
                            >
                                {isPending ? (
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                ) : (
                                <Trash2 className="mr-2 h-4 w-4" />
                                )}
                            Delete
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                        </DropdownMenu>
                    </TableCell>
                </TableRow>
            ))
            )}
        </TableBody>
    </Table>
  );
}
