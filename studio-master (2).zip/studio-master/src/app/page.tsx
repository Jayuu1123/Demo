
'use client';
import { testDatabaseConnection, type DbConnectionResult } from "../lib/db"; // Import type
import type React from 'react'; // Ensure React is imported for type usage
import { useState, useEffect } from 'react'; // Import useState and useEffect

import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarFooter,
  SidebarTrigger,
  SidebarMenuAction,
} from '@/components/ui/sidebar';
import { Header } from '@/components/layout/header';
import {
  Users,
  DollarSign,
  ShoppingCart,
  Settings,
  LifeBuoy,
  Contact,
  LineChart,
  LayoutDashboard,
  Plus,
  Box, // Icon for Items
  Boxes, // Icon for Item Groups
  Building, // Icon for Parties
  Target, // Icon for Leads
  Handshake, // Icon for Opportunities
  Filter, // Replaced Pipeline
  FileText, // For Quotations
  ClipboardList, // For Sales Orders
  Receipt, // For Invoices
  Truck, // Purchase Order icon
  BookUser, // Vendors
  FileStack, // Bills
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';


export default function HomePage() {
   // State to track the active path for client-side rendering
  const [activePath, setActivePath] = useState('');
  const [dbStatus, setDbStatus] = useState<DbConnectionResult | null>(null); // State for DB status
  const [isLoadingDbStatus, setIsLoadingDbStatus] = useState(true);

  useEffect(() => {
    // Set the active path only on the client side after mount
    setActivePath(window.location.pathname);

    // Test database connection on mount
    const checkDb = async () => {
        setIsLoadingDbStatus(true);
        try {
             const result = await testDatabaseConnection();
             setDbStatus(result);
        } catch (error) {
            // Catch errors during the fetch itself (e.g., network error)
            console.error("Error calling testDatabaseConnection:", error);
             setDbStatus({ success: false, message: `Failed to check DB connection: ${error instanceof Error ? error.message : String(error)}` });
        } finally {
            setIsLoadingDbStatus(false);
        }
    };
    checkDb();
  }, []); // Empty dependency array ensures this runs only once on mount


  // Demo data remains the same
  const demoSales = [
    { id: 'SO-001', customer: 'Acme Corp', total: '₹1,25,000.00', status: 'Shipped' }, // Updated currency
    { id: 'SO-002', customer: 'Globex Inc.', total: '₹87,550.50', status: 'Processing' }, // Updated currency
    { id: 'SO-003', customer: 'Stark Industries', total: '₹2,50,000.00', status: 'Delivered' }, // Updated currency
  ];

  const demoLeads = [
    { name: 'John Doe', company: 'Tech Solutions', status: 'New', id: 'lead-001' },
    { name: 'Jane Smith', company: 'Innovate LLC', status: 'Contacted', id: 'lead-002' },
    { name: 'Peter Jones', company: 'Web Services', status: 'Qualified', id: 'lead-003' },
  ];

  const demoTasks = [
    { title: 'Follow up with Acme Corp', due: 'Tomorrow' },
    { title: 'Prepare Q3 Sales Report', due: 'Friday' },
    { title: 'Schedule team meeting', due: 'Next Monday' },
  ];

  const demoAttendance = [
    { name: 'Alice Brown', status: 'Present' },
    { name: 'Bob Green', status: 'Present' },
    { name: 'Charlie White', status: 'Absent' },
    { name: 'David Black', status: 'On Leave' },
  ];

  const demoPurchaseOrders = [
      { id: 'PO-101', vendor: 'Supplier Alpha', total: '₹50,000.00', status: 'Ordered' }, // Updated currency
      { id: 'PO-102', vendor: 'Supplier Beta', total: '₹1,50,000.00', status: 'Received' }, // Updated currency
  ];

  const demoInvoices = [
      { id: 'INV-001', customer: 'Acme Corp', total: '₹1,25,000.00', status: 'Paid' }, // Updated currency
      { id: 'INV-002', customer: 'Globex Inc.', total: '₹87,550.50', status: 'Pending' }, // Updated currency
  ];

   return (
    <div className="flex min-h-screen w-full">
      <Sidebar collapsible="icon" variant="sidebar">
        <SidebarHeader className="flex items-center justify-between p-4">
          <div className="flex items-center gap-2">
             <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6 text-primary"
             >
               <path d="M12 2L2 7l10 5 10-5-10-5z" />
               <path d="M2 17l10 5 10-5" />
               <path d="M2 12l10 5 10-5" />
             </svg>
            <span className="font-semibold text-lg group-data-[collapsible=icon]:hidden">EraErp</span>
          </div>
          <SidebarTrigger className="md:hidden" />
        </SidebarHeader>
        <SidebarContent className="flex-1 overflow-auto">
          <SidebarMenu>
             <SidebarMenuItem>
              <SidebarMenuButton href="/" isActive={activePath === '/'} suppressHydrationWarning>
                <LayoutDashboard />
                <span>Dashboard</span>
              </SidebarMenuButton>
            </SidebarMenuItem>

            {/* CRM Module */}
            <SidebarMenuItem>
              <SidebarMenuButton href="/crm" isActive={activePath.startsWith('/crm')} suppressHydrationWarning>
                <Contact />
                <span>CRM</span>
              </SidebarMenuButton>
               <SidebarMenuAction href="/crm/new" aria-label="Add CRM Item" title="Add CRM Item" showOnHover suppressHydrationWarning>
                 <Plus />
               </SidebarMenuAction>
              <SidebarMenuSub>
                 <SidebarMenuSubItem>
                   <SidebarMenuSubButton href="/crm/items" isActive={activePath === '/crm/items'} suppressHydrationWarning>
                      <Box className="h-3.5 w-3.5 mr-1.5" /> Items
                   </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                   <SidebarMenuSubButton href="/crm/item-groups" isActive={activePath === '/crm/item-groups'} suppressHydrationWarning>
                      <Boxes className="h-3.5 w-3.5 mr-1.5" /> Item Groups
                   </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                   <SidebarMenuSubButton href="/crm/parties" isActive={activePath === '/crm/parties'} suppressHydrationWarning>
                       <Building className="h-3.5 w-3.5 mr-1.5" /> Parties
                   </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/crm/leads" isActive={activePath === '/crm/leads'} suppressHydrationWarning>
                    <Target className="h-3.5 w-3.5 mr-1.5" /> Leads
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/crm/contacts" isActive={activePath === '/crm/contacts'} suppressHydrationWarning>
                    <Contact className="h-3.5 w-3.5 mr-1.5" /> Contacts
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/crm/opportunities" isActive={activePath === '/crm/opportunities'} suppressHydrationWarning>
                    <Handshake className="h-3.5 w-3.5 mr-1.5" /> Opportunities
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/crm/pipeline" isActive={activePath === '/crm/pipeline'} suppressHydrationWarning>
                    <Filter className="h-3.5 w-3.5 mr-1.5" /> Pipeline
                  </SidebarMenuSubButton>
                 </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

             {/* Sales Module */}
            <SidebarMenuItem>
              {/* Updated main Sales link and active check */}
              <SidebarMenuButton href="/sales" isActive={activePath.startsWith('/sales')} suppressHydrationWarning>
                <LineChart />
                <span>Sales</span>
              </SidebarMenuButton>
               <SidebarMenuAction href="/sales/new" aria-label="Add Sales Item" title="Add Sales Item" showOnHover suppressHydrationWarning>
                 <Plus />
               </SidebarMenuAction>
               <SidebarMenuSub>
                {/* Updated Sales sub-menu links and active checks */}
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/sales/quotations" isActive={activePath === '/sales/quotations'} suppressHydrationWarning>
                     <FileText className="h-3.5 w-3.5 mr-1.5" /> Quotations
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/sales/sales-orders" isActive={activePath === '/sales/sales-orders'} suppressHydrationWarning>
                     <ClipboardList className="h-3.5 w-3.5 mr-1.5" /> Sales Orders
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/sales/invoices" isActive={activePath === '/sales/invoices'} suppressHydrationWarning>
                     <Receipt className="h-3.5 w-3.5 mr-1.5" /> Invoices
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

            {/* HR Module */}
            <SidebarMenuItem>
              <SidebarMenuButton href="/hr" isActive={activePath.startsWith('/hr') || activePath === '/suggest-roles'} suppressHydrationWarning>
                <Users />
                <span>Human Resources</span>
              </SidebarMenuButton>
               <SidebarMenuAction href="/hr/new" aria-label="Add HR Item" title="Add HR Item" showOnHover suppressHydrationWarning>
                 <Plus />
               </SidebarMenuAction>
              <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/hr/employees" isActive={activePath === '/hr/employees'} suppressHydrationWarning>Employees</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/hr/roles" isActive={activePath === '/hr/roles'} suppressHydrationWarning>Roles & Permissions</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                   {/* Make Suggest Roles active only if path is exactly /suggest-roles */}
                   <SidebarMenuSubButton href="/suggest-roles" isActive={activePath === '/suggest-roles'} suppressHydrationWarning>Suggest Roles (AI)</SidebarMenuSubButton>
                 </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/hr/attendance" isActive={activePath === '/hr/attendance'} suppressHydrationWarning>Attendance</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/hr/payroll" isActive={activePath === '/hr/payroll'} suppressHydrationWarning>Payroll</SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

            {/* Finance Module */}
            <SidebarMenuItem>
              <SidebarMenuButton href="/finance" isActive={activePath.startsWith('/finance')} suppressHydrationWarning>
                <DollarSign />
                <span>Finance</span>
              </SidebarMenuButton>
               <SidebarMenuAction href="/finance/new" aria-label="Add Finance Item" title="Add Finance Item" showOnHover suppressHydrationWarning>
                 <Plus />
               </SidebarMenuAction>
              <SidebarMenuSub>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/finance/accounts" isActive={activePath === '/finance/accounts'} suppressHydrationWarning>Chart of Accounts</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/finance/invoices" isActive={activePath === '/finance/invoices'} suppressHydrationWarning>Invoices</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/finance/payments" isActive={activePath === '/finance/payments'} suppressHydrationWarning>Payments</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/finance/expenses" isActive={activePath === '/finance/expenses'} suppressHydrationWarning>Expenses</SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/finance/reports" isActive={activePath === '/finance/reports'} suppressHydrationWarning>Reports</SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

             {/* Purchase Module */}
            <SidebarMenuItem>
              <SidebarMenuButton href="/purchase" isActive={activePath.startsWith('/purchase')} suppressHydrationWarning>
                <ShoppingCart />
                <span>Purchase</span>
              </SidebarMenuButton>
               <SidebarMenuAction href="/purchase/new" aria-label="Add Purchase Item" title="Add Purchase Item" showOnHover suppressHydrationWarning>
                 <Plus />
               </SidebarMenuAction>
              <SidebarMenuSub>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/purchase/purchase-orders" isActive={activePath.startsWith('/purchase/purchase-orders')} suppressHydrationWarning>
                      <Truck className="h-3.5 w-3.5 mr-1.5" /> Purchase Orders
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/purchase/vendors" isActive={activePath === '/purchase/vendors'} suppressHydrationWarning>
                       <BookUser className="h-3.5 w-3.5 mr-1.5" /> Vendors
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
                 <SidebarMenuSubItem>
                  <SidebarMenuSubButton href="/purchase/bills" isActive={activePath === '/purchase/bills'} suppressHydrationWarning>
                       <FileStack className="h-3.5 w-3.5 mr-1.5" /> Bills
                  </SidebarMenuSubButton>
                </SidebarMenuSubItem>
              </SidebarMenuSub>
            </SidebarMenuItem>

          </SidebarMenu>
        </SidebarContent>
        <SidebarFooter className="mt-auto">
           <SidebarMenu>
             <SidebarMenuItem>
              <SidebarMenuButton href="/settings" isActive={activePath.startsWith('/settings')} suppressHydrationWarning>
                <Settings />
                <span>Settings</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
            <SidebarMenuItem>
              <SidebarMenuButton href="/support" isActive={activePath === '/support'} suppressHydrationWarning>
                <LifeBuoy />
                <span>Support</span>
              </SidebarMenuButton>
            </SidebarMenuItem>
           </SidebarMenu>
        </SidebarFooter>
      </Sidebar>
      <SidebarInset className="flex flex-col">
        <Header />
        <main className="flex-1 overflow-auto p-6 bg-secondary/30">
           <h1 className="text-3xl font-semibold mb-6">Dashboard</h1>

           {/* Database Status */}
             <div className="mb-6">
                <Card className="shadow-sm">
                     <CardHeader>
                        <CardTitle className="text-base font-medium">Database Connection</CardTitle>
                     </CardHeader>
                     <CardContent>
                          {isLoadingDbStatus ? (
                              <p className="text-sm text-muted-foreground">Checking connection...</p>
                          ) : dbStatus?.success ? (
                              <Badge variant="default">Connected</Badge>
                          ) : (
                              <Badge variant="destructive">Disconnected</Badge>
                          )}
                          {dbStatus && !dbStatus.success && (
                              <p className="text-xs text-destructive mt-2">{dbStatus.message}</p>
                          )}
                     </CardContent>
                </Card>
             </div>

           {/* Dashboard content with demo entries */}
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
               {/* Recent Sales Orders */}
               <Card className="shadow-sm">
                 <CardHeader className='flex flex-row items-center justify-between pb-2'>
                   <CardTitle className="text-base font-medium">Recent Sales Orders</CardTitle>
                   <Link href="/sales/sales-orders" passHref>
                       <Button variant="outline" size="sm" suppressHydrationWarning>View All</Button>
                   </Link>
                 </CardHeader>
                 <CardContent>
                   <ul className="space-y-3">
                     {demoSales.map((sale) => (
                       <li key={sale.id} className="flex justify-between items-center text-sm border-b pb-2 last:border-none">
                         <div>
                           <span className="font-medium">{sale.id}</span>
                           <p className="text-muted-foreground text-xs">{sale.customer}</p>
                         </div>
                         <div className='text-right'>
                            <span className="block">{sale.total}</span>
                            <Badge variant={sale.status === 'Shipped' ? 'default' : sale.status === 'Delivered' ? 'secondary' : 'outline'} className='ml-auto text-xs mt-1'>{sale.status}</Badge>
                         </div>
                       </li>
                     ))}
                   </ul>
                 </CardContent>
              </Card>

              {/* New Leads */}
              <Card className="shadow-sm">
                 <CardHeader className='flex flex-row items-center justify-between pb-2'>
                   <CardTitle className="text-base font-medium">New Leads</CardTitle>
                    <Link href="/crm/leads" passHref>
                       <Button variant="outline" size="sm" suppressHydrationWarning>View All</Button>
                    </Link>
                 </CardHeader>
                 <CardContent>
                   <ul className="space-y-3">
                     {demoLeads.map((lead) => (
                       <li key={lead.id} className="flex justify-between items-center text-sm border-b pb-2 last:border-none">
                         <div>
                           <span className="font-medium">{lead.name}</span>
                           <p className="text-muted-foreground text-xs">{lead.company}</p>
                         </div>
                         <Badge variant={lead.status === 'New' ? 'destructive' : lead.status === 'Contacted' ? 'secondary' : 'default'} className='text-xs'>{lead.status}</Badge>
                       </li>
                     ))}
                   </ul>
                 </CardContent>
              </Card>

              {/* Upcoming Tasks */}
               <Card className="shadow-sm">
                 <CardHeader className='flex flex-row items-center justify-between pb-2'>
                   <CardTitle className="text-base font-medium">Upcoming Tasks</CardTitle>
                    {/* Link to Tasks page if it exists */}
                    <Button variant="outline" size="sm" disabled suppressHydrationWarning>View All</Button>
                 </CardHeader>
                 <CardContent>
                   <ul className="space-y-3">
                     {demoTasks.map((task, index) => (
                       <li key={index} className="flex justify-between items-center text-sm border-b pb-2 last:border-none">
                         <span className="font-medium">{task.title}</span>
                         <span className="text-muted-foreground">{task.due}</span>
                       </li>
                     ))}
                   </ul>
                 </CardContent>
              </Card>

              {/* Attendance Today */}
               <Card className="shadow-sm">
                 <CardHeader className='flex flex-row items-center justify-between pb-2'>
                   <CardTitle className="text-base font-medium">Attendance Today</CardTitle>
                    <Link href="/hr/attendance" passHref>
                       <Button variant="outline" size="sm" suppressHydrationWarning>View All</Button>
                    </Link>
                 </CardHeader>
                 <CardContent>
                   <ul className="space-y-3">
                     {demoAttendance.map((att) => (
                       <li key={att.name} className="flex justify-between items-center text-sm border-b pb-2 last:border-none">
                         <span className="font-medium">{att.name}</span>
                         <Badge variant={att.status === 'Present' ? 'default' : att.status === 'Absent' ? 'destructive' : 'outline'} className='text-xs'>{att.status}</Badge>
                       </li>
                     ))}
                   </ul>
                 </CardContent>
              </Card>

               {/* Recent Purchase Orders */}
                <Card className="shadow-sm">
                 <CardHeader className='flex flex-row items-center justify-between pb-2'>
                   <CardTitle className="text-base font-medium">Recent Purchase Orders</CardTitle>
                    <Link href="/purchase/purchase-orders" passHref>
                       <Button variant="outline" size="sm" suppressHydrationWarning>View All</Button>
                    </Link>
                 </CardHeader>
                 <CardContent>
                   <ul className="space-y-3">
                     {demoPurchaseOrders.map((po) => (
                       <li key={po.id} className="flex justify-between items-center text-sm border-b pb-2 last:border-none">
                         <div>
                           <span className="font-medium">{po.id}</span>
                           <p className="text-muted-foreground text-xs">{po.vendor}</p>
                         </div>
                         <div className='text-right'>
                            <span className="block">{po.total}</span>
                            <Badge variant={po.status === 'Ordered' ? 'outline' : 'default'} className='ml-auto text-xs mt-1'>{po.status}</Badge>
                         </div>
                       </li>
                     ))}
                   </ul>
                 </CardContent>
                </Card>

                 {/* Recent Invoices */}
                <Card className="shadow-sm">
                 <CardHeader className='flex flex-row items-center justify-between pb-2'>
                   <CardTitle className="text-base font-medium">Recent Invoices</CardTitle>
                    <Link href="/sales/invoices" passHref>
                       <Button variant="outline" size="sm" suppressHydrationWarning>View All</Button>
                    </Link>
                 </CardHeader>
                 <CardContent>
                   <ul className="space-y-3">
                     {demoInvoices.map((inv) => (
                       <li key={inv.id} className="flex justify-between items-center text-sm border-b pb-2 last:border-none">
                         <div>
                           <span className="font-medium">{inv.id}</span>
                           <p className="text-muted-foreground text-xs">{inv.customer}</p>
                         </div>
                         <div className='text-right'>
                            <span className="block">{inv.total}</span>
                            <Badge variant={inv.status === 'Paid' ? 'default' : 'destructive'} className='ml-auto text-xs mt-1'>{inv.status}</Badge>
                         </div>
                       </li>
                     ))}
                   </ul>
                 </CardContent>
                </Card>

           </div>
        </main>
      </SidebarInset>
    </div>
  );
}
