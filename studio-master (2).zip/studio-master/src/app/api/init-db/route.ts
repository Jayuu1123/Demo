
// src/app/api/init-db/route.ts
import { initializeDbSchema } from '@/lib/db';
import { NextResponse } from 'next/server';

export async function GET() {
  try {
    await initializeDbSchema();
    return NextResponse.json({ message: 'Database schema initialized successfully.' });
  } catch (error) {
    console.error('Error initializing database schema:', error);
    // Provide more specific error feedback if possible
    let errorMessage = 'Failed to initialize database schema.';
    if (error instanceof Error) {
        if (error.message.includes('401')) {
             errorMessage = 'Database authentication failed (401). Check your TURSO_AUTH_TOKEN.';
        } else if (error.message.includes('404')) {
             errorMessage = 'Database not found (404). Check your TURSO_DATABASE_URL.';
        } else if (error.message.includes('TURSO_DATABASE_URL') || error.message.includes('TURSO_AUTH_TOKEN')) {
            errorMessage = error.message; // Use the specific message from db.ts check
        } else {
            errorMessage = error.message; // General error message
        }
    } else {
         errorMessage = String(error);
    }

    return NextResponse.json({ message: errorMessage }, { status: 500 });
  }
}
