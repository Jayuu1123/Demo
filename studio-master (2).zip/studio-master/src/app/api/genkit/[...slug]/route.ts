
import '@/ai/dev'; // Make sure dev flows are loaded
import {createApp} from '@genkit-ai/next';

export const {GET, POST} = createApp();
