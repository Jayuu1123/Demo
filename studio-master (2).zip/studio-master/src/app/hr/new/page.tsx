'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import {
  Users, // Employees
  UserCog, // Roles & Permissions
  CalendarCheck, // Attendance
  Wallet, // Payroll
  ArrowLeft,
} from 'lucide-react';

// Define HR entry types
const hrEntryTypes = [
  { name: 'New Employee', href: '/hr/employees/new', icon: Users, description: 'Add a new employee record.' },
  { name: 'New Role', href: '/hr/roles/new', icon: UserCog, description: 'Define a new job role.' },
  { name: 'Log Attendance', href: '/hr/attendance/new', icon: CalendarCheck, description: 'Record employee attendance.' },
  { name: 'Process Payroll', href: '/hr/payroll/new', icon: Wallet, description: 'Start a new payroll run.' },
];

export default function NewHrEntryPage() {
  const router = useRouter();

  return (
    <>
       <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back">
          <ArrowLeft className="h-4 w-4" />
        </Button>
         <h1 className="text-3xl font-semibold">New Human Resources Entry</h1>
       </div>
      <p className="text-muted-foreground mb-8">
        Select the type of HR record you want to create.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {hrEntryTypes.map((entryType) => (
          <Link href={entryType.href} key={entryType.name} passHref>
            <Card className="shadow-sm hover:shadow-lg transition-shadow duration-200 cursor-pointer h-full flex flex-col">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                <entryType.icon className="h-8 w-8 text-primary" />
                <CardTitle className="text-xl font-medium">{entryType.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground">{entryType.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}
