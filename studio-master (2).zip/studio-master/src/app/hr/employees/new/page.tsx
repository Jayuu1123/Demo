'use client';

import { useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { CalendarIcon, Loader2, ArrowLeft } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
// Assume an action `addEmployee` exists in `@/actions/hr/employees`
// import { addEmployee } from '@/actions/hr/employees';

// Define employee status options based on schema
const employeeStatusOptions = ['Active', 'Inactive', 'Terminated'] as const;

// Define the Zod schema matching the database table
const EmployeeFormSchema = z.object({
  first_name: z.string().min(1, "First name is required"),
  last_name: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address").optional().or(z.literal('')),
  phone: z.string().optional(),
  job_title: z.string().optional(),
  department: z.string().optional(),
  hire_date: z.date().optional().nullable(), // Make optional
  status: z.enum(employeeStatusOptions).default('Active'),
});

type EmployeeFormValues = z.infer<typeof EmployeeFormSchema>;

export default function NewEmployeePage() {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const form = useForm<EmployeeFormValues>({
    resolver: zodResolver(EmployeeFormSchema),
    defaultValues: {
      first_name: '',
      last_name: '',
      email: '',
      phone: '',
      job_title: '',
      department: '',
      hire_date: null, // Default to null
      status: 'Active',
    },
  });

  const onSubmit = (values: EmployeeFormValues) => {
      toast({ title: "Info", description: "Employee creation not yet implemented." });
      console.log("Form Submitted (Not Implemented):", values);
    // TODO: Implement form submission logic using server action
    /*
    startTransition(async () => {
      const formData = new FormData();
      formData.append('first_name', values.first_name);
      formData.append('last_name', values.last_name);
      if (values.email) formData.append('email', values.email);
      if (values.phone) formData.append('phone', values.phone);
      if (values.job_title) formData.append('job_title', values.job_title);
      if (values.department) formData.append('department', values.department);
      if (values.hire_date) formData.append('hire_date', format(values.hire_date, 'yyyy-MM-dd'));
      formData.append('status', values.status);

      try {
        // const result = await addEmployee(formData); // Call the server action
        // if (result.success && result.id) {
        //   toast({
        //     title: "Success",
        //     description: "Employee created successfully.",
        //   });
        //   router.push('/hr/employees'); // Redirect back to the list
        // } else {
        //    const errorMessages = result.errors
        //       ? Object.entries(result.errors).map(([field, messages]) => `${field}: ${messages.join(', ')}`).join('; ')
        //       : result.message || "An unknown error occurred.";
        //   toast({
        //     variant: "destructive",
        //     title: "Error creating Employee",
        //     description: errorMessages,
        //   });
        //    if (result.errors && typeof result.errors !== 'string' && !Array.isArray(result.errors)) {
        //         Object.entries(result.errors).forEach(([field, messages]) => {
        //             if (messages && messages.length > 0) {
        //                form.setError(field as keyof EmployeeFormValues, { type: 'server', message: messages[0] });
        //             }
        //         });
        //     }
        //   console.error("Server validation errors:", result.errors || result.error);
        // }
      } catch (error) {
        console.error("Failed to create employee:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: error instanceof Error ? error.message : "An unexpected error occurred.",
        });
      }
    });
    */
  };

  return (
    <>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" onClick={() => router.back()} aria-label="Go back" suppressHydrationWarning>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-semibold">New Employee</h1>
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Card className="max-w-3xl mx-auto shadow-lg border border-border rounded-lg">
          <CardHeader className="border-b border-border p-4 md:p-6">
            <CardTitle className="text-xl md:text-2xl">Employee Information</CardTitle>
            <CardDescription className="text-muted-foreground">Enter details for the new employee.</CardDescription>
          </CardHeader>
          <CardContent className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Left Column */}
            <div className="space-y-4">
              {/* First Name */}
              <div className="space-y-2">
                <Label htmlFor="first_name" className="font-medium">First Name <span className="text-destructive">*</span></Label>
                <Input
                  id="first_name"
                  {...form.register('first_name')}
                  placeholder="e.g., Jane"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.first_name}
                  suppressHydrationWarning
                />
                {form.formState.errors.first_name && (
                  <p className="text-sm text-destructive">{form.formState.errors.first_name.message}</p>
                )}
              </div>

              {/* Last Name */}
              <div className="space-y-2">
                <Label htmlFor="last_name" className="font-medium">Last Name <span className="text-destructive">*</span></Label>
                <Input
                  id="last_name"
                  {...form.register('last_name')}
                  placeholder="e.g., Doe"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.last_name}
                  suppressHydrationWarning
                />
                {form.formState.errors.last_name && (
                  <p className="text-sm text-destructive">{form.formState.errors.last_name.message}</p>
                )}
              </div>

               {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email" className="font-medium">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...form.register('email')}
                  placeholder="e.g., jane.doe@company.com"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.email}
                  suppressHydrationWarning
                />
                {form.formState.errors.email && (
                  <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
                )}
              </div>

              {/* Phone */}
              <div className="space-y-2">
                <Label htmlFor="phone" className="font-medium">Phone</Label>
                <Input
                  id="phone"
                  type="tel"
                  {...form.register('phone')}
                  placeholder="e.g., +1 555-111-2222"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.phone}
                  suppressHydrationWarning
                />
                {form.formState.errors.phone && (
                  <p className="text-sm text-destructive">{form.formState.errors.phone.message}</p>
                )}
              </div>

            </div>

            {/* Right Column */}
            <div className="space-y-4">
               {/* Job Title */}
              <div className="space-y-2">
                <Label htmlFor="job_title" className="font-medium">Job Title</Label>
                <Input
                  id="job_title"
                  {...form.register('job_title')}
                  placeholder="e.g., Software Engineer"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.job_title}
                  suppressHydrationWarning
                />
                {form.formState.errors.job_title && (
                  <p className="text-sm text-destructive">{form.formState.errors.job_title.message}</p>
                )}
              </div>

              {/* Department */}
              <div className="space-y-2">
                <Label htmlFor="department" className="font-medium">Department</Label>
                <Input
                  id="department"
                  {...form.register('department')}
                  placeholder="e.g., Engineering, Sales"
                  className="border-input focus:ring-primary focus:border-primary"
                  aria-invalid={!!form.formState.errors.department}
                  suppressHydrationWarning
                />
                {form.formState.errors.department && (
                  <p className="text-sm text-destructive">{form.formState.errors.department.message}</p>
                )}
              </div>

              {/* Hire Date */}
              <div className="space-y-2">
                 <Label htmlFor="hire_date" className="font-medium">Hire Date</Label>
                 <Controller
                    control={form.control}
                    name="hire_date"
                    render={({ field }) => (
                      <Popover>
                          <PopoverTrigger asChild>
                              <Button
                                  variant={"outline"}
                                  className={cn(
                                  "w-full justify-start text-left font-normal border-input bg-input hover:bg-accent",
                                  !field.value && "text-muted-foreground"
                                  )}
                                  suppressHydrationWarning
                              >
                                  <CalendarIcon className="mr-2 h-4 w-4 text-muted-foreground" />
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                              </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0 bg-card border-border" align="start">
                              <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  // initialFocus // Can be removed if causing issues
                              />
                          </PopoverContent>
                       </Popover>
                    )}
                  />
                   {form.formState.errors.hire_date && (
                      <p className="text-sm text-destructive">{form.formState.errors.hire_date.message}</p>
                   )}
              </div>

              {/* Status */}
              <div className="space-y-2">
                <Label htmlFor="status" className="font-medium">Status <span className="text-destructive">*</span></Label>
                 <Controller
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <Select onValueChange={field.onChange} value={field.value}>
                        <SelectTrigger id="status" className="border-input focus:ring-primary focus:border-primary" suppressHydrationWarning>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover border-border">
                          {employeeStatusOptions.map((statusOption) => (
                            <SelectItem key={statusOption} value={statusOption}>{statusOption}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                {form.formState.errors.status && (
                  <p className="text-sm text-destructive">{form.formState.errors.status.message}</p>
                )}
              </div>
            </div>

          </CardContent>
          <CardFooter className="flex justify-end gap-3 border-t border-border p-4 md:p-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isPending} suppressHydrationWarning>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 text-primary-foreground" suppressHydrationWarning>
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isPending ? 'Creating...' : 'Create Employee'}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </>
  );
}
