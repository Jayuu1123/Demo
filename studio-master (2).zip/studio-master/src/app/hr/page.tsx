'use client';

import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Users, // Employees
  UserCog, // Roles & Permissions
  Bot, // Suggest Roles (AI)
  CalendarCheck, // Attendance
  Wallet, // Payroll
} from 'lucide-react';

// Define HR modules
const hrModules = [
  { name: 'Employees', href: '/hr/employees', icon: Users, description: 'Manage employee information and records.' },
  { name: 'Roles & Permissions', href: '/hr/roles', icon: UserCog, description: 'Define roles and access controls.' },
  { name: 'Suggest Roles (AI)', href: '/suggest-roles', icon: Bot, description: 'Get AI suggestions for new roles.' },
  { name: 'Attendance', href: '/hr/attendance', icon: CalendarCheck, description: 'Track employee attendance.' },
  { name: 'Payroll', href: '/hr/payroll', icon: Wallet, description: 'Manage employee salaries and payroll.' },
];

export default function HrHomePage() {
  return (
    <>
      <h1 className="text-3xl font-semibold mb-6">Human Resources Dashboard</h1>
      <p className="text-muted-foreground mb-8">
        Select a module below to manage your human resources operations.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {hrModules.map((module) => (
          <Link href={module.href} key={module.name} passHref>
            <Card className="shadow-sm hover:shadow-lg transition-shadow duration-200 cursor-pointer h-full flex flex-col">
              <CardHeader className="flex flex-row items-center gap-4 space-y-0 pb-2">
                <module.icon className="h-8 w-8 text-primary" />
                <CardTitle className="text-xl font-medium">{module.name}</CardTitle>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground">{module.description}</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}
