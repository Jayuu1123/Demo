
// src/types/purchase.ts

// --- Purchase Order Types ---
export const purchaseOrderStatusOptions = ['Draft', 'Ordered', 'Partly Received', 'Received', 'Completed', 'Cancelled'] as const;
export type PurchaseOrderStatus = typeof purchaseOrderStatusOptions[number];
