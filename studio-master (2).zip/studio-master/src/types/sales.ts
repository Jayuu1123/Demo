
// src/types/sales.ts

// --- Invoice Types ---
export const invoiceStatusOptions = ['Draft', 'Unpaid', 'Partly Paid', 'Paid', 'Overdue', 'Cancelled'] as const;
export type InvoiceStatus = typeof invoiceStatusOptions[number];

// Zod schema definition remains in the action file (src/actions/sales/invoices.ts)
// But the inferred type can be exported from here if needed elsewhere,
// although typically importing the type from the action file is fine if it doesn't cause issues.
// export type Invoice = z.infer<typeof InvoiceSchema>;


// --- Quotation Types ---
export const quotationStatusOptions = ['Draft', 'Sent', 'Accepted', 'Rejected', 'Expired', 'Cancelled'] as const;
export type QuotationStatus = typeof quotationStatusOptions[number];


// --- Sales Order Types ---
export const salesOrderStatusOptions = ['Draft', 'To Deliver and Bill', 'To Bill', 'Delivered', 'Completed', 'Cancelled'] as const;
export type SalesOrderStatus = typeof salesOrderStatusOptions[number];
