
// src/types/crm.ts

// --- Opportunity Types ---
export const opportunityStages = ['Qualification', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost'] as const;
export type OpportunityStage = typeof opportunityStages[number];

// --- Lead Types ---
// Enum values used directly in schema, no separate const needed unless reused often.

// --- Party Types ---
// Enum values used directly in schema, no separate const needed unless reused often.
