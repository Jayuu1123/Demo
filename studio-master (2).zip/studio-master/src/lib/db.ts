// src/lib/db.ts
import { createClient, type Client, LibsqlError } from '@libsql/client';

let clientInstance: Client | null = null;

// Export the type for the connection result
export type DbConnectionResult = {
    success: boolean;
    message: string;
};


// Optimization: Initialize client once and reuse
function getClient(): Client {
  if (!clientInstance) {
    const url = process.env.TURSO_DATABASE_URL;
    const authToken = process.env.TURSO_AUTH_TOKEN;

    // Print environment variables for debugging
    console.log('--- Database Environment Variables ---');
    console.log('TURSO_DATABASE_URL:', url ? url.substring(0, url.includes('.') ? url.indexOf('.') : url.length) + '...' : 'Not set'); // Sanitize URL for logging
    console.log('TURSO_AUTH_TOKEN:', authToken ? authToken.substring(0, 5) + '...' : 'Not set'); // Sanitize token for logging
    console.log('-------------------------------------');

    // Explicitly check for missing or placeholder URL
    if (!url) {
      console.error('FATAL ERROR: Missing TURSO_DATABASE_URL environment variable.');
       throw new Error('Missing TURSO_DATABASE_URL environment variable');
    }
     // Add a check for common placeholder patterns
    if (url === 'YOUR_TURSO_DB_URL_HERE' || url.includes('<your-db-name>') || url.includes('YOUR_') ) {
       console.error(`FATAL ERROR: Placeholder or invalid TURSO_DATABASE_URL detected: "${url}". Please provide your actual Turso database URL in the .env file.`);
       throw new Error('Placeholder or invalid TURSO_DATABASE_URL detected. Please provide your actual Turso database URL.');
    }

    // Explicitly check for missing or placeholder Auth Token
    if (!authToken) {
        console.error('FATAL ERROR: Missing TURSO_AUTH_TOKEN environment variable.');
        throw new Error('Missing TURSO_AUTH_TOKEN environment variable.');
     }
     if (authToken === 'YOUR_TURSO_AUTH_TOKEN_HERE' || authToken.includes('<') || authToken.includes('YOUR_')) {
         console.error('FATAL ERROR: Placeholder or invalid TURSO_AUTH_TOKEN detected. Please provide a valid Turso authentication token in the .env file.');
         throw new Error('Placeholder or invalid TURSO_AUTH_TOKEN detected. Please provide a valid Turso authentication token.');
     }


    try {
        clientInstance = createClient({
          url: url,
          authToken: authToken,
        });
        console.log('Turso client potentially initialized for URL:', url.substring(0, url.includes('.') ? url.indexOf('.') : url.length), '...'); // Log sanitized URL
    } catch (error) {
         // Catch specific initialization errors like URL_INVALID
         if (error instanceof LibsqlError && error.code === 'URL_INVALID') {
             console.error(`FATAL ERROR: Failed to initialize Turso client. The provided URL '${url.substring(0, url.includes('.') ? url.indexOf('.') : url.length)}...' is invalid.`);
             throw new Error(`Failed to initialize Turso client due to invalid URL: ${error.message}`);
         } else {
            console.error('Failed to initialize Turso client:', error);
             // Re-throw the generic error if it's not a URL format issue
            throw new Error(`Failed to initialize Turso client: ${error instanceof Error ? error.message : String(error)}`);
         }
    }
  }
  return clientInstance;
}

// Function to execute SQL queries
// Optimization: Add basic timing for query execution (optional, for debugging)
export async function runSqlQuery(sql: string, args: any[] = []) {
   let client: Client;
   try {
       client = getClient(); // Get or initialize client
   } catch (initError) {
       // If client initialization failed (e.g., missing env vars), re-throw the specific error
       console.error("Database client initialization failed:", initError);
       // Re-throw the specific initialization error to be caught by the caller
       throw initError;
   }

   const startTime = Date.now();
   try {
    console.debug('Executing SQL:', sql, 'Args:', args); // Debug logging
    const rs = await client.execute({ sql, args });
    const duration = Date.now() - startTime;
    console.debug(`SQL executed in ${duration}ms. Rows affected:`, rs.rowsAffected); // Debug logging
    return rs; // Return the full result set including rows and metadata
   } catch (e) {
    const duration = Date.now() - startTime;
    // Check specifically for LibsqlError and potential 401 Unauthorized / 404 Not Found / Table not found
     if (e instanceof LibsqlError && e.code === 'SERVER_ERROR') {
        if (e.message.includes('401')) {
             console.error(`\n--- Database Authentication Error (HTTP 401) ---\nExecuting SQL took ${duration}ms.\nFailed SQL: ${sql}\nArgs: ${JSON.stringify(args)}\nError Details: ${e.message}\nACTION REQUIRED: Please verify your TURSO_AUTH_TOKEN environment variable is correctly set and valid.\n---`);
             throw new Error('Database authentication failed (401). Check your TURSO_AUTH_TOKEN.');
        } else if (e.message.includes('404')) {
            console.error(`\n--- Database Not Found Error (HTTP 404) ---\nExecuting SQL took ${duration}ms.\nFailed SQL: ${sql}\nArgs: ${JSON.stringify(args)}\nError Details: ${e.message}\nACTION REQUIRED: Please verify your TURSO_DATABASE_URL environment variable is correct and that the database exists.\n---`);
            // Throw a more specific error message for 404
            throw new Error('Database not found (404). Check your TURSO_DATABASE_URL.');
        } else {
            // Log other server errors
             console.error(`\n--- Database Server Error (${e.code}) ---\nExecuting SQL took ${duration}ms.\nFailed SQL: ${sql}\nArgs: ${JSON.stringify(args)}\nError Details: ${e.message}\n---`);
             throw new Error(`Database server error occurred: ${e.message}`);
        }
     } else if (e instanceof LibsqlError && e.code === 'SQLITE_UNKNOWN' && e.message.includes('no such table')) {
         // Specific handling for "no such table"
         console.error(`\n--- Database Schema Error (SQLITE_UNKNOWN) ---\nExecuting SQL took ${duration}ms.\nFailed SQL: ${sql}\nArgs: ${JSON.stringify(args)}\nError Details: ${e.message}\nACTION REQUIRED: The required table does not exist. Run the schema initialization (e.g., visit /api/init-db).\n---`);
         throw new Error(`Database schema error: ${e.message}. Ensure the database schema is initialized.`);
     } else if (e instanceof LibsqlError) {
       // Log other LibsqlErrors with more detail
        console.error(`\n--- Database Error (${e.code || 'Unknown LibsqlError'}) ---\nExecuting SQL took ${duration}ms.\nFailed SQL: ${sql}\nArgs: ${JSON.stringify(args)}\nError Details: ${e.message}\n---`);
        throw new Error(`Database error occurred: ${e.message}`); // Throw a generic DB error
     } else {
        // Log other generic errors
        console.error(`\n--- Generic Error During SQL Execution ---\nExecuting SQL took ${duration}ms.\nFailed SQL: ${sql}\nArgs: ${JSON.stringify(args)}\nError: ${e instanceof Error ? e.message : String(e)}\n---`);
        throw new Error(`An unexpected error occurred during database operation: ${e instanceof Error ? e.message : String(e)}`); // Throw generic error
     }
   }
}

// Function to initialize database schema (run once or as needed)
// IMPORTANT: Ensure this runs ONLY when necessary (e.g., first deployment, schema change)
// Using a migration tool (e.g., Drizzle Kit, Prisma Migrate) is highly recommended for production.
export async function initializeDbSchema() {
  console.log('Attempting to initialize database schema...');
  let client: Client;
   try {
       client = getClient(); // Ensure client is initialized before proceeding
       console.log('Database client obtained for schema initialization.');
   } catch (initError) {
       console.error("Cannot initialize schema: Database client initialization failed.", initError);
       // If we can't get the client, we can't initialize the schema.
       throw new Error(`Schema initialization failed due to DB client error: ${initError instanceof Error ? initError.message : String(initError)}`);
   }

  try {
    console.log("Executing schema batch DDL...");
    await client.batch([
        // --- CRM Tables ---
        `CREATE TABLE IF NOT EXISTS items (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            itemGroup TEXT, -- Corresponds to ItemGroupSchema name
            description TEXT,
            stockUom TEXT,
            valuationRate REAL, -- Matches ItemSchema valuationRate (number)
            imageHint TEXT
        );`,
        `CREATE INDEX IF NOT EXISTS idx_items_name ON items(name);`,
        `CREATE INDEX IF NOT EXISTS idx_items_itemGroup ON items(itemGroup);`,

        `CREATE TABLE IF NOT EXISTS item_groups (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            parentGroup TEXT,
            isGroup INTEGER DEFAULT 1, -- Matches ItemGroupSchema isGroup (boolean)
            description TEXT
        );`,
         `CREATE INDEX IF NOT EXISTS idx_item_groups_name ON item_groups(name);`,

        `CREATE TABLE IF NOT EXISTS parties (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            type TEXT NOT NULL CHECK(type IN ('Customer', 'Supplier')), -- Matches PartySchema type enum
            territory TEXT,
            status TEXT NOT NULL CHECK(status IN ('Active', 'On Hold', 'Disabled')), -- Matches PartySchema status enum
            email TEXT -- Matches PartySchema email
        );`,
        `CREATE INDEX IF NOT EXISTS idx_parties_name ON parties(name);`,
        `CREATE INDEX IF NOT EXISTS idx_parties_type ON parties(type);`,
        `CREATE INDEX IF NOT EXISTS idx_parties_status ON parties(status);`,

       `CREATE TABLE IF NOT EXISTS leads (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            company TEXT,
            email TEXT,
            phone TEXT,
            status TEXT NOT NULL CHECK(status IN ('New', 'Contacted', 'Qualified', 'Lost', 'Converted')) -- Matches LeadSchema status enum
        );`,
        `CREATE INDEX IF NOT EXISTS idx_leads_name ON leads(name);`,
        `CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);`,

        `CREATE TABLE IF NOT EXISTS contacts (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            company TEXT,
            title TEXT,
            email TEXT,
            phone TEXT -- All match ContactSchema
        );`,
         `CREATE INDEX IF NOT EXISTS idx_contacts_name ON contacts(name);`,
         `CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);`, // Added index

        `CREATE TABLE IF NOT EXISTS opportunities (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            account TEXT,
            stage TEXT NOT NULL CHECK(stage IN ('Qualification', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost')), -- Matches OpportunitySchema stage enum
            amount REAL, -- Matches OpportunitySchema amount (number)
            closeDate TEXT NOT NULL -- Matches OpportunitySchema closeDate (string YYYY-MM-DD)
        );`,
        `CREATE INDEX IF NOT EXISTS idx_opportunities_closeDate ON opportunities(closeDate);`,
        `CREATE INDEX IF NOT EXISTS idx_opportunities_stage ON opportunities(stage);`,
        `CREATE INDEX IF NOT EXISTS idx_opportunities_name ON opportunities(name);`,

        // --- Sales Tables ---
        `CREATE TABLE IF NOT EXISTS quotations (
            id TEXT PRIMARY KEY,
            customer TEXT NOT NULL,
            date TEXT NOT NULL, -- Matches QuotationSchema date (string YYYY-MM-DD)
            expiryDate TEXT NOT NULL, -- Matches QuotationSchema expiryDate (string YYYY-MM-DD)
            total REAL, -- Matches QuotationSchema total (number)
            status TEXT NOT NULL CHECK(status IN ('Draft', 'Sent', 'Accepted', 'Rejected', 'Expired', 'Cancelled')) -- Matches QuotationSchema status enum
        );`,
         `CREATE INDEX IF NOT EXISTS idx_quotations_date ON quotations(date);`,
         `CREATE INDEX IF NOT EXISTS idx_quotations_status ON quotations(status);`,
         `CREATE INDEX IF NOT EXISTS idx_quotations_customer ON quotations(customer);`, // Added index

        `CREATE TABLE IF NOT EXISTS sales_orders (
            id TEXT PRIMARY KEY,
            customer TEXT NOT NULL,
            orderDate TEXT NOT NULL, -- Matches SalesOrderSchema orderDate (string YYYY-MM-DD)
            deliveryDate TEXT NOT NULL, -- Matches SalesOrderSchema deliveryDate (string YYYY-MM-DD)
            total REAL, -- Matches SalesOrderSchema total (number)
            status TEXT NOT NULL CHECK(status IN ('Draft', 'To Deliver and Bill', 'To Bill', 'Delivered', 'Completed', 'Cancelled')) -- Matches SalesOrderSchema status enum
        );`,
        `CREATE INDEX IF NOT EXISTS idx_sales_orders_orderDate ON sales_orders(orderDate);`,
        `CREATE INDEX IF NOT EXISTS idx_sales_orders_status ON sales_orders(status);`,
         `CREATE INDEX IF NOT EXISTS idx_sales_orders_customer ON sales_orders(customer);`, // Added index

        `CREATE TABLE IF NOT EXISTS invoices (
            id TEXT PRIMARY KEY,
            customer TEXT NOT NULL,
            postingDate TEXT NOT NULL, -- Matches InvoiceSchema postingDate (string YYYY-MM-DD)
            dueDate TEXT NOT NULL, -- Matches InvoiceSchema dueDate (string YYYY-MM-DD)
            grandTotal REAL NOT NULL, -- Matches InvoiceSchema grandTotal (number)
            outstandingAmount REAL NOT NULL, -- Matches InvoiceSchema outstandingAmount (number)
            status TEXT NOT NULL CHECK(status IN ('Draft', 'Unpaid', 'Partly Paid', 'Paid', 'Overdue', 'Cancelled')) -- Matches InvoiceSchema status enum
        );`,
        `CREATE INDEX IF NOT EXISTS idx_invoices_postingDate ON invoices(postingDate);`,
        `CREATE INDEX IF NOT EXISTS idx_invoices_dueDate ON invoices(dueDate);`,
        `CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);`,
        `CREATE INDEX IF NOT EXISTS idx_invoices_customer ON invoices(customer);`, // Added index

         // --- Purchase Tables ---
         `CREATE TABLE IF NOT EXISTS purchase_orders (
            id TEXT PRIMARY KEY,
            vendor TEXT NOT NULL, -- Matches PurchaseOrderSchema vendor (string)
            orderDate TEXT NOT NULL, -- Matches PurchaseOrderSchema orderDate (string YYYY-MM-DD)
            expectedDeliveryDate TEXT NOT NULL, -- Matches PurchaseOrderSchema expectedDeliveryDate (string YYYY-MM-DD)
            totalAmount REAL, -- Matches PurchaseOrderSchema totalAmount (number)
            status TEXT NOT NULL CHECK(status IN ('Draft', 'Ordered', 'Partly Received', 'Received', 'Completed', 'Cancelled')) -- Matches PurchaseOrderSchema status enum
        );`,
         `CREATE INDEX IF NOT EXISTS idx_purchase_orders_orderDate ON purchase_orders(orderDate);`,
         `CREATE INDEX IF NOT EXISTS idx_purchase_orders_status ON purchase_orders(status);`,
         `CREATE INDEX IF NOT EXISTS idx_purchase_orders_vendor ON purchase_orders(vendor);`, // Added index

         `CREATE TABLE IF NOT EXISTS vendors (
             id TEXT PRIMARY KEY,
             name TEXT NOT NULL,
             contact_person TEXT,
             email TEXT,
             phone TEXT,
             address TEXT
         );`,
          `CREATE INDEX IF NOT EXISTS idx_vendors_name ON vendors(name);`,

         `CREATE TABLE IF NOT EXISTS bills (
              id TEXT PRIMARY KEY,
              vendor_id TEXT NOT NULL, -- Consider FOREIGN KEY constraint
              po_id TEXT, -- Consider FOREIGN KEY constraint
              bill_date TEXT NOT NULL,
              due_date TEXT NOT NULL,
              total_amount REAL,
              status TEXT NOT NULL CHECK(status IN ('Draft', 'Submitted', 'Partly Paid', 'Paid', 'Cancelled'))
         );`,
         `CREATE INDEX IF NOT EXISTS idx_bills_vendor_id ON bills(vendor_id);`,
         `CREATE INDEX IF NOT EXISTS idx_bills_po_id ON bills(po_id);`,
         `CREATE INDEX IF NOT EXISTS idx_bills_due_date ON bills(due_date);`,
         `CREATE INDEX IF NOT EXISTS idx_bills_status ON bills(status);`,

        // --- Finance Tables ---
        `CREATE TABLE IF NOT EXISTS accounts (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            type TEXT NOT NULL CHECK(type IN ('Asset', 'Liability', 'Equity', 'Income', 'Expense')),
            currency TEXT DEFAULT 'INR',
            balance REAL DEFAULT 0.0
        );`,
        `CREATE INDEX IF NOT EXISTS idx_accounts_name ON accounts(name);`,
        `CREATE INDEX IF NOT EXISTS idx_accounts_type ON accounts(type);`,

        `CREATE TABLE IF NOT EXISTS payments (
            id TEXT PRIMARY KEY,
            date TEXT NOT NULL,
            party_id TEXT, -- Link to Customer or Supplier
            party_type TEXT CHECK(party_type IN ('Customer', 'Supplier')),
            amount REAL NOT NULL,
            reference TEXT,
            payment_method TEXT,
            status TEXT CHECK(status IN ('Draft', 'Cleared', 'Reconciled', 'Cancelled'))
        );`,
         `CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(date);`,
         `CREATE INDEX IF NOT EXISTS idx_payments_party_id ON payments(party_id);`,
         `CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);`,

         `CREATE TABLE IF NOT EXISTS expenses (
             id TEXT PRIMARY KEY,
             date TEXT NOT NULL,
             category TEXT NOT NULL,
             description TEXT,
             amount REAL NOT NULL,
             paid_by TEXT, -- Link to employee or bank account?
             receipt_url TEXT
         );`,
         `CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date);`,
         `CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category);`,

         // --- HR Tables ---
         `CREATE TABLE IF NOT EXISTS employees (
            id TEXT PRIMARY KEY,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE,
            phone TEXT,
            job_title TEXT,
            department TEXT,
            hire_date TEXT,
            status TEXT CHECK(status IN ('Active', 'Inactive', 'Terminated'))
        );`,
        `CREATE INDEX IF NOT EXISTS idx_employees_name ON employees(last_name, first_name);`,
        `CREATE INDEX IF NOT EXISTS idx_employees_email ON employees(email);`,
        `CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department);`,
        `CREATE INDEX IF NOT EXISTS idx_employees_status ON employees(status);`,

         // --- Demo Table for Testing ---
         `CREATE TABLE IF NOT EXISTS demo_table (
             id INTEGER PRIMARY KEY AUTOINCREMENT,
             name TEXT NOT NULL,
             value REAL,
             created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
         );`,
          // --- Test Table for Connection Check ---
         `CREATE TABLE IF NOT EXISTS test_connection (
            id INTEGER PRIMARY KEY,
            message TEXT
         );`,
        // Add a test record to test_connection
        `INSERT INTO test_connection (id, message) VALUES (1, 'Connection test table exists') ON CONFLICT(id) DO NOTHING;`


    ], 'write'); // Use 'write' mode for DDL statements
    console.log('Database schema initialization batch executed successfully.');
  } catch (e) {
     // Check specifically for LibsqlError and potential 401/404 during schema init
     if (e instanceof LibsqlError && e.code === 'SERVER_ERROR') {
        if (e.message.includes('401')) {
            console.error(`\n--- Database Authentication Error (HTTP 401) during schema initialization ---\nACTION REQUIRED: Please verify your TURSO_AUTH_TOKEN environment variable is correctly set and valid.\nError Details: ${e.message}\n---`);
            throw new Error('Database authentication failed (401) during schema initialization. Check your TURSO_AUTH_TOKEN.');
        } else if (e.message.includes('404')) {
             console.error(`\n--- Database Not Found Error (HTTP 404) during schema initialization ---\nACTION REQUIRED: Please verify your TURSO_DATABASE_URL environment variable is correct and that the database exists.\nError Details: ${e.message}\n---`);
             // Throw a more specific error message for 404 during schema init
             throw new Error('Database not found (404) during schema initialization. Check your TURSO_DATABASE_URL.');
        } else {
             console.error(`\n--- Database Server Error (${e.code}) during schema initialization ---\nError Details: ${e.message}\n---`);
              throw new Error(`Database server error during schema initialization: ${e.message}`);
        }
     } else if (e instanceof LibsqlError) {
         console.error(`\n--- Database Error (${e.code || 'Unknown LibsqlError'}) during schema initialization ---\nError Details: ${e.message}\n---`);
         throw new Error(`Database error during schema initialization: ${e.message}`);
     } else {
        console.error('Failed to execute schema initialization batch:', e);
         throw new Error(`An unexpected error occurred during schema initialization: ${e instanceof Error ? e.message : String(e)}`);
     }
  }
}

// Function to check database connection by executing a simple query
// To be called explicitly, e.g., from an API route or setup script
export async function checkDatabaseConnection(): Promise<DbConnectionResult> {
  console.log('Attempting to check database connection...');
  let client: Client;
  try {
    client = getClient(); // Get or initialize client
    console.log('Database client obtained for connection check.');
  } catch (initError) {
    console.error("Cannot check connection: Database client initialization failed.", initError);
    return { success: false, message: `Connection check failed due to DB client error: ${initError instanceof Error ? initError.message : String(initError)}` };
  }

  try {
    console.log("Executing simple query to test connection...");
    // Use the test_connection table created in initializeDbSchema
    const result = await client.execute('SELECT 1 FROM test_connection LIMIT 1');
    console.log('Database connection test successful:', result);
    return { success: true, message: 'Database connection successful.' };
  } catch (error) {
    console.error('Database connection test failed:', error);
    // Check for specific error types
    if (error instanceof LibsqlError && error.code === 'SERVER_ERROR') {
        if (error.message.includes('401')) {
             return { success: false, message: 'Database authentication failed (401). Check TURSO_AUTH_TOKEN.' };
        } else if (error.message.includes('404')) {
             // Return a more specific message for 404
             return { success: false, message: 'Database not found (404). Check TURSO_DATABASE_URL.' };
        } else {
             return { success: false, message: `Database server error: ${error.message}` };
        }
    } else if (error instanceof LibsqlError && error.code === 'URL_INVALID'){
        return { success: false, message: `Invalid database URL format. Check TURSO_DATABASE_URL.` };
    } else if (error instanceof LibsqlError && error.code === 'SQLITE_UNKNOWN' && error.message.includes('no such table: test_connection')) {
        return { success: false, message: 'Database schema not initialized. Cannot find test_connection table.' };
    } else {
        return { success: false, message: `Database connection failed: ${error instanceof Error ? error.message : String(error)}` };
    }
  }
}


// Example usage (can be called from an API route or server action)
export async function testDatabaseConnection(): Promise<DbConnectionResult> {
  const isConnected = await checkDatabaseConnection();
  if (isConnected.success) {
    return { success: true, message: 'Database connection is successful.' };
  } else {
    // Log the detailed error message from checkDatabaseConnection
    console.error('testDatabaseConnection failed:', isConnected.message);
    return { success: false, message: `Database connection failed. Check console logs for details. Error: ${isConnected.message}` };
  }
}

// NOTE: The automatic call to initializeDbSchema() has been removed.
// It should be called explicitly when needed, e.g., via an API route or a setup script.
// Avoid calling on every request in production.
// Example call in `src/app/api/init-db/route.ts`
// await initializeDbSchema();
