
"use client";

import Link from 'next/link';
import {
  Bell,
  CircleUser,
  Home,
  LineChart,
  Menu,
  Package, // Used for Items
  Boxes, // Used for Item Groups
  Building, // Used for Parties
  Search,
  ShoppingCart,
  Users,
  Bot,
  Settings,
  Contact, // Keep for main CRM
  Target, // For Leads
  Handshake, // For Opportunities
  Filter, // Replaced Pipeline
  DollarSign, // Added missing import
  FileText, // For Quotations
  ClipboardList, // For Sales Orders
  Receipt, // For Invoices
  Truck, // Purchase Orders
  BookUser, // Vendors
  FileStack, // Bills
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'; // Import SheetTrigger and SheetTitle
import { SidebarTrigger, useSidebar } from '@/components/ui/sidebar';

export function Header() {
  const { toggleSidebar } = useSidebar();

  return (
    <header className="flex h-14 items-center gap-4 border-b bg-card px-4 lg:h-[60px] lg:px-6 sticky top-0 z-30">
      <SidebarTrigger className="hidden md:flex" />
      <Sheet>
         <SheetTrigger asChild>
            <Button
              variant="outline"
              size="icon"
              suppressHydrationWarning // Add suppressHydrationWarning
              className="shrink-0 md:hidden"
            >
               <Menu className="h-5 w-5" />
               <span className="sr-only">Toggle navigation menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="flex flex-col p-0 w-full max-w-xs sm:max-w-sm">
             {/* Mobile Sidebar Content */}
              <SheetTitle className="sr-only">Mobile Navigation Menu</SheetTitle> {/* Added accessible title */}
             <nav className="grid gap-2 text-lg font-medium p-6">
                <Link href="#" className="flex items-center gap-2 text-lg font-semibold mb-4">
                   <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-6 w-6 text-primary"
                    >
                      <path d="M12 2L2 7l10 5 10-5-10-5z" />
                      <path d="M2 17l10 5 10-5" />
                      <path d="M2 12l10 5 10-5" />
                    </svg>
                    <span>EraErp</span>
                </Link>
                <Link href="/" className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground">
                   <Home className="h-5 w-5" />
                    Dashboard
                </Link>
                 <Link href="/crm" className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground">
                  <Contact className="h-5 w-5" />
                  CRM
                 </Link>
                 {/* Add specific CRM links for mobile */}
                 <Link href="/crm/items" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                    <Package className="h-4 w-4" /> Items
                 </Link>
                 <Link href="/crm/item-groups" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                    <Boxes className="h-4 w-4" /> Item Groups
                 </Link>
                  <Link href="/crm/parties" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                     <Building className="h-4 w-4" /> Parties
                  </Link>
                  <Link href="/crm/leads" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                     <Target className="h-4 w-4" /> Leads
                  </Link>
                  <Link href="/crm/contacts" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                     <Users className="h-4 w-4" /> Contacts {/* Using Users icon as Contact is used for main CRM */}
                  </Link>
                   <Link href="/crm/opportunities" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                     <Handshake className="h-4 w-4" /> Opportunities
                  </Link>
                   <Link href="/crm/pipeline" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                     <Filter className="h-4 w-4" /> Pipeline
                  </Link>
                 {/* --- End CRM links --- */}

                 <Link href="/sales" className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground">
                  <LineChart className="h-5 w-5" />
                  Sales
                 </Link>
                  {/* Add specific Sales links for mobile */}
                 <Link href="/sales/quotations" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                    <FileText className="h-4 w-4" /> Quotations
                 </Link>
                 <Link href="/sales/sales-orders" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                    <ClipboardList className="h-4 w-4" /> Sales Orders
                 </Link>
                 <Link href="/sales/invoices" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                    <Receipt className="h-4 w-4" /> Invoices
                 </Link>
                 {/* --- End Sales links --- */}

                <Link href="/hr" className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground">
                  <Users className="h-5 w-5" />
                  Human Resources
                </Link>
                 <Link href="/suggest-roles" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                   <Bot className="h-4 w-4" />
                    Suggest Roles (AI)
                 </Link>
                  <Link href="/finance" className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground">
                   <DollarSign className="h-5 w-5" />
                   Finance
                 </Link>
                  <Link href="/purchase" className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground">
                   <ShoppingCart className="h-5 w-5" />
                   Purchase
                 </Link>
                 {/* Add specific Purchase links for mobile */}
                 <Link href="/purchase/purchase-orders" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                    <Truck className="h-4 w-4" /> Purchase Orders
                 </Link>
                 <Link href="/purchase/vendors" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                    <BookUser className="h-4 w-4" /> Vendors
                 </Link>
                 <Link href="/purchase/bills" className="ml-4 flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground text-base">
                    <FileStack className="h-4 w-4" /> Bills
                 </Link>
                 {/* --- End Purchase links --- */}

                <Link href="/settings" className="flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground">
                  <Settings className="h-5 w-5" />
                  Settings
                 </Link>
             </nav>
          </SheetContent>
      </Sheet>

      <div className="w-full flex-1">
        <form>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search features, items, parties..." // Updated placeholder
              className="w-full appearance-none bg-background pl-8 shadow-none md:w-2/3 lg:w-1/3"
              suppressHydrationWarning // Add suppressHydrationWarning
            />
          </div>
        </form>
      </div>
      <Button variant="outline" size="icon" className="relative" suppressHydrationWarning>
        <Bell className="h-4 w-4" />
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
           <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
           <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
        </span>
        <span className="sr-only">Toggle notifications</span>
      </Button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="secondary" size="icon" className="rounded-full" suppressHydrationWarning>
            <CircleUser className="h-5 w-5" />
            <span className="sr-only">Toggle user menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>My Account</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem>
             <Settings className="mr-2 h-4 w-4" />
             <span>Settings</span>
          </DropdownMenuItem>
          <DropdownMenuItem>Support</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem>Logout</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  );
}
