
import type {NextConfig} from 'next';

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    // Set to false ONLY if you're confident about type safety or managing errors elsewhere
    ignoreBuildErrors: true,
  },
  eslint: {
    // Recommended: Address linting issues instead of ignoring them
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'picsum.photos',
        port: '',
        pathname: '/**',
      },
    ],
    // Add deviceSizes and imageSizes if you know the specific sizes your app uses
    // deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    // imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
  },
  // Experimental features (use with caution, may change)
  experimental: {
    // Enable Server Actions (if you are using them extensively)
    serverActions: true,
    // Consider enabling other relevant flags based on Next.js version and needs
    // e.g., typedRoutes: true, serverComponentsExternalPackages: ['some-package']
  },
  // Optimize build output
  // output: 'standalone', // Creates a smaller deployment footprint if needed
};

export default nextConfig;
